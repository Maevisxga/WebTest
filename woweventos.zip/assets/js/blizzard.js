function polyfill(e, t, n) {
	e[t] || Object.defineProperty(e, t, {
		enumerable: !1,
		configurable: !0,
		writable: !0,
		value: n
	})
}
if (function(e, t) {
		"object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function(e) {
			if (!e.document) throw new Error("jQuery requires a window with a document");
			return t(e)
		} : t(e)
	}("undefined" != typeof window ? window : this, function(e, t) {
		var n = [],
			i = e.document,
			o = n.slice,
			r = n.concat,
			a = n.push,
			s = n.indexOf,
			l = {},
			c = l.toString,
			u = l.hasOwnProperty,
			d = {},
			f = function(e, t) {
				return new f.fn.init(e, t)
			},
			p = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
			h = /^-ms-/,
			m = /-([\da-z])/gi,
			g = function(e, t) {
				return t.toUpperCase()
			};

		function v(e) {
			var t = !!e && "length" in e && e.length,
				n = f.type(e);
			return "function" !== n && !f.isWindow(e) && ("array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e)
		}
		f.fn = f.prototype = {
			jquery: "2.2.4",
			constructor: f,
			selector: "",
			length: 0,
			toArray: function() {
				return o.call(this)
			},
			get: function(e) {
				return null != e ? e < 0 ? this[e + this.length] : this[e] : o.call(this)
			},
			pushStack: function(e) {
				var t = f.merge(this.constructor(), e);
				return t.prevObject = this, t.context = this.context, t
			},
			each: function(e) {
				return f.each(this, e)
			},
			map: function(e) {
				return this.pushStack(f.map(this, function(t, n) {
					return e.call(t, n, t)
				}))
			},
			slice: function() {
				return this.pushStack(o.apply(this, arguments))
			},
			first: function() {
				return this.eq(0)
			},
			last: function() {
				return this.eq(-1)
			},
			eq: function(e) {
				var t = this.length,
					n = +e + (e < 0 ? t : 0);
				return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
			},
			end: function() {
				return this.prevObject || this.constructor()
			},
			push: a,
			sort: n.sort,
			splice: n.splice
		}, f.extend = f.fn.extend = function() {
			var e, t, n, i, o, r, a = arguments[0] || {},
				s = 1,
				l = arguments.length,
				c = !1;
			for ("boolean" == typeof a && (c = a, a = arguments[s] || {}, s++), "object" == typeof a || f.isFunction(a) || (a = {}), s === l && (a = this, s--); s < l; s++)
				if (null != (e = arguments[s]))
					for (t in e) n = a[t], a !== (i = e[t]) && (c && i && (f.isPlainObject(i) || (o = f.isArray(i))) ? (o ? (o = !1, r = n && f.isArray(n) ? n : []) : r = n && f.isPlainObject(n) ? n : {}, a[t] = f.extend(c, r, i)) : void 0 !== i && (a[t] = i));
			return a
		}, f.extend({
			expando: "jQuery" + ("2.2.4" + Math.random()).replace(/\D/g, ""),
			isReady: !0,
			error: function(e) {
				throw new Error(e)
			},
			noop: function() {},
			isFunction: function(e) {
				return "function" === f.type(e)
			},
			isArray: Array.isArray,
			isWindow: function(e) {
				return null != e && e === e.window
			},
			isNumeric: function(e) {
				var t = e && e.toString();
				return !f.isArray(e) && t - parseFloat(t) + 1 >= 0
			},
			isPlainObject: function(e) {
				var t;
				if ("object" !== f.type(e) || e.nodeType || f.isWindow(e)) return !1;
				if (e.constructor && !u.call(e, "constructor") && !u.call(e.constructor.prototype || {}, "isPrototypeOf")) return !1;
				for (t in e);
				return void 0 === t || u.call(e, t)
			},
			isEmptyObject: function(e) {
				var t;
				for (t in e) return !1;
				return !0
			},
			type: function(e) {
				return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? l[c.call(e)] || "object" : typeof e
			},
			globalEval: function(e) {
				var t, n = eval;
				(e = f.trim(e)) && (1 === e.indexOf("use strict") ? ((t = i.createElement("script")).text = e, i.head.appendChild(t).parentNode.removeChild(t)) : n(e))
			},
			camelCase: function(e) {
				return e.replace(h, "ms-").replace(m, g)
			},
			nodeName: function(e, t) {
				return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
			},
			each: function(e, t) {
				var n, i = 0;
				if (v(e))
					for (n = e.length; i < n && !1 !== t.call(e[i], i, e[i]); i++);
				else
					for (i in e)
						if (!1 === t.call(e[i], i, e[i])) break;
				return e
			},
			trim: function(e) {
				return null == e ? "" : (e + "").replace(p, "")
			},
			makeArray: function(e, t) {
				var n = t || [];
				return null != e && (v(Object(e)) ? f.merge(n, "string" == typeof e ? [e] : e) : a.call(n, e)), n
			},
			inArray: function(e, t, n) {
				return null == t ? -1 : s.call(t, e, n)
			},
			merge: function(e, t) {
				for (var n = +t.length, i = 0, o = e.length; i < n; i++) e[o++] = t[i];
				return e.length = o, e
			},
			grep: function(e, t, n) {
				for (var i = [], o = 0, r = e.length, a = !n; o < r; o++) !t(e[o], o) !== a && i.push(e[o]);
				return i
			},
			map: function(e, t, n) {
				var i, o, a = 0,
					s = [];
				if (v(e))
					for (i = e.length; a < i; a++) null != (o = t(e[a], a, n)) && s.push(o);
				else
					for (a in e) null != (o = t(e[a], a, n)) && s.push(o);
				return r.apply([], s)
			},
			guid: 1,
			proxy: function(e, t) {
				var n, i, r;
				if ("string" == typeof t && (n = e[t], t = e, e = n), f.isFunction(e)) return i = o.call(arguments, 2), (r = function() {
					return e.apply(t || this, i.concat(o.call(arguments)))
				}).guid = e.guid = e.guid || f.guid++, r
			},
			now: Date.now,
			support: d
		}), "function" == typeof Symbol && (f.fn[Symbol.iterator] = n[Symbol.iterator]), f.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(e, t) {
			l["[object " + t + "]"] = t.toLowerCase()
		});
		var y = function(e) {
			var t, n, i, o, r, a, s, l, c, u, d, f, p, h, m, g, v, y, b, E = "sizzle" + 1 * new Date,
				T = e.document,
				w = 0,
				S = 0,
				C = re(),
				I = re(),
				x = re(),
				A = function(e, t) {
					return e === t && (d = !0), 0
				},
				D = 1 << 31,
				L = {}.hasOwnProperty,
				N = [],
				O = N.pop,
				M = N.push,
				_ = N.push,
				R = N.slice,
				k = function(e, t) {
					for (var n = 0, i = e.length; n < i; n++)
						if (e[n] === t) return n;
					return -1
				},
				U = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
				P = "[\\x20\\t\\r\\n\\f]",
				F = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
				H = "\\[" + P + "*(" + F + ")(?:" + P + "*([*^$|!~]?=)" + P + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + F + "))|)" + P + "*\\]",
				q = ":(" + F + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + H + ")*)|.*)\\)|)",
				$ = new RegExp(P + "+", "g"),
				G = new RegExp("^" + P + "+|((?:^|[^\\\\])(?:\\\\.)*)" + P + "+$", "g"),
				B = new RegExp("^" + P + "*," + P + "*"),
				z = new RegExp("^" + P + "*([>+~]|" + P + ")" + P + "*"),
				Y = new RegExp("=" + P + "*([^\\]'\"]*?)" + P + "*\\]", "g"),
				j = new RegExp(q),
				K = new RegExp("^" + F + "$"),
				W = {
					ID: new RegExp("^#(" + F + ")"),
					CLASS: new RegExp("^\\.(" + F + ")"),
					TAG: new RegExp("^(" + F + "|[*])"),
					ATTR: new RegExp("^" + H),
					PSEUDO: new RegExp("^" + q),
					CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + P + "*(even|odd|(([+-]|)(\\d*)n|)" + P + "*(?:([+-]|)" + P + "*(\\d+)|))" + P + "*\\)|)", "i"),
					bool: new RegExp("^(?:" + U + ")$", "i"),
					needsContext: new RegExp("^" + P + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + P + "*((?:-\\d)?\\d*)" + P + "*\\)|)(?=[^-]|$)", "i")
				},
				V = /^(?:input|select|textarea|button)$/i,
				X = /^h\d$/i,
				Z = /^[^{]+\{\s*\[native \w/,
				Q = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
				J = /[+~]/,
				ee = /'|\\/g,
				te = new RegExp("\\\\([\\da-f]{1,6}" + P + "?|(" + P + ")|.)", "ig"),
				ne = function(e, t, n) {
					var i = "0x" + t - 65536;
					return i != i || n ? t : i < 0 ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, 1023 & i | 56320)
				},
				ie = function() {
					f()
				};
			try {
				_.apply(N = R.call(T.childNodes), T.childNodes), N[T.childNodes.length].nodeType
			} catch (e) {
				_ = {
					apply: N.length ? function(e, t) {
						M.apply(e, R.call(t))
					} : function(e, t) {
						for (var n = e.length, i = 0; e[n++] = t[i++];);
						e.length = n - 1
					}
				}
			}

			function oe(e, t, i, o) {
				var r, s, c, u, d, h, v, y, w = t && t.ownerDocument,
					S = t ? t.nodeType : 9;
				if (i = i || [], "string" != typeof e || !e || 1 !== S && 9 !== S && 11 !== S) return i;
				if (!o && ((t ? t.ownerDocument || t : T) !== p && f(t), t = t || p, m)) {
					if (11 !== S && (h = Q.exec(e)))
						if (r = h[1]) {
							if (9 === S) {
								if (!(c = t.getElementById(r))) return i;
								if (c.id === r) return i.push(c), i
							} else if (w && (c = w.getElementById(r)) && b(t, c) && c.id === r) return i.push(c), i
						} else {
							if (h[2]) return _.apply(i, t.getElementsByTagName(e)), i;
							if ((r = h[3]) && n.getElementsByClassName && t.getElementsByClassName) return _.apply(i, t.getElementsByClassName(r)), i
						} if (n.qsa && !x[e + " "] && (!g || !g.test(e))) {
						if (1 !== S) w = t, y = e;
						else if ("object" !== t.nodeName.toLowerCase()) {
							for ((u = t.getAttribute("id")) ? u = u.replace(ee, "\\$&") : t.setAttribute("id", u = E), s = (v = a(e)).length, d = K.test(u) ? "#" + u : "[id='" + u + "']"; s--;) v[s] = d + " " + me(v[s]);
							y = v.join(","), w = J.test(e) && pe(t.parentNode) || t
						}
						if (y) try {
							return _.apply(i, w.querySelectorAll(y)), i
						} catch (e) {} finally {
							u === E && t.removeAttribute("id")
						}
					}
				}
				return l(e.replace(G, "$1"), t, i, o)
			}

			function re() {
				var e = [];
				return function t(n, o) {
					return e.push(n + " ") > i.cacheLength && delete t[e.shift()], t[n + " "] = o
				}
			}

			function ae(e) {
				return e[E] = !0, e
			}

			function se(e) {
				var t = p.createElement("div");
				try {
					return !!e(t)
				} catch (e) {
					return !1
				} finally {
					t.parentNode && t.parentNode.removeChild(t), t = null
				}
			}

			function le(e, t) {
				for (var n = e.split("|"), o = n.length; o--;) i.attrHandle[n[o]] = t
			}

			function ce(e, t) {
				var n = t && e,
					i = n && 1 === e.nodeType && 1 === t.nodeType && (~t.sourceIndex || D) - (~e.sourceIndex || D);
				if (i) return i;
				if (n)
					for (; n = n.nextSibling;)
						if (n === t) return -1;
				return e ? 1 : -1
			}

			function ue(e) {
				return function(t) {
					return "input" === t.nodeName.toLowerCase() && t.type === e
				}
			}

			function de(e) {
				return function(t) {
					var n = t.nodeName.toLowerCase();
					return ("input" === n || "button" === n) && t.type === e
				}
			}

			function fe(e) {
				return ae(function(t) {
					return t = +t, ae(function(n, i) {
						for (var o, r = e([], n.length, t), a = r.length; a--;) n[o = r[a]] && (n[o] = !(i[o] = n[o]))
					})
				})
			}

			function pe(e) {
				return e && void 0 !== e.getElementsByTagName && e
			}
			for (t in n = oe.support = {}, r = oe.isXML = function(e) {
					var t = e && (e.ownerDocument || e).documentElement;
					return !!t && "HTML" !== t.nodeName
				}, f = oe.setDocument = function(e) {
					var t, o, a = e ? e.ownerDocument || e : T;
					return a !== p && 9 === a.nodeType && a.documentElement ? (h = (p = a).documentElement, m = !r(p), (o = p.defaultView) && o.top !== o && (o.addEventListener ? o.addEventListener("unload", ie, !1) : o.attachEvent && o.attachEvent("onunload", ie)), n.attributes = se(function(e) {
						return e.className = "i", !e.getAttribute("className")
					}), n.getElementsByTagName = se(function(e) {
						return e.appendChild(p.createComment("")), !e.getElementsByTagName("*").length
					}), n.getElementsByClassName = Z.test(p.getElementsByClassName), n.getById = se(function(e) {
						return h.appendChild(e).id = E, !p.getElementsByName || !p.getElementsByName(E).length
					}), n.getById ? (i.find.ID = function(e, t) {
						if (void 0 !== t.getElementById && m) {
							var n = t.getElementById(e);
							return n ? [n] : []
						}
					}, i.filter.ID = function(e) {
						var t = e.replace(te, ne);
						return function(e) {
							return e.getAttribute("id") === t
						}
					}) : (delete i.find.ID, i.filter.ID = function(e) {
						var t = e.replace(te, ne);
						return function(e) {
							var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
							return n && n.value === t
						}
					}), i.find.TAG = n.getElementsByTagName ? function(e, t) {
						return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : n.qsa ? t.querySelectorAll(e) : void 0
					} : function(e, t) {
						var n, i = [],
							o = 0,
							r = t.getElementsByTagName(e);
						if ("*" === e) {
							for (; n = r[o++];) 1 === n.nodeType && i.push(n);
							return i
						}
						return r
					}, i.find.CLASS = n.getElementsByClassName && function(e, t) {
						if (void 0 !== t.getElementsByClassName && m) return t.getElementsByClassName(e)
					}, v = [], g = [], (n.qsa = Z.test(p.querySelectorAll)) && (se(function(e) {
						h.appendChild(e).innerHTML = "<a id='" + E + "'></a><select id='" + E + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && g.push("[*^$]=" + P + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || g.push("\\[" + P + "*(?:value|" + U + ")"), e.querySelectorAll("[id~=" + E + "-]").length || g.push("~="), e.querySelectorAll(":checked").length || g.push(":checked"), e.querySelectorAll("a#" + E + "+*").length || g.push(".#.+[+~]")
					}), se(function(e) {
						var t = p.createElement("input");
						t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && g.push("name" + P + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || g.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), g.push(",.*:")
					})), (n.matchesSelector = Z.test(y = h.matches || h.webkitMatchesSelector || h.mozMatchesSelector || h.oMatchesSelector || h.msMatchesSelector)) && se(function(e) {
						n.disconnectedMatch = y.call(e, "div"), y.call(e, "[s!='']:x"), v.push("!=", q)
					}), g = g.length && new RegExp(g.join("|")), v = v.length && new RegExp(v.join("|")), t = Z.test(h.compareDocumentPosition), b = t || Z.test(h.contains) ? function(e, t) {
						var n = 9 === e.nodeType ? e.documentElement : e,
							i = t && t.parentNode;
						return e === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(i)))
					} : function(e, t) {
						if (t)
							for (; t = t.parentNode;)
								if (t === e) return !0;
						return !1
					}, A = t ? function(e, t) {
						if (e === t) return d = !0, 0;
						var i = !e.compareDocumentPosition - !t.compareDocumentPosition;
						return i || (1 & (i = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !n.sortDetached && t.compareDocumentPosition(e) === i ? e === p || e.ownerDocument === T && b(T, e) ? -1 : t === p || t.ownerDocument === T && b(T, t) ? 1 : u ? k(u, e) - k(u, t) : 0 : 4 & i ? -1 : 1)
					} : function(e, t) {
						if (e === t) return d = !0, 0;
						var n, i = 0,
							o = e.parentNode,
							r = t.parentNode,
							a = [e],
							s = [t];
						if (!o || !r) return e === p ? -1 : t === p ? 1 : o ? -1 : r ? 1 : u ? k(u, e) - k(u, t) : 0;
						if (o === r) return ce(e, t);
						for (n = e; n = n.parentNode;) a.unshift(n);
						for (n = t; n = n.parentNode;) s.unshift(n);
						for (; a[i] === s[i];) i++;
						return i ? ce(a[i], s[i]) : a[i] === T ? -1 : s[i] === T ? 1 : 0
					}, p) : p
				}, oe.matches = function(e, t) {
					return oe(e, null, null, t)
				}, oe.matchesSelector = function(e, t) {
					if ((e.ownerDocument || e) !== p && f(e), t = t.replace(Y, "='$1']"), n.matchesSelector && m && !x[t + " "] && (!v || !v.test(t)) && (!g || !g.test(t))) try {
						var i = y.call(e, t);
						if (i || n.disconnectedMatch || e.document && 11 !== e.document.nodeType) return i
					} catch (e) {}
					return oe(t, p, null, [e]).length > 0
				}, oe.contains = function(e, t) {
					return (e.ownerDocument || e) !== p && f(e), b(e, t)
				}, oe.attr = function(e, t) {
					(e.ownerDocument || e) !== p && f(e);
					var o = i.attrHandle[t.toLowerCase()],
						r = o && L.call(i.attrHandle, t.toLowerCase()) ? o(e, t, !m) : void 0;
					return void 0 !== r ? r : n.attributes || !m ? e.getAttribute(t) : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
				}, oe.error = function(e) {
					throw new Error("Syntax error, unrecognized expression: " + e)
				}, oe.uniqueSort = function(e) {
					var t, i = [],
						o = 0,
						r = 0;
					if (d = !n.detectDuplicates, u = !n.sortStable && e.slice(0), e.sort(A), d) {
						for (; t = e[r++];) t === e[r] && (o = i.push(r));
						for (; o--;) e.splice(i[o], 1)
					}
					return u = null, e
				}, o = oe.getText = function(e) {
					var t, n = "",
						i = 0,
						r = e.nodeType;
					if (r) {
						if (1 === r || 9 === r || 11 === r) {
							if ("string" == typeof e.textContent) return e.textContent;
							for (e = e.firstChild; e; e = e.nextSibling) n += o(e)
						} else if (3 === r || 4 === r) return e.nodeValue
					} else
						for (; t = e[i++];) n += o(t);
					return n
				}, (i = oe.selectors = {
					cacheLength: 50,
					createPseudo: ae,
					match: W,
					attrHandle: {},
					find: {},
					relative: {
						">": {
							dir: "parentNode",
							first: !0
						},
						" ": {
							dir: "parentNode"
						},
						"+": {
							dir: "previousSibling",
							first: !0
						},
						"~": {
							dir: "previousSibling"
						}
					},
					preFilter: {
						ATTR: function(e) {
							return e[1] = e[1].replace(te, ne), e[3] = (e[3] || e[4] || e[5] || "").replace(te, ne), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
						},
						CHILD: function(e) {
							return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || oe.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && oe.error(e[0]), e
						},
						PSEUDO: function(e) {
							var t, n = !e[6] && e[2];
							return W.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && j.test(n) && (t = a(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
						}
					},
					filter: {
						TAG: function(e) {
							var t = e.replace(te, ne).toLowerCase();
							return "*" === e ? function() {
								return !0
							} : function(e) {
								return e.nodeName && e.nodeName.toLowerCase() === t
							}
						},
						CLASS: function(e) {
							var t = C[e + " "];
							return t || (t = new RegExp("(^|" + P + ")" + e + "(" + P + "|$)")) && C(e, function(e) {
								return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
							})
						},
						ATTR: function(e, t, n) {
							return function(i) {
								var o = oe.attr(i, e);
								return null == o ? "!=" === t : !t || (o += "", "=" === t ? o === n : "!=" === t ? o !== n : "^=" === t ? n && 0 === o.indexOf(n) : "*=" === t ? n && o.indexOf(n) > -1 : "$=" === t ? n && o.slice(-n.length) === n : "~=" === t ? (" " + o.replace($, " ") + " ").indexOf(n) > -1 : "|=" === t && (o === n || o.slice(0, n.length + 1) === n + "-"))
							}
						},
						CHILD: function(e, t, n, i, o) {
							var r = "nth" !== e.slice(0, 3),
								a = "last" !== e.slice(-4),
								s = "of-type" === t;
							return 1 === i && 0 === o ? function(e) {
								return !!e.parentNode
							} : function(t, n, l) {
								var c, u, d, f, p, h, m = r !== a ? "nextSibling" : "previousSibling",
									g = t.parentNode,
									v = s && t.nodeName.toLowerCase(),
									y = !l && !s,
									b = !1;
								if (g) {
									if (r) {
										for (; m;) {
											for (f = t; f = f[m];)
												if (s ? f.nodeName.toLowerCase() === v : 1 === f.nodeType) return !1;
											h = m = "only" === e && !h && "nextSibling"
										}
										return !0
									}
									if (h = [a ? g.firstChild : g.lastChild], a && y) {
										for (b = (p = (c = (u = (d = (f = g)[E] || (f[E] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] || [])[0] === w && c[1]) && c[2], f = p && g.childNodes[p]; f = ++p && f && f[m] || (b = p = 0) || h.pop();)
											if (1 === f.nodeType && ++b && f === t) {
												u[e] = [w, p, b];
												break
											}
									} else if (y && (b = p = (c = (u = (d = (f = t)[E] || (f[E] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] || [])[0] === w && c[1]), !1 === b)
										for (;
											(f = ++p && f && f[m] || (b = p = 0) || h.pop()) && ((s ? f.nodeName.toLowerCase() !== v : 1 !== f.nodeType) || !++b || (y && ((u = (d = f[E] || (f[E] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] = [w, b]), f !== t)););
									return (b -= o) === i || b % i == 0 && b / i >= 0
								}
							}
						},
						PSEUDO: function(e, t) {
							var n, o = i.pseudos[e] || i.setFilters[e.toLowerCase()] || oe.error("unsupported pseudo: " + e);
							return o[E] ? o(t) : o.length > 1 ? (n = [e, e, "", t], i.setFilters.hasOwnProperty(e.toLowerCase()) ? ae(function(e, n) {
								for (var i, r = o(e, t), a = r.length; a--;) e[i = k(e, r[a])] = !(n[i] = r[a])
							}) : function(e) {
								return o(e, 0, n)
							}) : o
						}
					},
					pseudos: {
						not: ae(function(e) {
							var t = [],
								n = [],
								i = s(e.replace(G, "$1"));
							return i[E] ? ae(function(e, t, n, o) {
								for (var r, a = i(e, null, o, []), s = e.length; s--;)(r = a[s]) && (e[s] = !(t[s] = r))
							}) : function(e, o, r) {
								return t[0] = e, i(t, null, r, n), t[0] = null, !n.pop()
							}
						}),
						has: ae(function(e) {
							return function(t) {
								return oe(e, t).length > 0
							}
						}),
						contains: ae(function(e) {
							return e = e.replace(te, ne),
								function(t) {
									return (t.textContent || t.innerText || o(t)).indexOf(e) > -1
								}
						}),
						lang: ae(function(e) {
							return K.test(e || "") || oe.error("unsupported lang: " + e), e = e.replace(te, ne).toLowerCase(),
								function(t) {
									var n;
									do {
										if (n = m ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
									} while ((t = t.parentNode) && 1 === t.nodeType);
									return !1
								}
						}),
						target: function(t) {
							var n = e.location && e.location.hash;
							return n && n.slice(1) === t.id
						},
						root: function(e) {
							return e === h
						},
						focus: function(e) {
							return e === p.activeElement && (!p.hasFocus || p.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
						},
						enabled: function(e) {
							return !1 === e.disabled
						},
						disabled: function(e) {
							return !0 === e.disabled
						},
						checked: function(e) {
							var t = e.nodeName.toLowerCase();
							return "input" === t && !!e.checked || "option" === t && !!e.selected
						},
						selected: function(e) {
							return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
						},
						empty: function(e) {
							for (e = e.firstChild; e; e = e.nextSibling)
								if (e.nodeType < 6) return !1;
							return !0
						},
						parent: function(e) {
							return !i.pseudos.empty(e)
						},
						header: function(e) {
							return X.test(e.nodeName)
						},
						input: function(e) {
							return V.test(e.nodeName)
						},
						button: function(e) {
							var t = e.nodeName.toLowerCase();
							return "input" === t && "button" === e.type || "button" === t
						},
						text: function(e) {
							var t;
							return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
						},
						first: fe(function() {
							return [0]
						}),
						last: fe(function(e, t) {
							return [t - 1]
						}),
						eq: fe(function(e, t, n) {
							return [n < 0 ? n + t : n]
						}),
						even: fe(function(e, t) {
							for (var n = 0; n < t; n += 2) e.push(n);
							return e
						}),
						odd: fe(function(e, t) {
							for (var n = 1; n < t; n += 2) e.push(n);
							return e
						}),
						lt: fe(function(e, t, n) {
							for (var i = n < 0 ? n + t : n; --i >= 0;) e.push(i);
							return e
						}),
						gt: fe(function(e, t, n) {
							for (var i = n < 0 ? n + t : n; ++i < t;) e.push(i);
							return e
						})
					}
				}).pseudos.nth = i.pseudos.eq, {
					radio: !0,
					checkbox: !0,
					file: !0,
					password: !0,
					image: !0
				}) i.pseudos[t] = ue(t);
			for (t in {
					submit: !0,
					reset: !0
				}) i.pseudos[t] = de(t);

			function he() {}

			function me(e) {
				for (var t = 0, n = e.length, i = ""; t < n; t++) i += e[t].value;
				return i
			}

			function ge(e, t, n) {
				var i = t.dir,
					o = n && "parentNode" === i,
					r = S++;
				return t.first ? function(t, n, r) {
					for (; t = t[i];)
						if (1 === t.nodeType || o) return e(t, n, r)
				} : function(t, n, a) {
					var s, l, c, u = [w, r];
					if (a) {
						for (; t = t[i];)
							if ((1 === t.nodeType || o) && e(t, n, a)) return !0
					} else
						for (; t = t[i];)
							if (1 === t.nodeType || o) {
								if ((s = (l = (c = t[E] || (t[E] = {}))[t.uniqueID] || (c[t.uniqueID] = {}))[i]) && s[0] === w && s[1] === r) return u[2] = s[2];
								if (l[i] = u, u[2] = e(t, n, a)) return !0
							}
				}
			}

			function ve(e) {
				return e.length > 1 ? function(t, n, i) {
					for (var o = e.length; o--;)
						if (!e[o](t, n, i)) return !1;
					return !0
				} : e[0]
			}

			function ye(e, t, n, i, o) {
				for (var r, a = [], s = 0, l = e.length, c = null != t; s < l; s++)(r = e[s]) && (n && !n(r, i, o) || (a.push(r), c && t.push(s)));
				return a
			}

			function be(e, t, n, i, o, r) {
				return i && !i[E] && (i = be(i)), o && !o[E] && (o = be(o, r)), ae(function(r, a, s, l) {
					var c, u, d, f = [],
						p = [],
						h = a.length,
						m = r || function(e, t, n) {
							for (var i = 0, o = t.length; i < o; i++) oe(e, t[i], n);
							return n
						}(t || "*", s.nodeType ? [s] : s, []),
						g = !e || !r && t ? m : ye(m, f, e, s, l),
						v = n ? o || (r ? e : h || i) ? [] : a : g;
					if (n && n(g, v, s, l), i)
						for (c = ye(v, p), i(c, [], s, l), u = c.length; u--;)(d = c[u]) && (v[p[u]] = !(g[p[u]] = d));
					if (r) {
						if (o || e) {
							if (o) {
								for (c = [], u = v.length; u--;)(d = v[u]) && c.push(g[u] = d);
								o(null, v = [], c, l)
							}
							for (u = v.length; u--;)(d = v[u]) && (c = o ? k(r, d) : f[u]) > -1 && (r[c] = !(a[c] = d))
						}
					} else v = ye(v === a ? v.splice(h, v.length) : v), o ? o(null, a, v, l) : _.apply(a, v)
				})
			}

			function Ee(e) {
				for (var t, n, o, r = e.length, a = i.relative[e[0].type], s = a || i.relative[" "], l = a ? 1 : 0, u = ge(function(e) {
						return e === t
					}, s, !0), d = ge(function(e) {
						return k(t, e) > -1
					}, s, !0), f = [function(e, n, i) {
						var o = !a && (i || n !== c) || ((t = n).nodeType ? u(e, n, i) : d(e, n, i));
						return t = null, o
					}]; l < r; l++)
					if (n = i.relative[e[l].type]) f = [ge(ve(f), n)];
					else {
						if ((n = i.filter[e[l].type].apply(null, e[l].matches))[E]) {
							for (o = ++l; o < r && !i.relative[e[o].type]; o++);
							return be(l > 1 && ve(f), l > 1 && me(e.slice(0, l - 1).concat({
								value: " " === e[l - 2].type ? "*" : ""
							})).replace(G, "$1"), n, l < o && Ee(e.slice(l, o)), o < r && Ee(e = e.slice(o)), o < r && me(e))
						}
						f.push(n)
					} return ve(f)
			}
			return he.prototype = i.filters = i.pseudos, i.setFilters = new he, a = oe.tokenize = function(e, t) {
				var n, o, r, a, s, l, c, u = I[e + " "];
				if (u) return t ? 0 : u.slice(0);
				for (s = e, l = [], c = i.preFilter; s;) {
					for (a in n && !(o = B.exec(s)) || (o && (s = s.slice(o[0].length) || s), l.push(r = [])), n = !1, (o = z.exec(s)) && (n = o.shift(), r.push({
							value: n,
							type: o[0].replace(G, " ")
						}), s = s.slice(n.length)), i.filter) !(o = W[a].exec(s)) || c[a] && !(o = c[a](o)) || (n = o.shift(), r.push({
						value: n,
						type: a,
						matches: o
					}), s = s.slice(n.length));
					if (!n) break
				}
				return t ? s.length : s ? oe.error(e) : I(e, l).slice(0)
			}, s = oe.compile = function(e, t) {
				var n, o = [],
					r = [],
					s = x[e + " "];
				if (!s) {
					for (t || (t = a(e)), n = t.length; n--;)(s = Ee(t[n]))[E] ? o.push(s) : r.push(s);
					(s = x(e, function(e, t) {
						var n = t.length > 0,
							o = e.length > 0,
							r = function(r, a, s, l, u) {
								var d, h, g, v = 0,
									y = "0",
									b = r && [],
									E = [],
									T = c,
									S = r || o && i.find.TAG("*", u),
									C = w += null == T ? 1 : Math.random() || .1,
									I = S.length;
								for (u && (c = a === p || a || u); y !== I && null != (d = S[y]); y++) {
									if (o && d) {
										for (h = 0, a || d.ownerDocument === p || (f(d), s = !m); g = e[h++];)
											if (g(d, a || p, s)) {
												l.push(d);
												break
											} u && (w = C)
									}
									n && ((d = !g && d) && v--, r && b.push(d))
								}
								if (v += y, n && y !== v) {
									for (h = 0; g = t[h++];) g(b, E, a, s);
									if (r) {
										if (v > 0)
											for (; y--;) b[y] || E[y] || (E[y] = O.call(l));
										E = ye(E)
									}
									_.apply(l, E), u && !r && E.length > 0 && v + t.length > 1 && oe.uniqueSort(l)
								}
								return u && (w = C, c = T), b
							};
						return n ? ae(r) : r
					}(r, o))).selector = e
				}
				return s
			}, l = oe.select = function(e, t, o, r) {
				var l, c, u, d, f, p = "function" == typeof e && e,
					h = !r && a(e = p.selector || e);
				if (o = o || [], 1 === h.length) {
					if ((c = h[0] = h[0].slice(0)).length > 2 && "ID" === (u = c[0]).type && n.getById && 9 === t.nodeType && m && i.relative[c[1].type]) {
						if (!(t = (i.find.ID(u.matches[0].replace(te, ne), t) || [])[0])) return o;
						p && (t = t.parentNode), e = e.slice(c.shift().value.length)
					}
					for (l = W.needsContext.test(e) ? 0 : c.length; l-- && (u = c[l], !i.relative[d = u.type]);)
						if ((f = i.find[d]) && (r = f(u.matches[0].replace(te, ne), J.test(c[0].type) && pe(t.parentNode) || t))) {
							if (c.splice(l, 1), !(e = r.length && me(c))) return _.apply(o, r), o;
							break
						}
				}
				return (p || s(e, h))(r, t, !m, o, !t || J.test(e) && pe(t.parentNode) || t), o
			}, n.sortStable = E.split("").sort(A).join("") === E, n.detectDuplicates = !!d, f(), n.sortDetached = se(function(e) {
				return 1 & e.compareDocumentPosition(p.createElement("div"))
			}), se(function(e) {
				return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
			}) || le("type|href|height|width", function(e, t, n) {
				if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
			}), n.attributes && se(function(e) {
				return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
			}) || le("value", function(e, t, n) {
				if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue
			}), se(function(e) {
				return null == e.getAttribute("disabled")
			}) || le(U, function(e, t, n) {
				var i;
				if (!n) return !0 === e[t] ? t.toLowerCase() : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
			}), oe
		}(e);
		f.find = y, f.expr = y.selectors, f.expr[":"] = f.expr.pseudos, f.uniqueSort = f.unique = y.uniqueSort, f.text = y.getText, f.isXMLDoc = y.isXML, f.contains = y.contains;
		var b = function(e, t, n) {
				for (var i = [], o = void 0 !== n;
					(e = e[t]) && 9 !== e.nodeType;)
					if (1 === e.nodeType) {
						if (o && f(e).is(n)) break;
						i.push(e)
					} return i
			},
			E = function(e, t) {
				for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
				return n
			},
			T = f.expr.match.needsContext,
			w = /^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,
			S = /^.[^:#\[\.,]*$/;

		function C(e, t, n) {
			if (f.isFunction(t)) return f.grep(e, function(e, i) {
				return !!t.call(e, i, e) !== n
			});
			if (t.nodeType) return f.grep(e, function(e) {
				return e === t !== n
			});
			if ("string" == typeof t) {
				if (S.test(t)) return f.filter(t, e, n);
				t = f.filter(t, e)
			}
			return f.grep(e, function(e) {
				return s.call(t, e) > -1 !== n
			})
		}
		f.filter = function(e, t, n) {
			var i = t[0];
			return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === i.nodeType ? f.find.matchesSelector(i, e) ? [i] : [] : f.find.matches(e, f.grep(t, function(e) {
				return 1 === e.nodeType
			}))
		}, f.fn.extend({
			find: function(e) {
				var t, n = this.length,
					i = [],
					o = this;
				if ("string" != typeof e) return this.pushStack(f(e).filter(function() {
					for (t = 0; t < n; t++)
						if (f.contains(o[t], this)) return !0
				}));
				for (t = 0; t < n; t++) f.find(e, o[t], i);
				return (i = this.pushStack(n > 1 ? f.unique(i) : i)).selector = this.selector ? this.selector + " " + e : e, i
			},
			filter: function(e) {
				return this.pushStack(C(this, e || [], !1))
			},
			not: function(e) {
				return this.pushStack(C(this, e || [], !0))
			},
			is: function(e) {
				return !!C(this, "string" == typeof e && T.test(e) ? f(e) : e || [], !1).length
			}
		});
		var I, x = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/;
		(f.fn.init = function(e, t, n) {
			var o, r;
			if (!e) return this;
			if (n = n || I, "string" == typeof e) {
				if (!(o = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : x.exec(e)) || !o[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
				if (o[1]) {
					if (t = t instanceof f ? t[0] : t, f.merge(this, f.parseHTML(o[1], t && t.nodeType ? t.ownerDocument || t : i, !0)), w.test(o[1]) && f.isPlainObject(t))
						for (o in t) f.isFunction(this[o]) ? this[o](t[o]) : this.attr(o, t[o]);
					return this
				}
				return (r = i.getElementById(o[2])) && r.parentNode && (this.length = 1, this[0] = r), this.context = i, this.selector = e, this
			}
			return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : f.isFunction(e) ? void 0 !== n.ready ? n.ready(e) : e(f) : (void 0 !== e.selector && (this.selector = e.selector, this.context = e.context), f.makeArray(e, this))
		}).prototype = f.fn, I = f(i);
		var A = /^(?:parents|prev(?:Until|All))/,
			D = {
				children: !0,
				contents: !0,
				next: !0,
				prev: !0
			};

		function L(e, t) {
			for (;
				(e = e[t]) && 1 !== e.nodeType;);
			return e
		}
		f.fn.extend({
			has: function(e) {
				var t = f(e, this),
					n = t.length;
				return this.filter(function() {
					for (var e = 0; e < n; e++)
						if (f.contains(this, t[e])) return !0
				})
			},
			closest: function(e, t) {
				for (var n, i = 0, o = this.length, r = [], a = T.test(e) || "string" != typeof e ? f(e, t || this.context) : 0; i < o; i++)
					for (n = this[i]; n && n !== t; n = n.parentNode)
						if (n.nodeType < 11 && (a ? a.index(n) > -1 : 1 === n.nodeType && f.find.matchesSelector(n, e))) {
							r.push(n);
							break
						} return this.pushStack(r.length > 1 ? f.uniqueSort(r) : r)
			},
			index: function(e) {
				return e ? "string" == typeof e ? s.call(f(e), this[0]) : s.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
			},
			add: function(e, t) {
				return this.pushStack(f.uniqueSort(f.merge(this.get(), f(e, t))))
			},
			addBack: function(e) {
				return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
			}
		}), f.each({
			parent: function(e) {
				var t = e.parentNode;
				return t && 11 !== t.nodeType ? t : null
			},
			parents: function(e) {
				return b(e, "parentNode")
			},
			parentsUntil: function(e, t, n) {
				return b(e, "parentNode", n)
			},
			next: function(e) {
				return L(e, "nextSibling")
			},
			prev: function(e) {
				return L(e, "previousSibling")
			},
			nextAll: function(e) {
				return b(e, "nextSibling")
			},
			prevAll: function(e) {
				return b(e, "previousSibling")
			},
			nextUntil: function(e, t, n) {
				return b(e, "nextSibling", n)
			},
			prevUntil: function(e, t, n) {
				return b(e, "previousSibling", n)
			},
			siblings: function(e) {
				return E((e.parentNode || {}).firstChild, e)
			},
			children: function(e) {
				return E(e.firstChild)
			},
			contents: function(e) {
				return e.contentDocument || f.merge([], e.childNodes)
			}
		}, function(e, t) {
			f.fn[e] = function(n, i) {
				var o = f.map(this, t, n);
				return "Until" !== e.slice(-5) && (i = n), i && "string" == typeof i && (o = f.filter(i, o)), this.length > 1 && (D[e] || f.uniqueSort(o), A.test(e) && o.reverse()), this.pushStack(o)
			}
		});
		var N, O = /\S+/g;

		function M() {
			i.removeEventListener("DOMContentLoaded", M), e.removeEventListener("load", M), f.ready()
		}
		f.Callbacks = function(e) {
			e = "string" == typeof e ? function(e) {
				var t = {};
				return f.each(e.match(O) || [], function(e, n) {
					t[n] = !0
				}), t
			}(e) : f.extend({}, e);
			var t, n, i, o, r = [],
				a = [],
				s = -1,
				l = function() {
					for (o = e.once, i = t = !0; a.length; s = -1)
						for (n = a.shift(); ++s < r.length;) !1 === r[s].apply(n[0], n[1]) && e.stopOnFalse && (s = r.length, n = !1);
					e.memory || (n = !1), t = !1, o && (r = n ? [] : "")
				},
				c = {
					add: function() {
						return r && (n && !t && (s = r.length - 1, a.push(n)), function t(n) {
							f.each(n, function(n, i) {
								f.isFunction(i) ? e.unique && c.has(i) || r.push(i) : i && i.length && "string" !== f.type(i) && t(i)
							})
						}(arguments), n && !t && l()), this
					},
					remove: function() {
						return f.each(arguments, function(e, t) {
							for (var n;
								(n = f.inArray(t, r, n)) > -1;) r.splice(n, 1), n <= s && s--
						}), this
					},
					has: function(e) {
						return e ? f.inArray(e, r) > -1 : r.length > 0
					},
					empty: function() {
						return r && (r = []), this
					},
					disable: function() {
						return o = a = [], r = n = "", this
					},
					disabled: function() {
						return !r
					},
					lock: function() {
						return o = a = [], n || (r = n = ""), this
					},
					locked: function() {
						return !!o
					},
					fireWith: function(e, n) {
						return o || (n = [e, (n = n || []).slice ? n.slice() : n], a.push(n), t || l()), this
					},
					fire: function() {
						return c.fireWith(this, arguments), this
					},
					fired: function() {
						return !!i
					}
				};
			return c
		}, f.extend({
			Deferred: function(e) {
				var t = [
						["resolve", "done", f.Callbacks("once memory"), "resolved"],
						["reject", "fail", f.Callbacks("once memory"), "rejected"],
						["notify", "progress", f.Callbacks("memory")]
					],
					n = "pending",
					i = {
						state: function() {
							return n
						},
						always: function() {
							return o.done(arguments).fail(arguments), this
						},
						then: function() {
							var e = arguments;
							return f.Deferred(function(n) {
								f.each(t, function(t, r) {
									var a = f.isFunction(e[t]) && e[t];
									o[r[1]](function() {
										var e = a && a.apply(this, arguments);
										e && f.isFunction(e.promise) ? e.promise().progress(n.notify).done(n.resolve).fail(n.reject) : n[r[0] + "With"](this === i ? n.promise() : this, a ? [e] : arguments)
									})
								}), e = null
							}).promise()
						},
						promise: function(e) {
							return null != e ? f.extend(e, i) : i
						}
					},
					o = {};
				return i.pipe = i.then, f.each(t, function(e, r) {
					var a = r[2],
						s = r[3];
					i[r[1]] = a.add, s && a.add(function() {
						n = s
					}, t[1 ^ e][2].disable, t[2][2].lock), o[r[0]] = function() {
						return o[r[0] + "With"](this === o ? i : this, arguments), this
					}, o[r[0] + "With"] = a.fireWith
				}), i.promise(o), e && e.call(o, o), o
			},
			when: function(e) {
				var t, n, i, r = 0,
					a = o.call(arguments),
					s = a.length,
					l = 1 !== s || e && f.isFunction(e.promise) ? s : 0,
					c = 1 === l ? e : f.Deferred(),
					u = function(e, n, i) {
						return function(r) {
							n[e] = this, i[e] = arguments.length > 1 ? o.call(arguments) : r, i === t ? c.notifyWith(n, i) : --l || c.resolveWith(n, i)
						}
					};
				if (s > 1)
					for (t = new Array(s), n = new Array(s), i = new Array(s); r < s; r++) a[r] && f.isFunction(a[r].promise) ? a[r].promise().progress(u(r, n, t)).done(u(r, i, a)).fail(c.reject) : --l;
				return l || c.resolveWith(i, a), c.promise()
			}
		}), f.fn.ready = function(e) {
			return f.ready.promise().done(e), this
		}, f.extend({
			isReady: !1,
			readyWait: 1,
			holdReady: function(e) {
				e ? f.readyWait++ : f.ready(!0)
			},
			ready: function(e) {
				(!0 === e ? --f.readyWait : f.isReady) || (f.isReady = !0, !0 !== e && --f.readyWait > 0 || (N.resolveWith(i, [f]), f.fn.triggerHandler && (f(i).triggerHandler("ready"), f(i).off("ready"))))
			}
		}), f.ready.promise = function(t) {
			return N || (N = f.Deferred(), "complete" === i.readyState || "loading" !== i.readyState && !i.documentElement.doScroll ? e.setTimeout(f.ready) : (i.addEventListener("DOMContentLoaded", M), e.addEventListener("load", M))), N.promise(t)
		}, f.ready.promise();
		var _ = function(e, t, n, i, o, r, a) {
				var s = 0,
					l = e.length,
					c = null == n;
				if ("object" === f.type(n))
					for (s in o = !0, n) _(e, t, s, n[s], !0, r, a);
				else if (void 0 !== i && (o = !0, f.isFunction(i) || (a = !0), c && (a ? (t.call(e, i), t = null) : (c = t, t = function(e, t, n) {
						return c.call(f(e), n)
					})), t))
					for (; s < l; s++) t(e[s], n, a ? i : i.call(e[s], s, t(e[s], n)));
				return o ? e : c ? t.call(e) : l ? t(e[0], n) : r
			},
			R = function(e) {
				return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
			};

		function k() {
			this.expando = f.expando + k.uid++
		}
		k.uid = 1, k.prototype = {
			register: function(e, t) {
				var n = t || {};
				return e.nodeType ? e[this.expando] = n : Object.defineProperty(e, this.expando, {
					value: n,
					writable: !0,
					configurable: !0
				}), e[this.expando]
			},
			cache: function(e) {
				if (!R(e)) return {};
				var t = e[this.expando];
				return t || (t = {}, R(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
					value: t,
					configurable: !0
				}))), t
			},
			set: function(e, t, n) {
				var i, o = this.cache(e);
				if ("string" == typeof t) o[t] = n;
				else
					for (i in t) o[i] = t[i];
				return o
			},
			get: function(e, t) {
				return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][t]
			},
			access: function(e, t, n) {
				var i;
				return void 0 === t || t && "string" == typeof t && void 0 === n ? void 0 !== (i = this.get(e, t)) ? i : this.get(e, f.camelCase(t)) : (this.set(e, t, n), void 0 !== n ? n : t)
			},
			remove: function(e, t) {
				var n, i, o, r = e[this.expando];
				if (void 0 !== r) {
					if (void 0 === t) this.register(e);
					else {
						f.isArray(t) ? i = t.concat(t.map(f.camelCase)) : (o = f.camelCase(t), i = t in r ? [t, o] : (i = o) in r ? [i] : i.match(O) || []), n = i.length;
						for (; n--;) delete r[i[n]]
					}(void 0 === t || f.isEmptyObject(r)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
				}
			},
			hasData: function(e) {
				var t = e[this.expando];
				return void 0 !== t && !f.isEmptyObject(t)
			}
		};
		var U = new k,
			P = new k,
			F = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
			H = /[A-Z]/g;

		function q(e, t, n) {
			var i;
			if (void 0 === n && 1 === e.nodeType)
				if (i = "data-" + t.replace(H, "-$&").toLowerCase(), "string" == typeof(n = e.getAttribute(i))) {
					try {
						n = "true" === n || "false" !== n && ("null" === n ? null : +n + "" === n ? +n : F.test(n) ? f.parseJSON(n) : n)
					} catch (e) {}
					P.set(e, t, n)
				} else n = void 0;
			return n
		}
		f.extend({
			hasData: function(e) {
				return P.hasData(e) || U.hasData(e)
			},
			data: function(e, t, n) {
				return P.access(e, t, n)
			},
			removeData: function(e, t) {
				P.remove(e, t)
			},
			_data: function(e, t, n) {
				return U.access(e, t, n)
			},
			_removeData: function(e, t) {
				U.remove(e, t)
			}
		}), f.fn.extend({
			data: function(e, t) {
				var n, i, o, r = this[0],
					a = r && r.attributes;
				if (void 0 === e) {
					if (this.length && (o = P.get(r), 1 === r.nodeType && !U.get(r, "hasDataAttrs"))) {
						for (n = a.length; n--;) a[n] && 0 === (i = a[n].name).indexOf("data-") && (i = f.camelCase(i.slice(5)), q(r, i, o[i]));
						U.set(r, "hasDataAttrs", !0)
					}
					return o
				}
				return "object" == typeof e ? this.each(function() {
					P.set(this, e)
				}) : _(this, function(t) {
					var n, i;
					if (r && void 0 === t) return void 0 !== (n = P.get(r, e) || P.get(r, e.replace(H, "-$&").toLowerCase())) ? n : (i = f.camelCase(e), void 0 !== (n = P.get(r, i)) ? n : void 0 !== (n = q(r, i, void 0)) ? n : void 0);
					i = f.camelCase(e), this.each(function() {
						var n = P.get(this, i);
						P.set(this, i, t), e.indexOf("-") > -1 && void 0 !== n && P.set(this, e, t)
					})
				}, null, t, arguments.length > 1, null, !0)
			},
			removeData: function(e) {
				return this.each(function() {
					P.remove(this, e)
				})
			}
		}), f.extend({
			queue: function(e, t, n) {
				var i;
				if (e) return t = (t || "fx") + "queue", i = U.get(e, t), n && (!i || f.isArray(n) ? i = U.access(e, t, f.makeArray(n)) : i.push(n)), i || []
			},
			dequeue: function(e, t) {
				t = t || "fx";
				var n = f.queue(e, t),
					i = n.length,
					o = n.shift(),
					r = f._queueHooks(e, t);
				"inprogress" === o && (o = n.shift(), i--), o && ("fx" === t && n.unshift("inprogress"), delete r.stop, o.call(e, function() {
					f.dequeue(e, t)
				}, r)), !i && r && r.empty.fire()
			},
			_queueHooks: function(e, t) {
				var n = t + "queueHooks";
				return U.get(e, n) || U.access(e, n, {
					empty: f.Callbacks("once memory").add(function() {
						U.remove(e, [t + "queue", n])
					})
				})
			}
		}), f.fn.extend({
			queue: function(e, t) {
				var n = 2;
				return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? f.queue(this[0], e) : void 0 === t ? this : this.each(function() {
					var n = f.queue(this, e, t);
					f._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && f.dequeue(this, e)
				})
			},
			dequeue: function(e) {
				return this.each(function() {
					f.dequeue(this, e)
				})
			},
			clearQueue: function(e) {
				return this.queue(e || "fx", [])
			},
			promise: function(e, t) {
				var n, i = 1,
					o = f.Deferred(),
					r = this,
					a = this.length,
					s = function() {
						--i || o.resolveWith(r, [r])
					};
				for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;)(n = U.get(r[a], e + "queueHooks")) && n.empty && (i++, n.empty.add(s));
				return s(), o.promise(t)
			}
		});
		var $ = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
			G = new RegExp("^(?:([+-])=|)(" + $ + ")([a-z%]*)$", "i"),
			B = ["Top", "Right", "Bottom", "Left"],
			z = function(e, t) {
				return e = t || e, "none" === f.css(e, "display") || !f.contains(e.ownerDocument, e)
			};

		function Y(e, t, n, i) {
			var o, r = 1,
				a = 20,
				s = i ? function() {
					return i.cur()
				} : function() {
					return f.css(e, t, "")
				},
				l = s(),
				c = n && n[3] || (f.cssNumber[t] ? "" : "px"),
				u = (f.cssNumber[t] || "px" !== c && +l) && G.exec(f.css(e, t));
			if (u && u[3] !== c) {
				c = c || u[3], n = n || [], u = +l || 1;
				do {
					u /= r = r || ".5", f.style(e, t, u + c)
				} while (r !== (r = s() / l) && 1 !== r && --a)
			}
			return n && (u = +u || +l || 0, o = n[1] ? u + (n[1] + 1) * n[2] : +n[2], i && (i.unit = c, i.start = u, i.end = o)), o
		}
		var j = /^(?:checkbox|radio)$/i,
			K = /<([\w:-]+)/,
			W = /^$|\/(?:java|ecma)script/i,
			V = {
				option: [1, "<select multiple='multiple'>", "</select>"],
				thead: [1, "<table>", "</table>"],
				col: [2, "<table><colgroup>", "</colgroup></table>"],
				tr: [2, "<table><tbody>", "</tbody></table>"],
				td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
				_default: [0, "", ""]
			};

		function X(e, t) {
			var n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : [];
			return void 0 === t || t && f.nodeName(e, t) ? f.merge([e], n) : n
		}

		function Z(e, t) {
			for (var n = 0, i = e.length; n < i; n++) U.set(e[n], "globalEval", !t || U.get(t[n], "globalEval"))
		}
		V.optgroup = V.option, V.tbody = V.tfoot = V.colgroup = V.caption = V.thead, V.th = V.td;
		var Q, J, ee = /<|&#?\w+;/;

		function te(e, t, n, i, o) {
			for (var r, a, s, l, c, u, d = t.createDocumentFragment(), p = [], h = 0, m = e.length; h < m; h++)
				if ((r = e[h]) || 0 === r)
					if ("object" === f.type(r)) f.merge(p, r.nodeType ? [r] : r);
					else if (ee.test(r)) {
				for (a = a || d.appendChild(t.createElement("div")), s = (K.exec(r) || ["", ""])[1].toLowerCase(), l = V[s] || V._default, a.innerHTML = l[1] + f.htmlPrefilter(r) + l[2], u = l[0]; u--;) a = a.lastChild;
				f.merge(p, a.childNodes), (a = d.firstChild).textContent = ""
			} else p.push(t.createTextNode(r));
			for (d.textContent = "", h = 0; r = p[h++];)
				if (i && f.inArray(r, i) > -1) o && o.push(r);
				else if (c = f.contains(r.ownerDocument, r), a = X(d.appendChild(r), "script"), c && Z(a), n)
				for (u = 0; r = a[u++];) W.test(r.type || "") && n.push(r);
			return d
		}
		Q = i.createDocumentFragment().appendChild(i.createElement("div")), (J = i.createElement("input")).setAttribute("type", "radio"), J.setAttribute("checked", "checked"), J.setAttribute("name", "t"), Q.appendChild(J), d.checkClone = Q.cloneNode(!0).cloneNode(!0).lastChild.checked, Q.innerHTML = "<textarea>x</textarea>", d.noCloneChecked = !!Q.cloneNode(!0).lastChild.defaultValue;
		var ne = /^key/,
			ie = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
			oe = /^([^.]*)(?:\.(.+)|)/;

		function re() {
			return !0
		}

		function ae() {
			return !1
		}

		function se() {
			try {
				return i.activeElement
			} catch (e) {}
		}

		function le(e, t, n, i, o, r) {
			var a, s;
			if ("object" == typeof t) {
				for (s in "string" != typeof n && (i = i || n, n = void 0), t) le(e, s, n, i, t[s], r);
				return e
			}
			if (null == i && null == o ? (o = n, i = n = void 0) : null == o && ("string" == typeof n ? (o = i, i = void 0) : (o = i, i = n, n = void 0)), !1 === o) o = ae;
			else if (!o) return e;
			return 1 === r && (a = o, (o = function(e) {
				return f().off(e), a.apply(this, arguments)
			}).guid = a.guid || (a.guid = f.guid++)), e.each(function() {
				f.event.add(this, t, o, i, n)
			})
		}
		f.event = {
			global: {},
			add: function(e, t, n, i, o) {
				var r, a, s, l, c, u, d, p, h, m, g, v = U.get(e);
				if (v)
					for (n.handler && (n = (r = n).handler, o = r.selector), n.guid || (n.guid = f.guid++), (l = v.events) || (l = v.events = {}), (a = v.handle) || (a = v.handle = function(t) {
							return void 0 !== f && f.event.triggered !== t.type ? f.event.dispatch.apply(e, arguments) : void 0
						}), c = (t = (t || "").match(O) || [""]).length; c--;) h = g = (s = oe.exec(t[c]) || [])[1], m = (s[2] || "").split(".").sort(), h && (d = f.event.special[h] || {}, h = (o ? d.delegateType : d.bindType) || h, d = f.event.special[h] || {}, u = f.extend({
						type: h,
						origType: g,
						data: i,
						handler: n,
						guid: n.guid,
						selector: o,
						needsContext: o && f.expr.match.needsContext.test(o),
						namespace: m.join(".")
					}, r), (p = l[h]) || ((p = l[h] = []).delegateCount = 0, d.setup && !1 !== d.setup.call(e, i, m, a) || e.addEventListener && e.addEventListener(h, a)), d.add && (d.add.call(e, u), u.handler.guid || (u.handler.guid = n.guid)), o ? p.splice(p.delegateCount++, 0, u) : p.push(u), f.event.global[h] = !0)
			},
			remove: function(e, t, n, i, o) {
				var r, a, s, l, c, u, d, p, h, m, g, v = U.hasData(e) && U.get(e);
				if (v && (l = v.events)) {
					for (c = (t = (t || "").match(O) || [""]).length; c--;)
						if (h = g = (s = oe.exec(t[c]) || [])[1], m = (s[2] || "").split(".").sort(), h) {
							for (d = f.event.special[h] || {}, p = l[h = (i ? d.delegateType : d.bindType) || h] || [], s = s[2] && new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = r = p.length; r--;) u = p[r], !o && g !== u.origType || n && n.guid !== u.guid || s && !s.test(u.namespace) || i && i !== u.selector && ("**" !== i || !u.selector) || (p.splice(r, 1), u.selector && p.delegateCount--, d.remove && d.remove.call(e, u));
							a && !p.length && (d.teardown && !1 !== d.teardown.call(e, m, v.handle) || f.removeEvent(e, h, v.handle), delete l[h])
						} else
							for (h in l) f.event.remove(e, h + t[c], n, i, !0);
					f.isEmptyObject(l) && U.remove(e, "handle events")
				}
			},
			dispatch: function(e) {
				e = f.event.fix(e);
				var t, n, i, r, a, s, l = o.call(arguments),
					c = (U.get(this, "events") || {})[e.type] || [],
					u = f.event.special[e.type] || {};
				if (l[0] = e, e.delegateTarget = this, !u.preDispatch || !1 !== u.preDispatch.call(this, e)) {
					for (s = f.event.handlers.call(this, e, c), t = 0;
						(r = s[t++]) && !e.isPropagationStopped();)
						for (e.currentTarget = r.elem, n = 0;
							(a = r.handlers[n++]) && !e.isImmediatePropagationStopped();) e.rnamespace && !e.rnamespace.test(a.namespace) || (e.handleObj = a, e.data = a.data, void 0 !== (i = ((f.event.special[a.origType] || {}).handle || a.handler).apply(r.elem, l)) && !1 === (e.result = i) && (e.preventDefault(), e.stopPropagation()));
					return u.postDispatch && u.postDispatch.call(this, e), e.result
				}
			},
			handlers: function(e, t) {
				var n, i, o, r, a = [],
					s = t.delegateCount,
					l = e.target;
				if (s && l.nodeType && ("click" !== e.type || isNaN(e.button) || e.button < 1))
					for (; l !== this; l = l.parentNode || this)
						if (1 === l.nodeType && (!0 !== l.disabled || "click" !== e.type)) {
							for (i = [], n = 0; n < s; n++) void 0 === i[o = (r = t[n]).selector + " "] && (i[o] = r.needsContext ? f(o, this).index(l) > -1 : f.find(o, this, null, [l]).length), i[o] && i.push(r);
							i.length && a.push({
								elem: l,
								handlers: i
							})
						} return s < t.length && a.push({
					elem: this,
					handlers: t.slice(s)
				}), a
			},
			props: "altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
			fixHooks: {},
			keyHooks: {
				props: "char charCode key keyCode".split(" "),
				filter: function(e, t) {
					return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
				}
			},
			mouseHooks: {
				props: "button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
				filter: function(e, t) {
					var n, o, r, a = t.button;
					return null == e.pageX && null != t.clientX && (o = (n = e.target.ownerDocument || i).documentElement, r = n.body, e.pageX = t.clientX + (o && o.scrollLeft || r && r.scrollLeft || 0) - (o && o.clientLeft || r && r.clientLeft || 0), e.pageY = t.clientY + (o && o.scrollTop || r && r.scrollTop || 0) - (o && o.clientTop || r && r.clientTop || 0)), e.which || void 0 === a || (e.which = 1 & a ? 1 : 2 & a ? 3 : 4 & a ? 2 : 0), e
				}
			},
			fix: function(e) {
				if (e[f.expando]) return e;
				var t, n, o, r = e.type,
					a = e,
					s = this.fixHooks[r];
				for (s || (this.fixHooks[r] = s = ie.test(r) ? this.mouseHooks : ne.test(r) ? this.keyHooks : {}), o = s.props ? this.props.concat(s.props) : this.props, e = new f.Event(a), t = o.length; t--;) e[n = o[t]] = a[n];
				return e.target || (e.target = i), 3 === e.target.nodeType && (e.target = e.target.parentNode), s.filter ? s.filter(e, a) : e
			},
			special: {
				load: {
					noBubble: !0
				},
				focus: {
					trigger: function() {
						if (this !== se() && this.focus) return this.focus(), !1
					},
					delegateType: "focusin"
				},
				blur: {
					trigger: function() {
						if (this === se() && this.blur) return this.blur(), !1
					},
					delegateType: "focusout"
				},
				click: {
					trigger: function() {
						if ("checkbox" === this.type && this.click && f.nodeName(this, "input")) return this.click(), !1
					},
					_default: function(e) {
						return f.nodeName(e.target, "a")
					}
				},
				beforeunload: {
					postDispatch: function(e) {
						void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
					}
				}
			}
		}, f.removeEvent = function(e, t, n) {
			e.removeEventListener && e.removeEventListener(t, n)
		}, f.Event = function(e, t) {
			if (!(this instanceof f.Event)) return new f.Event(e, t);
			e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? re : ae) : this.type = e, t && f.extend(this, t), this.timeStamp = e && e.timeStamp || f.now(), this[f.expando] = !0
		}, f.Event.prototype = {
			constructor: f.Event,
			isDefaultPrevented: ae,
			isPropagationStopped: ae,
			isImmediatePropagationStopped: ae,
			isSimulated: !1,
			preventDefault: function() {
				var e = this.originalEvent;
				this.isDefaultPrevented = re, e && !this.isSimulated && e.preventDefault()
			},
			stopPropagation: function() {
				var e = this.originalEvent;
				this.isPropagationStopped = re, e && !this.isSimulated && e.stopPropagation()
			},
			stopImmediatePropagation: function() {
				var e = this.originalEvent;
				this.isImmediatePropagationStopped = re, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
			}
		}, f.each({
			mouseenter: "mouseover",
			mouseleave: "mouseout",
			pointerenter: "pointerover",
			pointerleave: "pointerout"
		}, function(e, t) {
			f.event.special[e] = {
				delegateType: t,
				bindType: t,
				handle: function(e) {
					var n, i = e.relatedTarget,
						o = e.handleObj;
					return i && (i === this || f.contains(this, i)) || (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t), n
				}
			}
		}), f.fn.extend({
			on: function(e, t, n, i) {
				return le(this, e, t, n, i)
			},
			one: function(e, t, n, i) {
				return le(this, e, t, n, i, 1)
			},
			off: function(e, t, n) {
				var i, o;
				if (e && e.preventDefault && e.handleObj) return i = e.handleObj, f(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
				if ("object" == typeof e) {
					for (o in e) this.off(o, t, e[o]);
					return this
				}
				return !1 !== t && "function" != typeof t || (n = t, t = void 0), !1 === n && (n = ae), this.each(function() {
					f.event.remove(this, e, n, t)
				})
			}
		});
		var ce = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,
			ue = /<script|<style|<link/i,
			de = /checked\s*(?:[^=]|=\s*.checked.)/i,
			fe = /^true\/(.*)/,
			pe = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;

		function he(e, t) {
			return f.nodeName(e, "table") && f.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
		}

		function me(e) {
			return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
		}

		function ge(e) {
			var t = fe.exec(e.type);
			return t ? e.type = t[1] : e.removeAttribute("type"), e
		}

		function ve(e, t) {
			var n, i, o, r, a, s, l, c;
			if (1 === t.nodeType) {
				if (U.hasData(e) && (r = U.access(e), a = U.set(t, r), c = r.events))
					for (o in delete a.handle, a.events = {}, c)
						for (n = 0, i = c[o].length; n < i; n++) f.event.add(t, o, c[o][n]);
				P.hasData(e) && (s = P.access(e), l = f.extend({}, s), P.set(t, l))
			}
		}

		function ye(e, t, n, i) {
			t = r.apply([], t);
			var o, a, s, l, c, u, p = 0,
				h = e.length,
				m = h - 1,
				g = t[0],
				v = f.isFunction(g);
			if (v || h > 1 && "string" == typeof g && !d.checkClone && de.test(g)) return e.each(function(o) {
				var r = e.eq(o);
				v && (t[0] = g.call(this, o, r.html())), ye(r, t, n, i)
			});
			if (h && (a = (o = te(t, e[0].ownerDocument, !1, e, i)).firstChild, 1 === o.childNodes.length && (o = a), a || i)) {
				for (l = (s = f.map(X(o, "script"), me)).length; p < h; p++) c = o, p !== m && (c = f.clone(c, !0, !0), l && f.merge(s, X(c, "script"))), n.call(e[p], c, p);
				if (l)
					for (u = s[s.length - 1].ownerDocument, f.map(s, ge), p = 0; p < l; p++) c = s[p], W.test(c.type || "") && !U.access(c, "globalEval") && f.contains(u, c) && (c.src ? f._evalUrl && f._evalUrl(c.src) : f.globalEval(c.textContent.replace(pe, "")))
			}
			return e
		}

		function be(e, t, n) {
			for (var i, o = t ? f.filter(t, e) : e, r = 0; null != (i = o[r]); r++) n || 1 !== i.nodeType || f.cleanData(X(i)), i.parentNode && (n && f.contains(i.ownerDocument, i) && Z(X(i, "script")), i.parentNode.removeChild(i));
			return e
		}
		f.extend({
			htmlPrefilter: function(e) {
				return e.replace(ce, "<$1></$2>")
			},
			clone: function(e, t, n) {
				var i, o, r, a, s, l, c, u = e.cloneNode(!0),
					p = f.contains(e.ownerDocument, e);
				if (!(d.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || f.isXMLDoc(e)))
					for (a = X(u), i = 0, o = (r = X(e)).length; i < o; i++) s = r[i], l = a[i], void 0, "input" === (c = l.nodeName.toLowerCase()) && j.test(s.type) ? l.checked = s.checked : "input" !== c && "textarea" !== c || (l.defaultValue = s.defaultValue);
				if (t)
					if (n)
						for (r = r || X(e), a = a || X(u), i = 0, o = r.length; i < o; i++) ve(r[i], a[i]);
					else ve(e, u);
				return (a = X(u, "script")).length > 0 && Z(a, !p && X(e, "script")), u
			},
			cleanData: function(e) {
				for (var t, n, i, o = f.event.special, r = 0; void 0 !== (n = e[r]); r++)
					if (R(n)) {
						if (t = n[U.expando]) {
							if (t.events)
								for (i in t.events) o[i] ? f.event.remove(n, i) : f.removeEvent(n, i, t.handle);
							n[U.expando] = void 0
						}
						n[P.expando] && (n[P.expando] = void 0)
					}
			}
		}), f.fn.extend({
			domManip: ye,
			detach: function(e) {
				return be(this, e, !0)
			},
			remove: function(e) {
				return be(this, e)
			},
			text: function(e) {
				return _(this, function(e) {
					return void 0 === e ? f.text(this) : this.empty().each(function() {
						1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e)
					})
				}, null, e, arguments.length)
			},
			append: function() {
				return ye(this, arguments, function(e) {
					1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || he(this, e).appendChild(e)
				})
			},
			prepend: function() {
				return ye(this, arguments, function(e) {
					if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
						var t = he(this, e);
						t.insertBefore(e, t.firstChild)
					}
				})
			},
			before: function() {
				return ye(this, arguments, function(e) {
					this.parentNode && this.parentNode.insertBefore(e, this)
				})
			},
			after: function() {
				return ye(this, arguments, function(e) {
					this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
				})
			},
			empty: function() {
				for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (f.cleanData(X(e, !1)), e.textContent = "");
				return this
			},
			clone: function(e, t) {
				return e = null != e && e, t = null == t ? e : t, this.map(function() {
					return f.clone(this, e, t)
				})
			},
			html: function(e) {
				return _(this, function(e) {
					var t = this[0] || {},
						n = 0,
						i = this.length;
					if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
					if ("string" == typeof e && !ue.test(e) && !V[(K.exec(e) || ["", ""])[1].toLowerCase()]) {
						e = f.htmlPrefilter(e);
						try {
							for (; n < i; n++) 1 === (t = this[n] || {}).nodeType && (f.cleanData(X(t, !1)), t.innerHTML = e);
							t = 0
						} catch (e) {}
					}
					t && this.empty().append(e)
				}, null, e, arguments.length)
			},
			replaceWith: function() {
				var e = [];
				return ye(this, arguments, function(t) {
					var n = this.parentNode;
					f.inArray(this, e) < 0 && (f.cleanData(X(this)), n && n.replaceChild(t, this))
				}, e)
			}
		}), f.each({
			appendTo: "append",
			prependTo: "prepend",
			insertBefore: "before",
			insertAfter: "after",
			replaceAll: "replaceWith"
		}, function(e, t) {
			f.fn[e] = function(e) {
				for (var n, i = [], o = f(e), r = o.length - 1, s = 0; s <= r; s++) n = s === r ? this : this.clone(!0), f(o[s])[t](n), a.apply(i, n.get());
				return this.pushStack(i)
			}
		});
		var Ee, Te = {
			HTML: "block",
			BODY: "block"
		};

		function we(e, t) {
			var n = f(t.createElement(e)).appendTo(t.body),
				i = f.css(n[0], "display");
			return n.detach(), i
		}

		function Se(e) {
			var t = i,
				n = Te[e];
			return n || ("none" !== (n = we(e, t)) && n || ((t = (Ee = (Ee || f("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement))[0].contentDocument).write(), t.close(), n = we(e, t), Ee.detach()), Te[e] = n), n
		}
		var Ce = /^margin/,
			Ie = new RegExp("^(" + $ + ")(?!px)[a-z%]+$", "i"),
			xe = function(t) {
				var n = t.ownerDocument.defaultView;
				return n && n.opener || (n = e), n.getComputedStyle(t)
			},
			Ae = function(e, t, n, i) {
				var o, r, a = {};
				for (r in t) a[r] = e.style[r], e.style[r] = t[r];
				for (r in o = n.apply(e, i || []), t) e.style[r] = a[r];
				return o
			},
			De = i.documentElement;

		function Le(e, t, n) {
			var i, o, r, a, s = e.style;
			return "" !== (a = (n = n || xe(e)) ? n.getPropertyValue(t) || n[t] : void 0) && void 0 !== a || f.contains(e.ownerDocument, e) || (a = f.style(e, t)), n && !d.pixelMarginRight() && Ie.test(a) && Ce.test(t) && (i = s.width, o = s.minWidth, r = s.maxWidth, s.minWidth = s.maxWidth = s.width = a, a = n.width, s.width = i, s.minWidth = o, s.maxWidth = r), void 0 !== a ? a + "" : a
		}

		function Ne(e, t) {
			return {
				get: function() {
					if (!e()) return (this.get = t).apply(this, arguments);
					delete this.get
				}
			}
		}! function() {
			var t, n, o, r, a = i.createElement("div"),
				s = i.createElement("div");

			function l() {
				s.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", s.innerHTML = "", De.appendChild(a);
				var i = e.getComputedStyle(s);
				t = "1%" !== i.top, r = "2px" === i.marginLeft, n = "4px" === i.width, s.style.marginRight = "50%", o = "4px" === i.marginRight, De.removeChild(a)
			}
			s.style && (s.style.backgroundClip = "content-box", s.cloneNode(!0).style.backgroundClip = "", d.clearCloneStyle = "content-box" === s.style.backgroundClip, a.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", a.appendChild(s), f.extend(d, {
				pixelPosition: function() {
					return l(), t
				},
				boxSizingReliable: function() {
					return null == n && l(), n
				},
				pixelMarginRight: function() {
					return null == n && l(), o
				},
				reliableMarginLeft: function() {
					return null == n && l(), r
				},
				reliableMarginRight: function() {
					var t, n = s.appendChild(i.createElement("div"));
					return n.style.cssText = s.style.cssText = "-webkit-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", n.style.marginRight = n.style.width = "0", s.style.width = "1px", De.appendChild(a), t = !parseFloat(e.getComputedStyle(n).marginRight), De.removeChild(a), s.removeChild(n), t
				}
			}))
		}();
		var Oe = /^(none|table(?!-c[ea]).+)/,
			Me = {
				position: "absolute",
				visibility: "hidden",
				display: "block"
			},
			_e = {
				letterSpacing: "0",
				fontWeight: "400"
			},
			Re = ["Webkit", "O", "Moz", "ms"],
			ke = i.createElement("div").style;

		function Ue(e) {
			if (e in ke) return e;
			for (var t = e[0].toUpperCase() + e.slice(1), n = Re.length; n--;)
				if ((e = Re[n] + t) in ke) return e
		}

		function Pe(e, t, n) {
			var i = G.exec(t);
			return i ? Math.max(0, i[2] - (n || 0)) + (i[3] || "px") : t
		}

		function Fe(e, t, n, i, o) {
			for (var r = n === (i ? "border" : "content") ? 4 : "width" === t ? 1 : 0, a = 0; r < 4; r += 2) "margin" === n && (a += f.css(e, n + B[r], !0, o)), i ? ("content" === n && (a -= f.css(e, "padding" + B[r], !0, o)), "margin" !== n && (a -= f.css(e, "border" + B[r] + "Width", !0, o))) : (a += f.css(e, "padding" + B[r], !0, o), "padding" !== n && (a += f.css(e, "border" + B[r] + "Width", !0, o)));
			return a
		}

		function He(e, t, n) {
			var i = !0,
				o = "width" === t ? e.offsetWidth : e.offsetHeight,
				r = xe(e),
				a = "border-box" === f.css(e, "boxSizing", !1, r);
			if (o <= 0 || null == o) {
				if (((o = Le(e, t, r)) < 0 || null == o) && (o = e.style[t]), Ie.test(o)) return o;
				i = a && (d.boxSizingReliable() || o === e.style[t]), o = parseFloat(o) || 0
			}
			return o + Fe(e, t, n || (a ? "border" : "content"), i, r) + "px"
		}

		function qe(e, t) {
			for (var n, i, o, r = [], a = 0, s = e.length; a < s; a++)(i = e[a]).style && (r[a] = U.get(i, "olddisplay"), n = i.style.display, t ? (r[a] || "none" !== n || (i.style.display = ""), "" === i.style.display && z(i) && (r[a] = U.access(i, "olddisplay", Se(i.nodeName)))) : (o = z(i), "none" === n && o || U.set(i, "olddisplay", o ? n : f.css(i, "display"))));
			for (a = 0; a < s; a++)(i = e[a]).style && (t && "none" !== i.style.display && "" !== i.style.display || (i.style.display = t ? r[a] || "" : "none"));
			return e
		}

		function $e(e, t, n, i, o) {
			return new $e.prototype.init(e, t, n, i, o)
		}
		f.extend({
			cssHooks: {
				opacity: {
					get: function(e, t) {
						if (t) {
							var n = Le(e, "opacity");
							return "" === n ? "1" : n
						}
					}
				}
			},
			cssNumber: {
				animationIterationCount: !0,
				columnCount: !0,
				fillOpacity: !0,
				flexGrow: !0,
				flexShrink: !0,
				fontWeight: !0,
				lineHeight: !0,
				opacity: !0,
				order: !0,
				orphans: !0,
				widows: !0,
				zIndex: !0,
				zoom: !0
			},
			cssProps: {
				float: "cssFloat"
			},
			style: function(e, t, n, i) {
				if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
					var o, r, a, s = f.camelCase(t),
						l = e.style;
					if (t = f.cssProps[s] || (f.cssProps[s] = Ue(s) || s), a = f.cssHooks[t] || f.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (o = a.get(e, !1, i)) ? o : l[t];
					"string" === (r = typeof n) && (o = G.exec(n)) && o[1] && (n = Y(e, t, o), r = "number"), null != n && n == n && ("number" === r && (n += o && o[3] || (f.cssNumber[s] ? "" : "px")), d.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), a && "set" in a && void 0 === (n = a.set(e, n, i)) || (l[t] = n))
				}
			},
			css: function(e, t, n, i) {
				var o, r, a, s = f.camelCase(t);
				return t = f.cssProps[s] || (f.cssProps[s] = Ue(s) || s), (a = f.cssHooks[t] || f.cssHooks[s]) && "get" in a && (o = a.get(e, !0, n)), void 0 === o && (o = Le(e, t, i)), "normal" === o && t in _e && (o = _e[t]), "" === n || n ? (r = parseFloat(o), !0 === n || isFinite(r) ? r || 0 : o) : o
			}
		}), f.each(["height", "width"], function(e, t) {
			f.cssHooks[t] = {
				get: function(e, n, i) {
					if (n) return Oe.test(f.css(e, "display")) && 0 === e.offsetWidth ? Ae(e, Me, function() {
						return He(e, t, i)
					}) : He(e, t, i)
				},
				set: function(e, n, i) {
					var o, r = i && xe(e),
						a = i && Fe(e, t, i, "border-box" === f.css(e, "boxSizing", !1, r), r);
					return a && (o = G.exec(n)) && "px" !== (o[3] || "px") && (e.style[t] = n, n = f.css(e, t)), Pe(0, n, a)
				}
			}
		}), f.cssHooks.marginLeft = Ne(d.reliableMarginLeft, function(e, t) {
			if (t) return (parseFloat(Le(e, "marginLeft")) || e.getBoundingClientRect().left - Ae(e, {
				marginLeft: 0
			}, function() {
				return e.getBoundingClientRect().left
			})) + "px"
		}), f.cssHooks.marginRight = Ne(d.reliableMarginRight, function(e, t) {
			if (t) return Ae(e, {
				display: "inline-block"
			}, Le, [e, "marginRight"])
		}), f.each({
			margin: "",
			padding: "",
			border: "Width"
		}, function(e, t) {
			f.cssHooks[e + t] = {
				expand: function(n) {
					for (var i = 0, o = {}, r = "string" == typeof n ? n.split(" ") : [n]; i < 4; i++) o[e + B[i] + t] = r[i] || r[i - 2] || r[0];
					return o
				}
			}, Ce.test(e) || (f.cssHooks[e + t].set = Pe)
		}), f.fn.extend({
			css: function(e, t) {
				return _(this, function(e, t, n) {
					var i, o, r = {},
						a = 0;
					if (f.isArray(t)) {
						for (i = xe(e), o = t.length; a < o; a++) r[t[a]] = f.css(e, t[a], !1, i);
						return r
					}
					return void 0 !== n ? f.style(e, t, n) : f.css(e, t)
				}, e, t, arguments.length > 1)
			},
			show: function() {
				return qe(this, !0)
			},
			hide: function() {
				return qe(this)
			},
			toggle: function(e) {
				return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
					z(this) ? f(this).show() : f(this).hide()
				})
			}
		}), f.Tween = $e, $e.prototype = {
			constructor: $e,
			init: function(e, t, n, i, o, r) {
				this.elem = e, this.prop = n, this.easing = o || f.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = r || (f.cssNumber[n] ? "" : "px")
			},
			cur: function() {
				var e = $e.propHooks[this.prop];
				return e && e.get ? e.get(this) : $e.propHooks._default.get(this)
			},
			run: function(e) {
				var t, n = $e.propHooks[this.prop];
				return this.options.duration ? this.pos = t = f.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : $e.propHooks._default.set(this), this
			}
		}, $e.prototype.init.prototype = $e.prototype, $e.propHooks = {
			_default: {
				get: function(e) {
					var t;
					return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = f.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0
				},
				set: function(e) {
					f.fx.step[e.prop] ? f.fx.step[e.prop](e) : 1 !== e.elem.nodeType || null == e.elem.style[f.cssProps[e.prop]] && !f.cssHooks[e.prop] ? e.elem[e.prop] = e.now : f.style(e.elem, e.prop, e.now + e.unit)
				}
			}
		}, $e.propHooks.scrollTop = $e.propHooks.scrollLeft = {
			set: function(e) {
				e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
			}
		}, f.easing = {
			linear: function(e) {
				return e
			},
			swing: function(e) {
				return .5 - Math.cos(e * Math.PI) / 2
			},
			_default: "swing"
		}, f.fx = $e.prototype.init, f.fx.step = {};
		var Ge, Be, ze = /^(?:toggle|show|hide)$/,
			Ye = /queueHooks$/;

		function je() {
			return e.setTimeout(function() {
				Ge = void 0
			}), Ge = f.now()
		}

		function Ke(e, t) {
			var n, i = 0,
				o = {
					height: e
				};
			for (t = t ? 1 : 0; i < 4; i += 2 - t) o["margin" + (n = B[i])] = o["padding" + n] = e;
			return t && (o.opacity = o.width = e), o
		}

		function We(e, t, n) {
			for (var i, o = (Ve.tweeners[t] || []).concat(Ve.tweeners["*"]), r = 0, a = o.length; r < a; r++)
				if (i = o[r].call(n, t, e)) return i
		}

		function Ve(e, t, n) {
			var i, o, r = 0,
				a = Ve.prefilters.length,
				s = f.Deferred().always(function() {
					delete l.elem
				}),
				l = function() {
					if (o) return !1;
					for (var t = Ge || je(), n = Math.max(0, c.startTime + c.duration - t), i = 1 - (n / c.duration || 0), r = 0, a = c.tweens.length; r < a; r++) c.tweens[r].run(i);
					return s.notifyWith(e, [c, i, n]), i < 1 && a ? n : (s.resolveWith(e, [c]), !1)
				},
				c = s.promise({
					elem: e,
					props: f.extend({}, t),
					opts: f.extend(!0, {
						specialEasing: {},
						easing: f.easing._default
					}, n),
					originalProperties: t,
					originalOptions: n,
					startTime: Ge || je(),
					duration: n.duration,
					tweens: [],
					createTween: function(t, n) {
						var i = f.Tween(e, c.opts, t, n, c.opts.specialEasing[t] || c.opts.easing);
						return c.tweens.push(i), i
					},
					stop: function(t) {
						var n = 0,
							i = t ? c.tweens.length : 0;
						if (o) return this;
						for (o = !0; n < i; n++) c.tweens[n].run(1);
						return t ? (s.notifyWith(e, [c, 1, 0]), s.resolveWith(e, [c, t])) : s.rejectWith(e, [c, t]), this
					}
				}),
				u = c.props;
			for (! function(e, t) {
					var n, i, o, r, a;
					for (n in e)
						if (o = t[i = f.camelCase(n)], r = e[n], f.isArray(r) && (o = r[1], r = e[n] = r[0]), n !== i && (e[i] = r, delete e[n]), (a = f.cssHooks[i]) && "expand" in a)
							for (n in r = a.expand(r), delete e[i], r) n in e || (e[n] = r[n], t[n] = o);
						else t[i] = o
				}(u, c.opts.specialEasing); r < a; r++)
				if (i = Ve.prefilters[r].call(c, e, u, c.opts)) return f.isFunction(i.stop) && (f._queueHooks(c.elem, c.opts.queue).stop = f.proxy(i.stop, i)), i;
			return f.map(u, We, c), f.isFunction(c.opts.start) && c.opts.start.call(e, c), f.fx.timer(f.extend(l, {
				elem: e,
				anim: c,
				queue: c.opts.queue
			})), c.progress(c.opts.progress).done(c.opts.done, c.opts.complete).fail(c.opts.fail).always(c.opts.always)
		}
		f.Animation = f.extend(Ve, {
				tweeners: {
					"*": [function(e, t) {
						var n = this.createTween(e, t);
						return Y(n.elem, e, G.exec(t), n), n
					}]
				},
				tweener: function(e, t) {
					f.isFunction(e) ? (t = e, e = ["*"]) : e = e.match(O);
					for (var n, i = 0, o = e.length; i < o; i++) n = e[i], Ve.tweeners[n] = Ve.tweeners[n] || [], Ve.tweeners[n].unshift(t)
				},
				prefilters: [function(e, t, n) {
					var i, o, r, a, s, l, c, u = this,
						d = {},
						p = e.style,
						h = e.nodeType && z(e),
						m = U.get(e, "fxshow");
					for (i in n.queue || (null == (s = f._queueHooks(e, "fx")).unqueued && (s.unqueued = 0, l = s.empty.fire, s.empty.fire = function() {
							s.unqueued || l()
						}), s.unqueued++, u.always(function() {
							u.always(function() {
								s.unqueued--, f.queue(e, "fx").length || s.empty.fire()
							})
						})), 1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [p.overflow, p.overflowX, p.overflowY], "inline" === ("none" === (c = f.css(e, "display")) ? U.get(e, "olddisplay") || Se(e.nodeName) : c) && "none" === f.css(e, "float") && (p.display = "inline-block")), n.overflow && (p.overflow = "hidden", u.always(function() {
							p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
						})), t)
						if (o = t[i], ze.exec(o)) {
							if (delete t[i], r = r || "toggle" === o, o === (h ? "hide" : "show")) {
								if ("show" !== o || !m || void 0 === m[i]) continue;
								h = !0
							}
							d[i] = m && m[i] || f.style(e, i)
						} else c = void 0;
					if (f.isEmptyObject(d)) "inline" === ("none" === c ? Se(e.nodeName) : c) && (p.display = c);
					else
						for (i in m ? "hidden" in m && (h = m.hidden) : m = U.access(e, "fxshow", {}), r && (m.hidden = !h), h ? f(e).show() : u.done(function() {
								f(e).hide()
							}), u.done(function() {
								var t;
								for (t in U.remove(e, "fxshow"), d) f.style(e, t, d[t])
							}), d) a = We(h ? m[i] : 0, i, u), i in m || (m[i] = a.start, h && (a.end = a.start, a.start = "width" === i || "height" === i ? 1 : 0))
				}],
				prefilter: function(e, t) {
					t ? Ve.prefilters.unshift(e) : Ve.prefilters.push(e)
				}
			}), f.speed = function(e, t, n) {
				var i = e && "object" == typeof e ? f.extend({}, e) : {
					complete: n || !n && t || f.isFunction(e) && e,
					duration: e,
					easing: n && t || t && !f.isFunction(t) && t
				};
				return i.duration = f.fx.off ? 0 : "number" == typeof i.duration ? i.duration : i.duration in f.fx.speeds ? f.fx.speeds[i.duration] : f.fx.speeds._default, null != i.queue && !0 !== i.queue || (i.queue = "fx"), i.old = i.complete, i.complete = function() {
					f.isFunction(i.old) && i.old.call(this), i.queue && f.dequeue(this, i.queue)
				}, i
			}, f.fn.extend({
				fadeTo: function(e, t, n, i) {
					return this.filter(z).css("opacity", 0).show().end().animate({
						opacity: t
					}, e, n, i)
				},
				animate: function(e, t, n, i) {
					var o = f.isEmptyObject(e),
						r = f.speed(t, n, i),
						a = function() {
							var t = Ve(this, f.extend({}, e), r);
							(o || U.get(this, "finish")) && t.stop(!0)
						};
					return a.finish = a, o || !1 === r.queue ? this.each(a) : this.queue(r.queue, a)
				},
				stop: function(e, t, n) {
					var i = function(e) {
						var t = e.stop;
						delete e.stop, t(n)
					};
					return "string" != typeof e && (n = t, t = e, e = void 0), t && !1 !== e && this.queue(e || "fx", []), this.each(function() {
						var t = !0,
							o = null != e && e + "queueHooks",
							r = f.timers,
							a = U.get(this);
						if (o) a[o] && a[o].stop && i(a[o]);
						else
							for (o in a) a[o] && a[o].stop && Ye.test(o) && i(a[o]);
						for (o = r.length; o--;) r[o].elem !== this || null != e && r[o].queue !== e || (r[o].anim.stop(n), t = !1, r.splice(o, 1));
						!t && n || f.dequeue(this, e)
					})
				},
				finish: function(e) {
					return !1 !== e && (e = e || "fx"), this.each(function() {
						var t, n = U.get(this),
							i = n[e + "queue"],
							o = n[e + "queueHooks"],
							r = f.timers,
							a = i ? i.length : 0;
						for (n.finish = !0, f.queue(this, e, []), o && o.stop && o.stop.call(this, !0), t = r.length; t--;) r[t].elem === this && r[t].queue === e && (r[t].anim.stop(!0), r.splice(t, 1));
						for (t = 0; t < a; t++) i[t] && i[t].finish && i[t].finish.call(this);
						delete n.finish
					})
				}
			}), f.each(["toggle", "show", "hide"], function(e, t) {
				var n = f.fn[t];
				f.fn[t] = function(e, i, o) {
					return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(Ke(t, !0), e, i, o)
				}
			}), f.each({
				slideDown: Ke("show"),
				slideUp: Ke("hide"),
				slideToggle: Ke("toggle"),
				fadeIn: {
					opacity: "show"
				},
				fadeOut: {
					opacity: "hide"
				},
				fadeToggle: {
					opacity: "toggle"
				}
			}, function(e, t) {
				f.fn[e] = function(e, n, i) {
					return this.animate(t, e, n, i)
				}
			}), f.timers = [], f.fx.tick = function() {
				var e, t = 0,
					n = f.timers;
				for (Ge = f.now(); t < n.length; t++)(e = n[t])() || n[t] !== e || n.splice(t--, 1);
				n.length || f.fx.stop(), Ge = void 0
			}, f.fx.timer = function(e) {
				f.timers.push(e), e() ? f.fx.start() : f.timers.pop()
			}, f.fx.interval = 13, f.fx.start = function() {
				Be || (Be = e.setInterval(f.fx.tick, f.fx.interval))
			}, f.fx.stop = function() {
				e.clearInterval(Be), Be = null
			}, f.fx.speeds = {
				slow: 600,
				fast: 200,
				_default: 400
			}, f.fn.delay = function(t, n) {
				return t = f.fx && f.fx.speeds[t] || t, n = n || "fx", this.queue(n, function(n, i) {
					var o = e.setTimeout(n, t);
					i.stop = function() {
						e.clearTimeout(o)
					}
				})
			},
			function() {
				var e = i.createElement("input"),
					t = i.createElement("select"),
					n = t.appendChild(i.createElement("option"));
				e.type = "checkbox", d.checkOn = "" !== e.value, d.optSelected = n.selected, t.disabled = !0, d.optDisabled = !n.disabled, (e = i.createElement("input")).value = "t", e.type = "radio", d.radioValue = "t" === e.value
			}();
		var Xe, Ze = f.expr.attrHandle;
		f.fn.extend({
			attr: function(e, t) {
				return _(this, f.attr, e, t, arguments.length > 1)
			},
			removeAttr: function(e) {
				return this.each(function() {
					f.removeAttr(this, e)
				})
			}
		}), f.extend({
			attr: function(e, t, n) {
				var i, o, r = e.nodeType;
				if (3 !== r && 8 !== r && 2 !== r) return void 0 === e.getAttribute ? f.prop(e, t, n) : (1 === r && f.isXMLDoc(e) || (t = t.toLowerCase(), o = f.attrHooks[t] || (f.expr.match.bool.test(t) ? Xe : void 0)), void 0 !== n ? null === n ? void f.removeAttr(e, t) : o && "set" in o && void 0 !== (i = o.set(e, n, t)) ? i : (e.setAttribute(t, n + ""), n) : o && "get" in o && null !== (i = o.get(e, t)) ? i : null == (i = f.find.attr(e, t)) ? void 0 : i)
			},
			attrHooks: {
				type: {
					set: function(e, t) {
						if (!d.radioValue && "radio" === t && f.nodeName(e, "input")) {
							var n = e.value;
							return e.setAttribute("type", t), n && (e.value = n), t
						}
					}
				}
			},
			removeAttr: function(e, t) {
				var n, i, o = 0,
					r = t && t.match(O);
				if (r && 1 === e.nodeType)
					for (; n = r[o++];) i = f.propFix[n] || n, f.expr.match.bool.test(n) && (e[i] = !1), e.removeAttribute(n)
			}
		}), Xe = {
			set: function(e, t, n) {
				return !1 === t ? f.removeAttr(e, n) : e.setAttribute(n, n), n
			}
		}, f.each(f.expr.match.bool.source.match(/\w+/g), function(e, t) {
			var n = Ze[t] || f.find.attr;
			Ze[t] = function(e, t, i) {
				var o, r;
				return i || (r = Ze[t], Ze[t] = o, o = null != n(e, t, i) ? t.toLowerCase() : null, Ze[t] = r), o
			}
		});
		var Qe = /^(?:input|select|textarea|button)$/i,
			Je = /^(?:a|area)$/i;
		f.fn.extend({
			prop: function(e, t) {
				return _(this, f.prop, e, t, arguments.length > 1)
			},
			removeProp: function(e) {
				return this.each(function() {
					delete this[f.propFix[e] || e]
				})
			}
		}), f.extend({
			prop: function(e, t, n) {
				var i, o, r = e.nodeType;
				if (3 !== r && 8 !== r && 2 !== r) return 1 === r && f.isXMLDoc(e) || (t = f.propFix[t] || t, o = f.propHooks[t]), void 0 !== n ? o && "set" in o && void 0 !== (i = o.set(e, n, t)) ? i : e[t] = n : o && "get" in o && null !== (i = o.get(e, t)) ? i : e[t]
			},
			propHooks: {
				tabIndex: {
					get: function(e) {
						var t = f.find.attr(e, "tabindex");
						return t ? parseInt(t, 10) : Qe.test(e.nodeName) || Je.test(e.nodeName) && e.href ? 0 : -1
					}
				}
			},
			propFix: {
				for: "htmlFor",
				class: "className"
			}
		}), d.optSelected || (f.propHooks.selected = {
			get: function(e) {
				var t = e.parentNode;
				return t && t.parentNode && t.parentNode.selectedIndex, null
			},
			set: function(e) {
				var t = e.parentNode;
				t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
			}
		}), f.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
			f.propFix[this.toLowerCase()] = this
		});
		var et = /[\t\r\n\f]/g;

		function tt(e) {
			return e.getAttribute && e.getAttribute("class") || ""
		}
		f.fn.extend({
			addClass: function(e) {
				var t, n, i, o, r, a, s, l = 0;
				if (f.isFunction(e)) return this.each(function(t) {
					f(this).addClass(e.call(this, t, tt(this)))
				});
				if ("string" == typeof e && e)
					for (t = e.match(O) || []; n = this[l++];)
						if (o = tt(n), i = 1 === n.nodeType && (" " + o + " ").replace(et, " ")) {
							for (a = 0; r = t[a++];) i.indexOf(" " + r + " ") < 0 && (i += r + " ");
							o !== (s = f.trim(i)) && n.setAttribute("class", s)
						} return this
			},
			removeClass: function(e) {
				var t, n, i, o, r, a, s, l = 0;
				if (f.isFunction(e)) return this.each(function(t) {
					f(this).removeClass(e.call(this, t, tt(this)))
				});
				if (!arguments.length) return this.attr("class", "");
				if ("string" == typeof e && e)
					for (t = e.match(O) || []; n = this[l++];)
						if (o = tt(n), i = 1 === n.nodeType && (" " + o + " ").replace(et, " ")) {
							for (a = 0; r = t[a++];)
								for (; i.indexOf(" " + r + " ") > -1;) i = i.replace(" " + r + " ", " ");
							o !== (s = f.trim(i)) && n.setAttribute("class", s)
						} return this
			},
			toggleClass: function(e, t) {
				var n = typeof e;
				return "boolean" == typeof t && "string" === n ? t ? this.addClass(e) : this.removeClass(e) : f.isFunction(e) ? this.each(function(n) {
					f(this).toggleClass(e.call(this, n, tt(this), t), t)
				}) : this.each(function() {
					var t, i, o, r;
					if ("string" === n)
						for (i = 0, o = f(this), r = e.match(O) || []; t = r[i++];) o.hasClass(t) ? o.removeClass(t) : o.addClass(t);
					else void 0 !== e && "boolean" !== n || ((t = tt(this)) && U.set(this, "__className__", t), this.setAttribute && this.setAttribute("class", t || !1 === e ? "" : U.get(this, "__className__") || ""))
				})
			},
			hasClass: function(e) {
				var t, n, i = 0;
				for (t = " " + e + " "; n = this[i++];)
					if (1 === n.nodeType && (" " + tt(n) + " ").replace(et, " ").indexOf(t) > -1) return !0;
				return !1
			}
		});
		var nt = /\r/g,
			it = /[\x20\t\r\n\f]+/g;
		f.fn.extend({
			val: function(e) {
				var t, n, i, o = this[0];
				return arguments.length ? (i = f.isFunction(e), this.each(function(n) {
					var o;
					1 === this.nodeType && (null == (o = i ? e.call(this, n, f(this).val()) : e) ? o = "" : "number" == typeof o ? o += "" : f.isArray(o) && (o = f.map(o, function(e) {
						return null == e ? "" : e + ""
					})), (t = f.valHooks[this.type] || f.valHooks[this.nodeName.toLowerCase()]) && "set" in t && void 0 !== t.set(this, o, "value") || (this.value = o))
				})) : o ? (t = f.valHooks[o.type] || f.valHooks[o.nodeName.toLowerCase()]) && "get" in t && void 0 !== (n = t.get(o, "value")) ? n : "string" == typeof(n = o.value) ? n.replace(nt, "") : null == n ? "" : n : void 0
			}
		}), f.extend({
			valHooks: {
				option: {
					get: function(e) {
						var t = f.find.attr(e, "value");
						return null != t ? t : f.trim(f.text(e)).replace(it, " ")
					}
				},
				select: {
					get: function(e) {
						for (var t, n, i = e.options, o = e.selectedIndex, r = "select-one" === e.type || o < 0, a = r ? null : [], s = r ? o + 1 : i.length, l = o < 0 ? s : r ? o : 0; l < s; l++)
							if (((n = i[l]).selected || l === o) && (d.optDisabled ? !n.disabled : null === n.getAttribute("disabled")) && (!n.parentNode.disabled || !f.nodeName(n.parentNode, "optgroup"))) {
								if (t = f(n).val(), r) return t;
								a.push(t)
							} return a
					},
					set: function(e, t) {
						for (var n, i, o = e.options, r = f.makeArray(t), a = o.length; a--;)((i = o[a]).selected = f.inArray(f.valHooks.option.get(i), r) > -1) && (n = !0);
						return n || (e.selectedIndex = -1), r
					}
				}
			}
		}), f.each(["radio", "checkbox"], function() {
			f.valHooks[this] = {
				set: function(e, t) {
					if (f.isArray(t)) return e.checked = f.inArray(f(e).val(), t) > -1
				}
			}, d.checkOn || (f.valHooks[this].get = function(e) {
				return null === e.getAttribute("value") ? "on" : e.value
			})
		});
		var ot = /^(?:focusinfocus|focusoutblur)$/;
		f.extend(f.event, {
			trigger: function(t, n, o, r) {
				var a, s, l, c, d, p, h, m = [o || i],
					g = u.call(t, "type") ? t.type : t,
					v = u.call(t, "namespace") ? t.namespace.split(".") : [];
				if (s = l = o = o || i, 3 !== o.nodeType && 8 !== o.nodeType && !ot.test(g + f.event.triggered) && (g.indexOf(".") > -1 && (g = (v = g.split(".")).shift(), v.sort()), d = g.indexOf(":") < 0 && "on" + g, (t = t[f.expando] ? t : new f.Event(g, "object" == typeof t && t)).isTrigger = r ? 2 : 3, t.namespace = v.join("."), t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = o), n = null == n ? [t] : f.makeArray(n, [t]), h = f.event.special[g] || {}, r || !h.trigger || !1 !== h.trigger.apply(o, n))) {
					if (!r && !h.noBubble && !f.isWindow(o)) {
						for (c = h.delegateType || g, ot.test(c + g) || (s = s.parentNode); s; s = s.parentNode) m.push(s), l = s;
						l === (o.ownerDocument || i) && m.push(l.defaultView || l.parentWindow || e)
					}
					for (a = 0;
						(s = m[a++]) && !t.isPropagationStopped();) t.type = a > 1 ? c : h.bindType || g, (p = (U.get(s, "events") || {})[t.type] && U.get(s, "handle")) && p.apply(s, n), (p = d && s[d]) && p.apply && R(s) && (t.result = p.apply(s, n), !1 === t.result && t.preventDefault());
					return t.type = g, r || t.isDefaultPrevented() || h._default && !1 !== h._default.apply(m.pop(), n) || !R(o) || d && f.isFunction(o[g]) && !f.isWindow(o) && ((l = o[d]) && (o[d] = null), f.event.triggered = g, o[g](), f.event.triggered = void 0, l && (o[d] = l)), t.result
				}
			},
			simulate: function(e, t, n) {
				var i = f.extend(new f.Event, n, {
					type: e,
					isSimulated: !0
				});
				f.event.trigger(i, null, t)
			}
		}), f.fn.extend({
			trigger: function(e, t) {
				return this.each(function() {
					f.event.trigger(e, t, this)
				})
			},
			triggerHandler: function(e, t) {
				var n = this[0];
				if (n) return f.event.trigger(e, t, n, !0)
			}
		}), f.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(e, t) {
			f.fn[t] = function(e, n) {
				return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
			}
		}), f.fn.extend({
			hover: function(e, t) {
				return this.mouseenter(e).mouseleave(t || e)
			}
		}), d.focusin = "onfocusin" in e, d.focusin || f.each({
			focus: "focusin",
			blur: "focusout"
		}, function(e, t) {
			var n = function(e) {
				f.event.simulate(t, e.target, f.event.fix(e))
			};
			f.event.special[t] = {
				setup: function() {
					var i = this.ownerDocument || this,
						o = U.access(i, t);
					o || i.addEventListener(e, n, !0), U.access(i, t, (o || 0) + 1)
				},
				teardown: function() {
					var i = this.ownerDocument || this,
						o = U.access(i, t) - 1;
					o ? U.access(i, t, o) : (i.removeEventListener(e, n, !0), U.remove(i, t))
				}
			}
		});
		var rt = e.location,
			at = f.now(),
			st = /\?/;
		f.parseJSON = function(e) {
			return JSON.parse(e + "")
		}, f.parseXML = function(t) {
			var n;
			if (!t || "string" != typeof t) return null;
			try {
				n = (new e.DOMParser).parseFromString(t, "text/xml")
			} catch (e) {
				n = void 0
			}
			return n && !n.getElementsByTagName("parsererror").length || f.error("Invalid XML: " + t), n
		};
		var lt = /#.*$/,
			ct = /([?&])_=[^&]*/,
			ut = /^(.*?):[ \t]*([^\r\n]*)$/gm,
			dt = /^(?:GET|HEAD)$/,
			ft = /^\/\//,
			pt = {},
			ht = {},
			mt = "*/".concat("*"),
			gt = i.createElement("a");

		function vt(e) {
			return function(t, n) {
				"string" != typeof t && (n = t, t = "*");
				var i, o = 0,
					r = t.toLowerCase().match(O) || [];
				if (f.isFunction(n))
					for (; i = r[o++];) "+" === i[0] ? (i = i.slice(1) || "*", (e[i] = e[i] || []).unshift(n)) : (e[i] = e[i] || []).push(n)
			}
		}

		function yt(e, t, n, i) {
			var o = {},
				r = e === ht;

			function a(s) {
				var l;
				return o[s] = !0, f.each(e[s] || [], function(e, s) {
					var c = s(t, n, i);
					return "string" != typeof c || r || o[c] ? r ? !(l = c) : void 0 : (t.dataTypes.unshift(c), a(c), !1)
				}), l
			}
			return a(t.dataTypes[0]) || !o["*"] && a("*")
		}

		function bt(e, t) {
			var n, i, o = f.ajaxSettings.flatOptions || {};
			for (n in t) void 0 !== t[n] && ((o[n] ? e : i || (i = {}))[n] = t[n]);
			return i && f.extend(!0, e, i), e
		}
		gt.href = rt.href, f.extend({
			active: 0,
			lastModified: {},
			etag: {},
			ajaxSettings: {
				url: rt.href,
				type: "GET",
				isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(rt.protocol),
				global: !0,
				processData: !0,
				async: !0,
				contentType: "application/x-www-form-urlencoded; charset=UTF-8",
				accepts: {
					"*": mt,
					text: "text/plain",
					html: "text/html",
					xml: "application/xml, text/xml",
					json: "application/json, text/javascript"
				},
				contents: {
					xml: /\bxml\b/,
					html: /\bhtml/,
					json: /\bjson\b/
				},
				responseFields: {
					xml: "responseXML",
					text: "responseText",
					json: "responseJSON"
				},
				converters: {
					"* text": String,
					"text html": !0,
					"text json": f.parseJSON,
					"text xml": f.parseXML
				},
				flatOptions: {
					url: !0,
					context: !0
				}
			},
			ajaxSetup: function(e, t) {
				return t ? bt(bt(e, f.ajaxSettings), t) : bt(f.ajaxSettings, e)
			},
			ajaxPrefilter: vt(pt),
			ajaxTransport: vt(ht),
			ajax: function(t, n) {
				"object" == typeof t && (n = t, t = void 0), n = n || {};
				var o, r, a, s, l, c, u, d, p = f.ajaxSetup({}, n),
					h = p.context || p,
					m = p.context && (h.nodeType || h.jquery) ? f(h) : f.event,
					g = f.Deferred(),
					v = f.Callbacks("once memory"),
					y = p.statusCode || {},
					b = {},
					E = {},
					T = 0,
					w = "canceled",
					S = {
						readyState: 0,
						getResponseHeader: function(e) {
							var t;
							if (2 === T) {
								if (!s)
									for (s = {}; t = ut.exec(a);) s[t[1].toLowerCase()] = t[2];
								t = s[e.toLowerCase()]
							}
							return null == t ? null : t
						},
						getAllResponseHeaders: function() {
							return 2 === T ? a : null
						},
						setRequestHeader: function(e, t) {
							var n = e.toLowerCase();
							return T || (e = E[n] = E[n] || e, b[e] = t), this
						},
						overrideMimeType: function(e) {
							return T || (p.mimeType = e), this
						},
						statusCode: function(e) {
							var t;
							if (e)
								if (T < 2)
									for (t in e) y[t] = [y[t], e[t]];
								else S.always(e[S.status]);
							return this
						},
						abort: function(e) {
							var t = e || w;
							return o && o.abort(t), C(0, t), this
						}
					};
				if (g.promise(S).complete = v.add, S.success = S.done, S.error = S.fail, p.url = ((t || p.url || rt.href) + "").replace(lt, "").replace(ft, rt.protocol + "//"), p.type = n.method || n.type || p.method || p.type, p.dataTypes = f.trim(p.dataType || "*").toLowerCase().match(O) || [""], null == p.crossDomain) {
					c = i.createElement("a");
					try {
						c.href = p.url, c.href = c.href, p.crossDomain = gt.protocol + "//" + gt.host != c.protocol + "//" + c.host
					} catch (e) {
						p.crossDomain = !0
					}
				}
				if (p.data && p.processData && "string" != typeof p.data && (p.data = f.param(p.data, p.traditional)), yt(pt, p, n, S), 2 === T) return S;
				for (d in (u = f.event && p.global) && 0 == f.active++ && f.event.trigger("ajaxStart"), p.type = p.type.toUpperCase(), p.hasContent = !dt.test(p.type), r = p.url, p.hasContent || (p.data && (r = p.url += (st.test(r) ? "&" : "?") + p.data, delete p.data), !1 === p.cache && (p.url = ct.test(r) ? r.replace(ct, "$1_=" + at++) : r + (st.test(r) ? "&" : "?") + "_=" + at++)), p.ifModified && (f.lastModified[r] && S.setRequestHeader("If-Modified-Since", f.lastModified[r]), f.etag[r] && S.setRequestHeader("If-None-Match", f.etag[r])), (p.data && p.hasContent && !1 !== p.contentType || n.contentType) && S.setRequestHeader("Content-Type", p.contentType), S.setRequestHeader("Accept", p.dataTypes[0] && p.accepts[p.dataTypes[0]] ? p.accepts[p.dataTypes[0]] + ("*" !== p.dataTypes[0] ? ", " + mt + "; q=0.01" : "") : p.accepts["*"]), p.headers) S.setRequestHeader(d, p.headers[d]);
				if (p.beforeSend && (!1 === p.beforeSend.call(h, S, p) || 2 === T)) return S.abort();
				for (d in w = "abort", {
						success: 1,
						error: 1,
						complete: 1
					}) S[d](p[d]);
				if (o = yt(ht, p, n, S)) {
					if (S.readyState = 1, u && m.trigger("ajaxSend", [S, p]), 2 === T) return S;
					p.async && p.timeout > 0 && (l = e.setTimeout(function() {
						S.abort("timeout")
					}, p.timeout));
					try {
						T = 1, o.send(b, C)
					} catch (e) {
						if (!(T < 2)) throw e;
						C(-1, e)
					}
				} else C(-1, "No Transport");

				function C(t, n, i, s) {
					var c, d, b, E, w, C = n;
					2 !== T && (T = 2, l && e.clearTimeout(l), o = void 0, a = s || "", S.readyState = t > 0 ? 4 : 0, c = t >= 200 && t < 300 || 304 === t, i && (E = function(e, t, n) {
						for (var i, o, r, a, s = e.contents, l = e.dataTypes;
							"*" === l[0];) l.shift(), void 0 === i && (i = e.mimeType || t.getResponseHeader("Content-Type"));
						if (i)
							for (o in s)
								if (s[o] && s[o].test(i)) {
									l.unshift(o);
									break
								} if (l[0] in n) r = l[0];
						else {
							for (o in n) {
								if (!l[0] || e.converters[o + " " + l[0]]) {
									r = o;
									break
								}
								a || (a = o)
							}
							r = r || a
						}
						if (r) return r !== l[0] && l.unshift(r), n[r]
					}(p, S, i)), E = function(e, t, n, i) {
						var o, r, a, s, l, c = {},
							u = e.dataTypes.slice();
						if (u[1])
							for (a in e.converters) c[a.toLowerCase()] = e.converters[a];
						for (r = u.shift(); r;)
							if (e.responseFields[r] && (n[e.responseFields[r]] = t), !l && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = r, r = u.shift())
								if ("*" === r) r = l;
								else if ("*" !== l && l !== r) {
							if (!(a = c[l + " " + r] || c["* " + r]))
								for (o in c)
									if ((s = o.split(" "))[1] === r && (a = c[l + " " + s[0]] || c["* " + s[0]])) {
										!0 === a ? a = c[o] : !0 !== c[o] && (r = s[0], u.unshift(s[1]));
										break
									} if (!0 !== a)
								if (a && e.throws) t = a(t);
								else try {
									t = a(t)
								} catch (e) {
									return {
										state: "parsererror",
										error: a ? e : "No conversion from " + l + " to " + r
									}
								}
						}
						return {
							state: "success",
							data: t
						}
					}(p, E, S, c), c ? (p.ifModified && ((w = S.getResponseHeader("Last-Modified")) && (f.lastModified[r] = w), (w = S.getResponseHeader("etag")) && (f.etag[r] = w)), 204 === t || "HEAD" === p.type ? C = "nocontent" : 304 === t ? C = "notmodified" : (C = E.state, d = E.data, c = !(b = E.error))) : (b = C, !t && C || (C = "error", t < 0 && (t = 0))), S.status = t, S.statusText = (n || C) + "", c ? g.resolveWith(h, [d, C, S]) : g.rejectWith(h, [S, C, b]), S.statusCode(y), y = void 0, u && m.trigger(c ? "ajaxSuccess" : "ajaxError", [S, p, c ? d : b]), v.fireWith(h, [S, C]), u && (m.trigger("ajaxComplete", [S, p]), --f.active || f.event.trigger("ajaxStop")))
				}
				return S
			},
			getJSON: function(e, t, n) {
				return f.get(e, t, n, "json")
			},
			getScript: function(e, t) {
				return f.get(e, void 0, t, "script")
			}
		}), f.each(["get", "post"], function(e, t) {
			f[t] = function(e, n, i, o) {
				return f.isFunction(n) && (o = o || i, i = n, n = void 0), f.ajax(f.extend({
					url: e,
					type: t,
					dataType: o,
					data: n,
					success: i
				}, f.isPlainObject(e) && e))
			}
		}), f._evalUrl = function(e) {
			return f.ajax({
				url: e,
				type: "GET",
				dataType: "script",
				async: !1,
				global: !1,
				throws: !0
			})
		}, f.fn.extend({
			wrapAll: function(e) {
				var t;
				return f.isFunction(e) ? this.each(function(t) {
					f(this).wrapAll(e.call(this, t))
				}) : (this[0] && (t = f(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
					for (var e = this; e.firstElementChild;) e = e.firstElementChild;
					return e
				}).append(this)), this)
			},
			wrapInner: function(e) {
				return f.isFunction(e) ? this.each(function(t) {
					f(this).wrapInner(e.call(this, t))
				}) : this.each(function() {
					var t = f(this),
						n = t.contents();
					n.length ? n.wrapAll(e) : t.append(e)
				})
			},
			wrap: function(e) {
				var t = f.isFunction(e);
				return this.each(function(n) {
					f(this).wrapAll(t ? e.call(this, n) : e)
				})
			},
			unwrap: function() {
				return this.parent().each(function() {
					f.nodeName(this, "body") || f(this).replaceWith(this.childNodes)
				}).end()
			}
		}), f.expr.filters.hidden = function(e) {
			return !f.expr.filters.visible(e)
		}, f.expr.filters.visible = function(e) {
			return e.offsetWidth > 0 || e.offsetHeight > 0 || e.getClientRects().length > 0
		};
		var Et = /%20/g,
			Tt = /\[\]$/,
			wt = /\r?\n/g,
			St = /^(?:submit|button|image|reset|file)$/i,
			Ct = /^(?:input|select|textarea|keygen)/i;

		function It(e, t, n, i) {
			var o;
			if (f.isArray(t)) f.each(t, function(t, o) {
				n || Tt.test(e) ? i(e, o) : It(e + "[" + ("object" == typeof o && null != o ? t : "") + "]", o, n, i)
			});
			else if (n || "object" !== f.type(t)) i(e, t);
			else
				for (o in t) It(e + "[" + o + "]", t[o], n, i)
		}
		f.param = function(e, t) {
			var n, i = [],
				o = function(e, t) {
					t = f.isFunction(t) ? t() : null == t ? "" : t, i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
				};
			if (void 0 === t && (t = f.ajaxSettings && f.ajaxSettings.traditional), f.isArray(e) || e.jquery && !f.isPlainObject(e)) f.each(e, function() {
				o(this.name, this.value)
			});
			else
				for (n in e) It(n, e[n], t, o);
			return i.join("&").replace(Et, "+")
		}, f.fn.extend({
			serialize: function() {
				return f.param(this.serializeArray())
			},
			serializeArray: function() {
				return this.map(function() {
					var e = f.prop(this, "elements");
					return e ? f.makeArray(e) : this
				}).filter(function() {
					var e = this.type;
					return this.name && !f(this).is(":disabled") && Ct.test(this.nodeName) && !St.test(e) && (this.checked || !j.test(e))
				}).map(function(e, t) {
					var n = f(this).val();
					return null == n ? null : f.isArray(n) ? f.map(n, function(e) {
						return {
							name: t.name,
							value: e.replace(wt, "\r\n")
						}
					}) : {
						name: t.name,
						value: n.replace(wt, "\r\n")
					}
				}).get()
			}
		}), f.ajaxSettings.xhr = function() {
			try {
				return new e.XMLHttpRequest
			} catch (e) {}
		};
		var xt = {
				0: 200,
				1223: 204
			},
			At = f.ajaxSettings.xhr();
		d.cors = !!At && "withCredentials" in At, d.ajax = At = !!At, f.ajaxTransport(function(t) {
			var n, i;
			if (d.cors || At && !t.crossDomain) return {
				send: function(o, r) {
					var a, s = t.xhr();
					if (s.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)
						for (a in t.xhrFields) s[a] = t.xhrFields[a];
					for (a in t.mimeType && s.overrideMimeType && s.overrideMimeType(t.mimeType), t.crossDomain || o["X-Requested-With"] || (o["X-Requested-With"] = "XMLHttpRequest"), o) s.setRequestHeader(a, o[a]);
					n = function(e) {
						return function() {
							n && (n = i = s.onload = s.onerror = s.onabort = s.onreadystatechange = null, "abort" === e ? s.abort() : "error" === e ? "number" != typeof s.status ? r(0, "error") : r(s.status, s.statusText) : r(xt[s.status] || s.status, s.statusText, "text" !== (s.responseType || "text") || "string" != typeof s.responseText ? {
								binary: s.response
							} : {
								text: s.responseText
							}, s.getAllResponseHeaders()))
						}
					}, s.onload = n(), i = s.onerror = n("error"), void 0 !== s.onabort ? s.onabort = i : s.onreadystatechange = function() {
						4 === s.readyState && e.setTimeout(function() {
							n && i()
						})
					}, n = n("abort");
					try {
						s.send(t.hasContent && t.data || null)
					} catch (e) {
						if (n) throw e
					}
				},
				abort: function() {
					n && n()
				}
			}
		}), f.ajaxSetup({
			accepts: {
				script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
			},
			contents: {
				script: /\b(?:java|ecma)script\b/
			},
			converters: {
				"text script": function(e) {
					return f.globalEval(e), e
				}
			}
		}), f.ajaxPrefilter("script", function(e) {
			void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
		}), f.ajaxTransport("script", function(e) {
			var t, n;
			if (e.crossDomain) return {
				send: function(o, r) {
					t = f("<script>").prop({
						charset: e.scriptCharset,
						src: e.url
					}).on("load error", n = function(e) {
						t.remove(), n = null, e && r("error" === e.type ? 404 : 200, e.type)
					}), i.head.appendChild(t[0])
				},
				abort: function() {
					n && n()
				}
			}
		});
		var Dt = [],
			Lt = /(=)\?(?=&|$)|\?\?/;
		f.ajaxSetup({
			jsonp: "callback",
			jsonpCallback: function() {
				var e = Dt.pop() || f.expando + "_" + at++;
				return this[e] = !0, e
			}
		}), f.ajaxPrefilter("json jsonp", function(t, n, i) {
			var o, r, a, s = !1 !== t.jsonp && (Lt.test(t.url) ? "url" : "string" == typeof t.data && 0 === (t.contentType || "").indexOf("application/x-www-form-urlencoded") && Lt.test(t.data) && "data");
			if (s || "jsonp" === t.dataTypes[0]) return o = t.jsonpCallback = f.isFunction(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(Lt, "$1" + o) : !1 !== t.jsonp && (t.url += (st.test(t.url) ? "&" : "?") + t.jsonp + "=" + o), t.converters["script json"] = function() {
				return a || f.error(o + " was not called"), a[0]
			}, t.dataTypes[0] = "json", r = e[o], e[o] = function() {
				a = arguments
			}, i.always(function() {
				void 0 === r ? f(e).removeProp(o) : e[o] = r, t[o] && (t.jsonpCallback = n.jsonpCallback, Dt.push(o)), a && f.isFunction(r) && r(a[0]), a = r = void 0
			}), "script"
		}), f.parseHTML = function(e, t, n) {
			if (!e || "string" != typeof e) return null;
			"boolean" == typeof t && (n = t, t = !1), t = t || i;
			var o = w.exec(e),
				r = !n && [];
			return o ? [t.createElement(o[1])] : (o = te([e], t, r), r && r.length && f(r).remove(), f.merge([], o.childNodes))
		};
		var Nt = f.fn.load;

		function Ot(e) {
			return f.isWindow(e) ? e : 9 === e.nodeType && e.defaultView
		}
		f.fn.load = function(e, t, n) {
			if ("string" != typeof e && Nt) return Nt.apply(this, arguments);
			var i, o, r, a = this,
				s = e.indexOf(" ");
			return s > -1 && (i = f.trim(e.slice(s)), e = e.slice(0, s)), f.isFunction(t) ? (n = t, t = void 0) : t && "object" == typeof t && (o = "POST"), a.length > 0 && f.ajax({
				url: e,
				type: o || "GET",
				dataType: "html",
				data: t
			}).done(function(e) {
				r = arguments, a.html(i ? f("<div>").append(f.parseHTML(e)).find(i) : e)
			}).always(n && function(e, t) {
				a.each(function() {
					n.apply(this, r || [e.responseText, t, e])
				})
			}), this
		}, f.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
			f.fn[t] = function(e) {
				return this.on(t, e)
			}
		}), f.expr.filters.animated = function(e) {
			return f.grep(f.timers, function(t) {
				return e === t.elem
			}).length
		}, f.offset = {
			setOffset: function(e, t, n) {
				var i, o, r, a, s, l, c = f.css(e, "position"),
					u = f(e),
					d = {};
				"static" === c && (e.style.position = "relative"), s = u.offset(), r = f.css(e, "top"), l = f.css(e, "left"), ("absolute" === c || "fixed" === c) && (r + l).indexOf("auto") > -1 ? (a = (i = u.position()).top, o = i.left) : (a = parseFloat(r) || 0, o = parseFloat(l) || 0), f.isFunction(t) && (t = t.call(e, n, f.extend({}, s))), null != t.top && (d.top = t.top - s.top + a), null != t.left && (d.left = t.left - s.left + o), "using" in t ? t.using.call(e, d) : u.css(d)
			}
		}, f.fn.extend({
			offset: function(e) {
				if (arguments.length) return void 0 === e ? this : this.each(function(t) {
					f.offset.setOffset(this, e, t)
				});
				var t, n, i = this[0],
					o = {
						top: 0,
						left: 0
					},
					r = i && i.ownerDocument;
				return r ? (t = r.documentElement, f.contains(t, i) ? (o = i.getBoundingClientRect(), n = Ot(r), {
					top: o.top + n.pageYOffset - t.clientTop,
					left: o.left + n.pageXOffset - t.clientLeft
				}) : o) : void 0
			},
			position: function() {
				if (this[0]) {
					var e, t, n = this[0],
						i = {
							top: 0,
							left: 0
						};
					return "fixed" === f.css(n, "position") ? t = n.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), f.nodeName(e[0], "html") || (i = e.offset()), i.top += f.css(e[0], "borderTopWidth", !0), i.left += f.css(e[0], "borderLeftWidth", !0)), {
						top: t.top - i.top - f.css(n, "marginTop", !0),
						left: t.left - i.left - f.css(n, "marginLeft", !0)
					}
				}
			},
			offsetParent: function() {
				return this.map(function() {
					for (var e = this.offsetParent; e && "static" === f.css(e, "position");) e = e.offsetParent;
					return e || De
				})
			}
		}), f.each({
			scrollLeft: "pageXOffset",
			scrollTop: "pageYOffset"
		}, function(e, t) {
			var n = "pageYOffset" === t;
			f.fn[e] = function(i) {
				return _(this, function(e, i, o) {
					var r = Ot(e);
					if (void 0 === o) return r ? r[t] : e[i];
					r ? r.scrollTo(n ? r.pageXOffset : o, n ? o : r.pageYOffset) : e[i] = o
				}, e, i, arguments.length)
			}
		}), f.each(["top", "left"], function(e, t) {
			f.cssHooks[t] = Ne(d.pixelPosition, function(e, n) {
				if (n) return n = Le(e, t), Ie.test(n) ? f(e).position()[t] + "px" : n
			})
		}), f.each({
			Height: "height",
			Width: "width"
		}, function(e, t) {
			f.each({
				padding: "inner" + e,
				content: t,
				"": "outer" + e
			}, function(n, i) {
				f.fn[i] = function(i, o) {
					var r = arguments.length && (n || "boolean" != typeof i),
						a = n || (!0 === i || !0 === o ? "margin" : "border");
					return _(this, function(t, n, i) {
						var o;
						return f.isWindow(t) ? t.document.documentElement["client" + e] : 9 === t.nodeType ? (o = t.documentElement, Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e])) : void 0 === i ? f.css(t, n, a) : f.style(t, n, i, a)
					}, t, r ? i : void 0, r, null)
				}
			})
		}), f.fn.extend({
			bind: function(e, t, n) {
				return this.on(e, null, t, n)
			},
			unbind: function(e, t) {
				return this.off(e, null, t)
			},
			delegate: function(e, t, n, i) {
				return this.on(t, e, n, i)
			},
			undelegate: function(e, t, n) {
				return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
			},
			size: function() {
				return this.length
			}
		}), f.fn.andSelf = f.fn.addBack, "function" == typeof define && define.amd && define("jquery", [], function() {
			return f
		});
		var Mt = e.jQuery,
			_t = e.$;
		return f.noConflict = function(t) {
			return e.$ === f && (e.$ = _t), t && e.jQuery === f && (e.jQuery = Mt), f
		}, t || (e.jQuery = e.$ = f), f
	}), function(e) {
		"function" == typeof define && define.amd ? define(["jquery"], function(t) {
			return e(t)
		}) : "object" == typeof module && "object" == typeof module.exports ? exports = e(require("jquery")) : e(jQuery)
	}(function(e) {
		e.easing.jswing = e.easing.swing;
		var t = Math.pow,
			n = Math.sqrt,
			i = Math.sin,
			o = Math.cos,
			r = Math.PI,
			a = 1.70158,
			s = 1.525 * a,
			l = 2 * r / 3,
			c = 2 * r / 4.5;

		function u(e) {
			var t = 7.5625,
				n = 2.75;
			return e < 1 / n ? t * e * e : e < 2 / n ? t * (e -= 1.5 / n) * e + .75 : e < 2.5 / n ? t * (e -= 2.25 / n) * e + .9375 : t * (e -= 2.625 / n) * e + .984375
		}
		e.extend(e.easing, {
			def: "easeOutQuad",
			swing: function(t) {
				return e.easing[e.easing.def](t)
			},
			easeInQuad: function(e) {
				return e * e
			},
			easeOutQuad: function(e) {
				return 1 - (1 - e) * (1 - e)
			},
			easeInOutQuad: function(e) {
				return e < .5 ? 2 * e * e : 1 - t(-2 * e + 2, 2) / 2
			},
			easeInCubic: function(e) {
				return e * e * e
			},
			easeOutCubic: function(e) {
				return 1 - t(1 - e, 3)
			},
			easeInOutCubic: function(e) {
				return e < .5 ? 4 * e * e * e : 1 - t(-2 * e + 2, 3) / 2
			},
			easeInQuart: function(e) {
				return e * e * e * e
			},
			easeOutQuart: function(e) {
				return 1 - t(1 - e, 4)
			},
			easeInOutQuart: function(e) {
				return e < .5 ? 8 * e * e * e * e : 1 - t(-2 * e + 2, 4) / 2
			},
			easeInQuint: function(e) {
				return e * e * e * e * e
			},
			easeOutQuint: function(e) {
				return 1 - t(1 - e, 5)
			},
			easeInOutQuint: function(e) {
				return e < .5 ? 16 * e * e * e * e * e : 1 - t(-2 * e + 2, 5) / 2
			},
			easeInSine: function(e) {
				return 1 - o(e * r / 2)
			},
			easeOutSine: function(e) {
				return i(e * r / 2)
			},
			easeInOutSine: function(e) {
				return -(o(r * e) - 1) / 2
			},
			easeInExpo: function(e) {
				return 0 === e ? 0 : t(2, 10 * e - 10)
			},
			easeOutExpo: function(e) {
				return 1 === e ? 1 : 1 - t(2, -10 * e)
			},
			easeInOutExpo: function(e) {
				return 0 === e ? 0 : 1 === e ? 1 : e < .5 ? t(2, 20 * e - 10) / 2 : (2 - t(2, -20 * e + 10)) / 2
			},
			easeInCirc: function(e) {
				return 1 - n(1 - t(e, 2))
			},
			easeOutCirc: function(e) {
				return n(1 - t(e - 1, 2))
			},
			easeInOutCirc: function(e) {
				return e < .5 ? (1 - n(1 - t(2 * e, 2))) / 2 : (n(1 - t(-2 * e + 2, 2)) + 1) / 2
			},
			easeInElastic: function(e) {
				return 0 === e ? 0 : 1 === e ? 1 : -t(2, 10 * e - 10) * i((10 * e - 10.75) * l)
			},
			easeOutElastic: function(e) {
				return 0 === e ? 0 : 1 === e ? 1 : t(2, -10 * e) * i((10 * e - .75) * l) + 1
			},
			easeInOutElastic: function(e) {
				return 0 === e ? 0 : 1 === e ? 1 : e < .5 ? -t(2, 20 * e - 10) * i((20 * e - 11.125) * c) / 2 : t(2, -20 * e + 10) * i((20 * e - 11.125) * c) / 2 + 1
			},
			easeInBack: function(e) {
				return 2.70158 * e * e * e - a * e * e
			},
			easeOutBack: function(e) {
				return 1 + 2.70158 * t(e - 1, 3) + a * t(e - 1, 2)
			},
			easeInOutBack: function(e) {
				return e < .5 ? t(2 * e, 2) * (7.189819 * e - s) / 2 : (t(2 * e - 2, 2) * ((s + 1) * (2 * e - 2) + s) + 2) / 2
			},
			easeInBounce: function(e) {
				return 1 - u(1 - e)
			},
			easeOutBounce: u,
			easeInOutBounce: function(e) {
				return e < .5 ? (1 - u(1 - 2 * e)) / 2 : (1 + u(2 * e - 1)) / 2
			}
		})
	}), function(e, t, n, i) {
		"use strict";
		var o, r = ["", "webkit", "Moz", "MS", "ms", "o"],
			a = t.createElement("div"),
			s = "function",
			l = Math.round,
			c = Math.abs,
			u = Date.now;

		function d(e, t, n) {
			return setTimeout(y(e, n), t)
		}

		function f(e, t, n) {
			return !!Array.isArray(e) && (p(e, n[t], n), !0)
		}

		function p(e, t, n) {
			var o;
			if (e)
				if (e.forEach) e.forEach(t, n);
				else if (e.length !== i)
				for (o = 0; o < e.length;) t.call(n, e[o], o, e), o++;
			else
				for (o in e) e.hasOwnProperty(o) && t.call(n, e[o], o, e)
		}

		function h(t, n, i) {
			var o = "DEPRECATED METHOD: " + n + "\n" + i + " AT \n";
			return function() {
				var n = new Error("get-stack-trace"),
					i = n && n.stack ? n.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace",
					r = e.console && (e.console.warn || e.console.log);
				return r && r.call(e.console, o, i), t.apply(this, arguments)
			}
		}
		o = "function" != typeof Object.assign ? function(e) {
			if (e === i || null === e) throw new TypeError("Cannot convert undefined or null to object");
			for (var t = Object(e), n = 1; n < arguments.length; n++) {
				var o = arguments[n];
				if (o !== i && null !== o)
					for (var r in o) o.hasOwnProperty(r) && (t[r] = o[r])
			}
			return t
		} : Object.assign;
		var m = h(function(e, t, n) {
				for (var o = Object.keys(t), r = 0; r < o.length;)(!n || n && e[o[r]] === i) && (e[o[r]] = t[o[r]]), r++;
				return e
			}, "extend", "Use `assign`."),
			g = h(function(e, t) {
				return m(e, t, !0)
			}, "merge", "Use `assign`.");

		function v(e, t, n) {
			var i, r = t.prototype;
			(i = e.prototype = Object.create(r)).constructor = e, i._super = r, n && o(i, n)
		}

		function y(e, t) {
			return function() {
				return e.apply(t, arguments)
			}
		}

		function b(e, t) {
			return typeof e == s ? e.apply(t && t[0] || i, t) : e
		}

		function E(e, t) {
			return e === i ? t : e
		}

		function T(e, t, n) {
			p(I(t), function(t) {
				e.addEventListener(t, n, !1)
			})
		}

		function w(e, t, n) {
			p(I(t), function(t) {
				e.removeEventListener(t, n, !1)
			})
		}

		function S(e, t) {
			for (; e;) {
				if (e == t) return !0;
				e = e.parentNode
			}
			return !1
		}

		function C(e, t) {
			return e.indexOf(t) > -1
		}

		function I(e) {
			return e.trim().split(/\s+/g)
		}

		function x(e, t, n) {
			if (e.indexOf && !n) return e.indexOf(t);
			for (var i = 0; i < e.length;) {
				if (n && e[i][n] == t || !n && e[i] === t) return i;
				i++
			}
			return -1
		}

		function A(e) {
			return Array.prototype.slice.call(e, 0)
		}

		function D(e, t, n) {
			for (var i = [], o = [], r = 0; r < e.length;) {
				var a = t ? e[r][t] : e[r];
				x(o, a) < 0 && i.push(e[r]), o[r] = a, r++
			}
			return n && (i = t ? i.sort(function(e, n) {
				return e[t] > n[t]
			}) : i.sort()), i
		}

		function L(e, t) {
			for (var n, o, a = t[0].toUpperCase() + t.slice(1), s = 0; s < r.length;) {
				if ((o = (n = r[s]) ? n + a : t) in e) return o;
				s++
			}
			return i
		}
		var N = 1;

		function O(t) {
			var n = t.ownerDocument || t;
			return n.defaultView || n.parentWindow || e
		}
		var M = "ontouchstart" in e,
			_ = L(e, "PointerEvent") !== i,
			R = M && /mobile|tablet|ip(ad|hone|od)|android/i.test(navigator.userAgent),
			k = 25,
			U = 1,
			P = 2,
			F = 4,
			H = 8,
			q = 1,
			$ = 2,
			G = 4,
			B = 8,
			z = 16,
			Y = $ | G,
			j = B | z,
			K = Y | j,
			W = ["x", "y"],
			V = ["clientX", "clientY"];

		function X(e, t) {
			var n = this;
			this.manager = e, this.callback = t, this.element = e.element, this.target = e.options.inputTarget, this.domHandler = function(t) {
				b(e.options.enable, [e]) && n.handler(t)
			}, this.init()
		}

		function Z(e, t, n) {
			var o = n.pointers.length,
				r = n.changedPointers.length,
				a = t & U && o - r == 0,
				s = t & (F | H) && o - r == 0;
			n.isFirst = !!a, n.isFinal = !!s, a && (e.session = {}), n.eventType = t,
				function(e, t) {
					var n = e.session,
						o = t.pointers,
						r = o.length;
					n.firstInput || (n.firstInput = Q(t));
					r > 1 && !n.firstMultiple ? n.firstMultiple = Q(t) : 1 === r && (n.firstMultiple = !1);
					var a = n.firstInput,
						s = n.firstMultiple,
						l = s ? s.center : a.center,
						d = t.center = J(o);
					t.timeStamp = u(), t.deltaTime = t.timeStamp - a.timeStamp, t.angle = ie(l, d), t.distance = ne(l, d),
						function(e, t) {
							var n = t.center,
								i = e.offsetDelta || {},
								o = e.prevDelta || {},
								r = e.prevInput || {};
							t.eventType !== U && r.eventType !== F || (o = e.prevDelta = {
								x: r.deltaX || 0,
								y: r.deltaY || 0
							}, i = e.offsetDelta = {
								x: n.x,
								y: n.y
							});
							t.deltaX = o.x + (n.x - i.x), t.deltaY = o.y + (n.y - i.y)
						}(n, t), t.offsetDirection = te(t.deltaX, t.deltaY);
					var f = ee(t.deltaTime, t.deltaX, t.deltaY);
					t.overallVelocityX = f.x, t.overallVelocityY = f.y, t.overallVelocity = c(f.x) > c(f.y) ? f.x : f.y, t.scale = s ? (p = s.pointers, h = o, ne(h[0], h[1], V) / ne(p[0], p[1], V)) : 1, t.rotation = s ? function(e, t) {
							return ie(t[1], t[0], V) + ie(e[1], e[0], V)
						}(s.pointers, o) : 0, t.maxPointers = n.prevInput ? t.pointers.length > n.prevInput.maxPointers ? t.pointers.length : n.prevInput.maxPointers : t.pointers.length,
						function(e, t) {
							var n, o, r, a, s = e.lastInterval || t,
								l = t.timeStamp - s.timeStamp;
							if (t.eventType != H && (l > k || s.velocity === i)) {
								var u = t.deltaX - s.deltaX,
									d = t.deltaY - s.deltaY,
									f = ee(l, u, d);
								o = f.x, r = f.y, n = c(f.x) > c(f.y) ? f.x : f.y, a = te(u, d), e.lastInterval = t
							} else n = s.velocity, o = s.velocityX, r = s.velocityY, a = s.direction;
							t.velocity = n, t.velocityX = o, t.velocityY = r, t.direction = a
						}(n, t);
					var p, h;
					var m = e.element;
					S(t.srcEvent.target, m) && (m = t.srcEvent.target);
					t.target = m
				}(e, n), e.emit("hammer.input", n), e.recognize(n), e.session.prevInput = n
		}

		function Q(e) {
			for (var t = [], n = 0; n < e.pointers.length;) t[n] = {
				clientX: l(e.pointers[n].clientX),
				clientY: l(e.pointers[n].clientY)
			}, n++;
			return {
				timeStamp: u(),
				pointers: t,
				center: J(t),
				deltaX: e.deltaX,
				deltaY: e.deltaY
			}
		}

		function J(e) {
			var t = e.length;
			if (1 === t) return {
				x: l(e[0].clientX),
				y: l(e[0].clientY)
			};
			for (var n = 0, i = 0, o = 0; o < t;) n += e[o].clientX, i += e[o].clientY, o++;
			return {
				x: l(n / t),
				y: l(i / t)
			}
		}

		function ee(e, t, n) {
			return {
				x: t / e || 0,
				y: n / e || 0
			}
		}

		function te(e, t) {
			return e === t ? q : c(e) >= c(t) ? e < 0 ? $ : G : t < 0 ? B : z
		}

		function ne(e, t, n) {
			n || (n = W);
			var i = t[n[0]] - e[n[0]],
				o = t[n[1]] - e[n[1]];
			return Math.sqrt(i * i + o * o)
		}

		function ie(e, t, n) {
			n || (n = W);
			var i = t[n[0]] - e[n[0]],
				o = t[n[1]] - e[n[1]];
			return 180 * Math.atan2(o, i) / Math.PI
		}
		X.prototype = {
			handler: function() {},
			init: function() {
				this.evEl && T(this.element, this.evEl, this.domHandler), this.evTarget && T(this.target, this.evTarget, this.domHandler), this.evWin && T(O(this.element), this.evWin, this.domHandler)
			},
			destroy: function() {
				this.evEl && w(this.element, this.evEl, this.domHandler), this.evTarget && w(this.target, this.evTarget, this.domHandler), this.evWin && w(O(this.element), this.evWin, this.domHandler)
			}
		};
		var oe = {
				mousedown: U,
				mousemove: P,
				mouseup: F
			},
			re = "mousedown",
			ae = "mousemove mouseup";

		function se() {
			this.evEl = re, this.evWin = ae, this.pressed = !1, X.apply(this, arguments)
		}
		v(se, X, {
			handler: function(e) {
				var t = oe[e.type];
				t & U && 0 === e.button && (this.pressed = !0), t & P && 1 !== e.which && (t = F), this.pressed && (t & F && (this.pressed = !1), this.callback(this.manager, t, {
					pointers: [e],
					changedPointers: [e],
					pointerType: "mouse",
					srcEvent: e
				}))
			}
		});
		var le = {
				pointerdown: U,
				pointermove: P,
				pointerup: F,
				pointercancel: H,
				pointerout: H
			},
			ce = {
				2: "touch",
				3: "pen",
				4: "mouse",
				5: "kinect"
			},
			ue = "pointerdown",
			de = "pointermove pointerup pointercancel";

		function fe() {
			this.evEl = ue, this.evWin = de, X.apply(this, arguments), this.store = this.manager.session.pointerEvents = []
		}
		e.MSPointerEvent && !e.PointerEvent && (ue = "MSPointerDown", de = "MSPointerMove MSPointerUp MSPointerCancel"), v(fe, X, {
			handler: function(e) {
				var t = this.store,
					n = !1,
					i = e.type.toLowerCase().replace("ms", ""),
					o = le[i],
					r = ce[e.pointerType] || e.pointerType,
					a = "touch" == r,
					s = x(t, e.pointerId, "pointerId");
				o & U && (0 === e.button || a) ? s < 0 && (t.push(e), s = t.length - 1) : o & (F | H) && (n = !0), s < 0 || (t[s] = e, this.callback(this.manager, o, {
					pointers: t,
					changedPointers: [e],
					pointerType: r,
					srcEvent: e
				}), n && t.splice(s, 1))
			}
		});
		var pe = {
				touchstart: U,
				touchmove: P,
				touchend: F,
				touchcancel: H
			},
			he = "touchstart",
			me = "touchstart touchmove touchend touchcancel";

		function ge() {
			this.evTarget = he, this.evWin = me, this.started = !1, X.apply(this, arguments)
		}
		v(ge, X, {
			handler: function(e) {
				var t = pe[e.type];
				if (t === U && (this.started = !0), this.started) {
					var n = function(e, t) {
						var n = A(e.touches),
							i = A(e.changedTouches);
						t & (F | H) && (n = D(n.concat(i), "identifier", !0));
						return [n, i]
					}.call(this, e, t);
					t & (F | H) && n[0].length - n[1].length == 0 && (this.started = !1), this.callback(this.manager, t, {
						pointers: n[0],
						changedPointers: n[1],
						pointerType: "touch",
						srcEvent: e
					})
				}
			}
		});
		var ve = {
				touchstart: U,
				touchmove: P,
				touchend: F,
				touchcancel: H
			},
			ye = "touchstart touchmove touchend touchcancel";

		function be() {
			this.evTarget = ye, this.targetIds = {}, X.apply(this, arguments)
		}
		v(be, X, {
			handler: function(e) {
				var t = ve[e.type],
					n = function(e, t) {
						var n = A(e.touches),
							i = this.targetIds;
						if (t & (U | P) && 1 === n.length) return i[n[0].identifier] = !0, [n, n];
						var o, r, a = A(e.changedTouches),
							s = [],
							l = this.target;
						if (r = n.filter(function(e) {
								return S(e.target, l)
							}), t === U)
							for (o = 0; o < r.length;) i[r[o].identifier] = !0, o++;
						o = 0;
						for (; o < a.length;) i[a[o].identifier] && s.push(a[o]), t & (F | H) && delete i[a[o].identifier], o++;
						if (!s.length) return;
						return [D(r.concat(s), "identifier", !0), s]
					}.call(this, e, t);
				n && this.callback(this.manager, t, {
					pointers: n[0],
					changedPointers: n[1],
					pointerType: "touch",
					srcEvent: e
				})
			}
		});
		var Ee = 2500,
			Te = 25;

		function we() {
			X.apply(this, arguments);
			var e = y(this.handler, this);
			this.touch = new be(this.manager, e), this.mouse = new se(this.manager, e), this.primaryTouch = null, this.lastTouches = []
		}

		function Se(e) {
			var t = e.changedPointers[0];
			if (t.identifier === this.primaryTouch) {
				var n = {
					x: t.clientX,
					y: t.clientY
				};
				this.lastTouches.push(n);
				var i = this.lastTouches;
				setTimeout(function() {
					var e = i.indexOf(n);
					e > -1 && i.splice(e, 1)
				}, Ee)
			}
		}
		v(we, X, {
			handler: function(e, t, n) {
				var i = "touch" == n.pointerType,
					o = "mouse" == n.pointerType;
				if (!(o && n.sourceCapabilities && n.sourceCapabilities.firesTouchEvents)) {
					if (i)(function(e, t) {
						e & U ? (this.primaryTouch = t.changedPointers[0].identifier, Se.call(this, t)) : e & (F | H) && Se.call(this, t)
					}).call(this, t, n);
					else if (o && function(e) {
							for (var t = e.srcEvent.clientX, n = e.srcEvent.clientY, i = 0; i < this.lastTouches.length; i++) {
								var o = this.lastTouches[i],
									r = Math.abs(t - o.x),
									a = Math.abs(n - o.y);
								if (r <= Te && a <= Te) return !0
							}
							return !1
						}.call(this, n)) return;
					this.callback(e, t, n)
				}
			},
			destroy: function() {
				this.touch.destroy(), this.mouse.destroy()
			}
		});
		var Ce = L(a.style, "touchAction"),
			Ie = Ce !== i,
			xe = "auto",
			Ae = "manipulation",
			De = "none",
			Le = "pan-x",
			Ne = "pan-y",
			Oe = function() {
				if (!Ie) return !1;
				var t = {},
					n = e.CSS && e.CSS.supports;
				return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function(i) {
					t[i] = !n || e.CSS.supports("touch-action", i)
				}), t
			}();

		function Me(e, t) {
			this.manager = e, this.set(t)
		}
		Me.prototype = {
			set: function(e) {
				"compute" == e && (e = this.compute()), Ie && this.manager.element.style && Oe[e] && (this.manager.element.style[Ce] = e), this.actions = e.toLowerCase().trim()
			},
			update: function() {
				this.set(this.manager.options.touchAction)
			},
			compute: function() {
				var e = [];
				return p(this.manager.recognizers, function(t) {
						b(t.options.enable, [t]) && (e = e.concat(t.getTouchAction()))
					}),
					function(e) {
						if (C(e, De)) return De;
						var t = C(e, Le),
							n = C(e, Ne);
						if (t && n) return De;
						if (t || n) return t ? Le : Ne;
						if (C(e, Ae)) return Ae;
						return xe
					}(e.join(" "))
			},
			preventDefaults: function(e) {
				var t = e.srcEvent,
					n = e.offsetDirection;
				if (this.manager.session.prevented) t.preventDefault();
				else {
					var i = this.actions,
						o = C(i, De) && !Oe[De],
						r = C(i, Ne) && !Oe[Ne],
						a = C(i, Le) && !Oe[Le];
					if (o) {
						var s = 1 === e.pointers.length,
							l = e.distance < 2,
							c = e.deltaTime < 250;
						if (s && l && c) return
					}
					if (!a || !r) return o || r && n & Y || a && n & j ? this.preventSrc(t) : void 0
				}
			},
			preventSrc: function(e) {
				this.manager.session.prevented = !0, e.preventDefault()
			}
		};
		var _e = 1,
			Re = 2,
			ke = 4,
			Ue = 8,
			Pe = Ue,
			Fe = 16;

		function He(e) {
			this.options = o({}, this.defaults, e || {}), this.id = N++, this.manager = null, this.options.enable = E(this.options.enable, !0), this.state = _e, this.simultaneous = {}, this.requireFail = []
		}

		function qe(e) {
			return e & Fe ? "cancel" : e & Ue ? "end" : e & ke ? "move" : e & Re ? "start" : ""
		}

		function $e(e) {
			return e == z ? "down" : e == B ? "up" : e == $ ? "left" : e == G ? "right" : ""
		}

		function Ge(e, t) {
			var n = t.manager;
			return n ? n.get(e) : e
		}

		function Be() {
			He.apply(this, arguments)
		}

		function ze() {
			Be.apply(this, arguments), this.pX = null, this.pY = null
		}

		function Ye() {
			Be.apply(this, arguments)
		}

		function je() {
			He.apply(this, arguments), this._timer = null, this._input = null
		}

		function Ke() {
			Be.apply(this, arguments)
		}

		function We() {
			Be.apply(this, arguments)
		}

		function Ve() {
			He.apply(this, arguments), this.pTime = !1, this.pCenter = !1, this._timer = null, this._input = null, this.count = 0
		}

		function Xe(e, t) {
			return (t = t || {}).recognizers = E(t.recognizers, Xe.defaults.preset), new Ze(e, t)
		}
		He.prototype = {
			defaults: {},
			set: function(e) {
				return o(this.options, e), this.manager && this.manager.touchAction.update(), this
			},
			recognizeWith: function(e) {
				if (f(e, "recognizeWith", this)) return this;
				var t = this.simultaneous;
				return t[(e = Ge(e, this)).id] || (t[e.id] = e, e.recognizeWith(this)), this
			},
			dropRecognizeWith: function(e) {
				return f(e, "dropRecognizeWith", this) ? this : (e = Ge(e, this), delete this.simultaneous[e.id], this)
			},
			requireFailure: function(e) {
				if (f(e, "requireFailure", this)) return this;
				var t = this.requireFail;
				return -1 === x(t, e = Ge(e, this)) && (t.push(e), e.requireFailure(this)), this
			},
			dropRequireFailure: function(e) {
				if (f(e, "dropRequireFailure", this)) return this;
				e = Ge(e, this);
				var t = x(this.requireFail, e);
				return t > -1 && this.requireFail.splice(t, 1), this
			},
			hasRequireFailures: function() {
				return this.requireFail.length > 0
			},
			canRecognizeWith: function(e) {
				return !!this.simultaneous[e.id]
			},
			emit: function(e) {
				var t = this,
					n = this.state;

				function i(n) {
					t.manager.emit(n, e)
				}
				n < Ue && i(t.options.event + qe(n)), i(t.options.event), e.additionalEvent && i(e.additionalEvent), n >= Ue && i(t.options.event + qe(n))
			},
			tryEmit: function(e) {
				if (this.canEmit()) return this.emit(e);
				this.state = 32
			},
			canEmit: function() {
				for (var e = 0; e < this.requireFail.length;) {
					if (!(this.requireFail[e].state & (32 | _e))) return !1;
					e++
				}
				return !0
			},
			recognize: function(e) {
				var t = o({}, e);
				if (!b(this.options.enable, [this, t])) return this.reset(), void(this.state = 32);
				this.state & (Pe | Fe | 32) && (this.state = _e), this.state = this.process(t), this.state & (Re | ke | Ue | Fe) && this.tryEmit(t)
			},
			process: function(e) {},
			getTouchAction: function() {},
			reset: function() {}
		}, v(Be, He, {
			defaults: {
				pointers: 1
			},
			attrTest: function(e) {
				var t = this.options.pointers;
				return 0 === t || e.pointers.length === t
			},
			process: function(e) {
				var t = this.state,
					n = e.eventType,
					i = t & (Re | ke),
					o = this.attrTest(e);
				return i && (n & H || !o) ? t | Fe : i || o ? n & F ? t | Ue : t & Re ? t | ke : Re : 32
			}
		}), v(ze, Be, {
			defaults: {
				event: "pan",
				threshold: 10,
				pointers: 1,
				direction: K
			},
			getTouchAction: function() {
				var e = this.options.direction,
					t = [];
				return e & Y && t.push(Ne), e & j && t.push(Le), t
			},
			directionTest: function(e) {
				var t = this.options,
					n = !0,
					i = e.distance,
					o = e.direction,
					r = e.deltaX,
					a = e.deltaY;
				return o & t.direction || (t.direction & Y ? (o = 0 === r ? q : r < 0 ? $ : G, n = r != this.pX, i = Math.abs(e.deltaX)) : (o = 0 === a ? q : a < 0 ? B : z, n = a != this.pY, i = Math.abs(e.deltaY))), e.direction = o, n && i > t.threshold && o & t.direction
			},
			attrTest: function(e) {
				return Be.prototype.attrTest.call(this, e) && (this.state & Re || !(this.state & Re) && this.directionTest(e))
			},
			emit: function(e) {
				this.pX = e.deltaX, this.pY = e.deltaY;
				var t = $e(e.direction);
				t && (e.additionalEvent = this.options.event + t), this._super.emit.call(this, e)
			}
		}), v(Ye, Be, {
			defaults: {
				event: "pinch",
				threshold: 0,
				pointers: 2
			},
			getTouchAction: function() {
				return [De]
			},
			attrTest: function(e) {
				return this._super.attrTest.call(this, e) && (Math.abs(e.scale - 1) > this.options.threshold || this.state & Re)
			},
			emit: function(e) {
				if (1 !== e.scale) {
					var t = e.scale < 1 ? "in" : "out";
					e.additionalEvent = this.options.event + t
				}
				this._super.emit.call(this, e)
			}
		}), v(je, He, {
			defaults: {
				event: "press",
				pointers: 1,
				time: 251,
				threshold: 9
			},
			getTouchAction: function() {
				return [xe]
			},
			process: function(e) {
				var t = this.options,
					n = e.pointers.length === t.pointers,
					i = e.distance < t.threshold,
					o = e.deltaTime > t.time;
				if (this._input = e, !i || !n || e.eventType & (F | H) && !o) this.reset();
				else if (e.eventType & U) this.reset(), this._timer = d(function() {
					this.state = Pe, this.tryEmit()
				}, t.time, this);
				else if (e.eventType & F) return Pe;
				return 32
			},
			reset: function() {
				clearTimeout(this._timer)
			},
			emit: function(e) {
				this.state === Pe && (e && e.eventType & F ? this.manager.emit(this.options.event + "up", e) : (this._input.timeStamp = u(), this.manager.emit(this.options.event, this._input)))
			}
		}), v(Ke, Be, {
			defaults: {
				event: "rotate",
				threshold: 0,
				pointers: 2
			},
			getTouchAction: function() {
				return [De]
			},
			attrTest: function(e) {
				return this._super.attrTest.call(this, e) && (Math.abs(e.rotation) > this.options.threshold || this.state & Re)
			}
		}), v(We, Be, {
			defaults: {
				event: "swipe",
				threshold: 10,
				velocity: .3,
				direction: Y | j,
				pointers: 1
			},
			getTouchAction: function() {
				return ze.prototype.getTouchAction.call(this)
			},
			attrTest: function(e) {
				var t, n = this.options.direction;
				return n & (Y | j) ? t = e.overallVelocity : n & Y ? t = e.overallVelocityX : n & j && (t = e.overallVelocityY), this._super.attrTest.call(this, e) && n & e.offsetDirection && e.distance > this.options.threshold && e.maxPointers == this.options.pointers && c(t) > this.options.velocity && e.eventType & F
			},
			emit: function(e) {
				var t = $e(e.offsetDirection);
				t && this.manager.emit(this.options.event + t, e), this.manager.emit(this.options.event, e)
			}
		}), v(Ve, He, {
			defaults: {
				event: "tap",
				pointers: 1,
				taps: 1,
				interval: 300,
				time: 250,
				threshold: 9,
				posThreshold: 10
			},
			getTouchAction: function() {
				return [Ae]
			},
			process: function(e) {
				var t = this.options,
					n = e.pointers.length === t.pointers,
					i = e.distance < t.threshold,
					o = e.deltaTime < t.time;
				if (this.reset(), e.eventType & U && 0 === this.count) return this.failTimeout();
				if (i && o && n) {
					if (e.eventType != F) return this.failTimeout();
					var r = !this.pTime || e.timeStamp - this.pTime < t.interval,
						a = !this.pCenter || ne(this.pCenter, e.center) < t.posThreshold;
					if (this.pTime = e.timeStamp, this.pCenter = e.center, a && r ? this.count += 1 : this.count = 1, this._input = e, 0 === this.count % t.taps) return this.hasRequireFailures() ? (this._timer = d(function() {
						this.state = Pe, this.tryEmit()
					}, t.interval, this), Re) : Pe
				}
				return 32
			},
			failTimeout: function() {
				return this._timer = d(function() {
					this.state = 32
				}, this.options.interval, this), 32
			},
			reset: function() {
				clearTimeout(this._timer)
			},
			emit: function() {
				this.state == Pe && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input))
			}
		}), Xe.VERSION = "2.0.7", Xe.defaults = {
			domEvents: !1,
			touchAction: "compute",
			enable: !0,
			inputTarget: null,
			inputClass: null,
			preset: [
				[Ke, {
					enable: !1
				}],
				[Ye, {
						enable: !1
					},
					["rotate"]
				],
				[We, {
					direction: Y
				}],
				[ze, {
						direction: Y
					},
					["swipe"]
				],
				[Ve],
				[Ve, {
						event: "doubletap",
						taps: 2
					},
					["tap"]
				],
				[je]
			],
			cssProps: {
				userSelect: "none",
				touchSelect: "none",
				touchCallout: "none",
				contentZooming: "none",
				userDrag: "none",
				tapHighlightColor: "rgba(0,0,0,0)"
			}
		};

		function Ze(e, t) {
			var n;
			this.options = o({}, Xe.defaults, t || {}), this.options.inputTarget = this.options.inputTarget || e, this.handlers = {}, this.session = {}, this.recognizers = [], this.oldCssProps = {}, this.element = e, this.input = new((n = this).options.inputClass || (_ ? fe : R ? be : M ? we : se))(n, Z), this.touchAction = new Me(this, this.options.touchAction), Qe(this, !0), p(this.options.recognizers, function(e) {
				var t = this.add(new e[0](e[1]));
				e[2] && t.recognizeWith(e[2]), e[3] && t.requireFailure(e[3])
			}, this)
		}

		function Qe(e, t) {
			var n, i = e.element;
			i.style && (p(e.options.cssProps, function(o, r) {
				n = L(i.style, r), t ? (e.oldCssProps[n] = i.style[n], i.style[n] = o) : i.style[n] = e.oldCssProps[n] || ""
			}), t || (e.oldCssProps = {}))
		}
		Ze.prototype = {
			set: function(e) {
				return o(this.options, e), e.touchAction && this.touchAction.update(), e.inputTarget && (this.input.destroy(), this.input.target = e.inputTarget, this.input.init()), this
			},
			stop: function(e) {
				this.session.stopped = e ? 2 : 1
			},
			recognize: function(e) {
				var t = this.session;
				if (!t.stopped) {
					var n;
					this.touchAction.preventDefaults(e);
					var i = this.recognizers,
						o = t.curRecognizer;
					(!o || o && o.state & Pe) && (o = t.curRecognizer = null);
					for (var r = 0; r < i.length;) n = i[r], 2 === t.stopped || o && n != o && !n.canRecognizeWith(o) ? n.reset() : n.recognize(e), !o && n.state & (Re | ke | Ue) && (o = t.curRecognizer = n), r++
				}
			},
			get: function(e) {
				if (e instanceof He) return e;
				for (var t = this.recognizers, n = 0; n < t.length; n++)
					if (t[n].options.event == e) return t[n];
				return null
			},
			add: function(e) {
				if (f(e, "add", this)) return this;
				var t = this.get(e.options.event);
				return t && this.remove(t), this.recognizers.push(e), e.manager = this, this.touchAction.update(), e
			},
			remove: function(e) {
				if (f(e, "remove", this)) return this;
				if (e = this.get(e)) {
					var t = this.recognizers,
						n = x(t, e); - 1 !== n && (t.splice(n, 1), this.touchAction.update())
				}
				return this
			},
			on: function(e, t) {
				if (e !== i && t !== i) {
					var n = this.handlers;
					return p(I(e), function(e) {
						n[e] = n[e] || [], n[e].push(t)
					}), this
				}
			},
			off: function(e, t) {
				if (e !== i) {
					var n = this.handlers;
					return p(I(e), function(e) {
						t ? n[e] && n[e].splice(x(n[e], t), 1) : delete n[e]
					}), this
				}
			},
			emit: function(e, n) {
				this.options.domEvents && function(e, n) {
					var i = t.createEvent("Event");
					i.initEvent(e, !0, !0), i.gesture = n, n.target.dispatchEvent(i)
				}(e, n);
				var i = this.handlers[e] && this.handlers[e].slice();
				if (i && i.length) {
					n.type = e, n.preventDefault = function() {
						n.srcEvent.preventDefault()
					};
					for (var o = 0; o < i.length;) i[o](n), o++
				}
			},
			destroy: function() {
				this.element && Qe(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null
			}
		}, o(Xe, {
			INPUT_START: U,
			INPUT_MOVE: P,
			INPUT_END: F,
			INPUT_CANCEL: H,
			STATE_POSSIBLE: _e,
			STATE_BEGAN: Re,
			STATE_CHANGED: ke,
			STATE_ENDED: Ue,
			STATE_RECOGNIZED: Pe,
			STATE_CANCELLED: Fe,
			STATE_FAILED: 32,
			DIRECTION_NONE: q,
			DIRECTION_LEFT: $,
			DIRECTION_RIGHT: G,
			DIRECTION_UP: B,
			DIRECTION_DOWN: z,
			DIRECTION_HORIZONTAL: Y,
			DIRECTION_VERTICAL: j,
			DIRECTION_ALL: K,
			Manager: Ze,
			Input: X,
			TouchAction: Me,
			TouchInput: be,
			MouseInput: se,
			PointerEventInput: fe,
			TouchMouseInput: we,
			SingleTouchInput: ge,
			Recognizer: He,
			AttrRecognizer: Be,
			Tap: Ve,
			Pan: ze,
			Swipe: We,
			Pinch: Ye,
			Rotate: Ke,
			Press: je,
			on: T,
			off: w,
			each: p,
			merge: g,
			extend: m,
			assign: o,
			inherit: v,
			bindFn: y,
			prefixed: L
		}), (void 0 !== e ? e : "undefined" != typeof self ? self : {}).Hammer = Xe, "function" == typeof define && define.amd ? define(function() {
			return Xe
		}) : "undefined" != typeof module && module.exports ? module.exports = Xe : e.Hammer = Xe
	}(window, document), function(e) {
		"function" == typeof define && define.amd ? define(["jquery", "hammerjs"], e) : "object" == typeof exports ? e(require("jquery"), require("hammerjs")) : e(jQuery, Hammer)
	}(function(e, t) {
		var n;
		e.fn.hammer = function(n) {
			return this.each(function() {
				! function(n, i) {
					var o = e(n);
					o.data("hammer") || o.data("hammer", new t(o[0], i))
				}(this, n)
			})
		}, t.Manager.prototype.emit = (n = t.Manager.prototype.emit, function(t, i) {
			n.call(this, t, i), e(this.element).trigger({
				type: t,
				gesture: i
			})
		})
	}), function(e) {
		"function" == typeof define && define.amd ? define(["jquery"], e) : "object" == typeof exports ? module.exports = e(require("jquery")) : e(jQuery)
	}(function(e) {
		"use strict";
		var t = "tinyscrollbar",
			n = {
				axis: "y",
				wheel: !0,
				wheelSpeed: 40,
				wheelLock: !0,
				touchLock: !0,
				trackSize: !1,
				thumbSize: !1,
				thumbSizeMin: 20
			};

		function i(i, o) {
			this.options = e.extend({}, n, o), this._defaults = n, this._name = t;
			var r = this,
				a = i.find(".viewport"),
				s = i.find(".overview"),
				l = i.find(".scrollbar"),
				c = l.find(".track"),
				u = l.find(".thumb"),
				d = "ontouchstart" in document.documentElement,
				f = "onwheel" in document.createElement("div") ? "wheel" : void 0 !== document.onmousewheel ? "mousewheel" : "DOMMouseScroll",
				p = "x" === this.options.axis,
				h = p ? "width" : "height",
				m = p ? "left" : "top",
				g = 0;

			function v() {
				return r.contentPosition > 0
			}

			function y() {
				return r.contentPosition <= r.contentSize - r.viewportSize - 5
			}

			function b(t, n) {
				r.hasContentToSroll && (e("body").addClass("noSelect"), g = n ? u.offset()[m] : p ? t.pageX : t.pageY, d ? (document.ontouchmove = function(e) {
					(r.options.touchLock || v() && y()) && e.preventDefault(), T(e.touches[0])
				}, document.ontouchend = w) : (e(document).bind("mousemove", T), e(document).bind("mouseup", w), u.bind("mouseup", w), c.bind("mouseup", w)), T(t))
			}

			function E(t) {
				if (r.hasContentToSroll) {
					var n = t || window.event,
						o = -(n.deltaY || n.detail || -1 / 3 * n.wheelDelta) / 40,
						a = 1 === n.deltaMode ? r.options.wheelSpeed : 1;
					r.contentPosition -= o * a * r.options.wheelSpeed, r.contentPosition = Math.min(r.contentSize - r.viewportSize, Math.max(0, r.contentPosition)), r.thumbPosition = r.contentPosition / r.trackRatio, i.trigger("move"), u.css(m, r.thumbPosition), s.css(m, -r.contentPosition), (r.options.wheelLock || v() && y()) && (n = e.event.fix(n)).preventDefault()
				}
			}

			function T(e) {
				if (r.hasContentToSroll) {
					var t = p ? e.pageX : e.pageY,
						n = d ? g - t : t - g,
						o = Math.min(r.trackSize - r.thumbSize, Math.max(0, r.thumbPosition + n));
					r.contentPosition = o * r.trackRatio, i.trigger("move"), u.css(m, o), s.css(m, -r.contentPosition)
				}
			}

			function w() {
				r.thumbPosition = parseInt(u.css(m), 10) || 0, e("body").removeClass("noSelect"), e(document).unbind("mousemove", T), e(document).unbind("mouseup", w), u.unbind("mouseup", w), c.unbind("mouseup", w), document.ontouchmove = document.ontouchend = null
			}
			return this.contentPosition = 0, this.viewportSize = 0, this.contentSize = 0, this.contentRatio = 0, this.trackSize = 0, this.trackRatio = 0, this.thumbSize = 0, this.thumbPosition = 0, this.hasContentToSroll = !1, this.update = function(e) {
				var t = h.charAt(0).toUpperCase() + h.slice(1).toLowerCase();
				switch (this.viewportSize = a[0]["offset" + t], this.contentSize = s[0]["scroll" + t], this.contentRatio = this.viewportSize / this.contentSize, this.trackSize = this.options.trackSize || this.viewportSize, this.thumbSize = Math.min(this.trackSize, Math.max(this.options.thumbSizeMin, this.options.thumbSize || this.trackSize * this.contentRatio)), this.trackRatio = (this.contentSize - this.viewportSize) / (this.trackSize - this.thumbSize), this.hasContentToSroll = this.contentRatio < 1, l.toggleClass("disable", !this.hasContentToSroll), e) {
					case "bottom":
						this.contentPosition = Math.max(this.contentSize - this.viewportSize, 0);
						break;
					case "relative":
						this.contentPosition = Math.min(Math.max(this.contentSize - this.viewportSize, 0), Math.max(0, this.contentPosition));
						break;
					default:
						this.contentPosition = parseInt(e, 10) || 0
				}
				return this.thumbPosition = this.contentPosition / this.trackRatio, u.css(m, r.thumbPosition), s.css(m, -r.contentPosition), l.css(h, r.trackSize), c.css(h, r.trackSize), u.css(h, r.thumbSize), r
			}, r.update(), d ? a[0].ontouchstart = function(e) {
				1 === e.touches.length && (e.stopPropagation(), b(e.touches[0]))
			} : (u.bind("mousedown", function(e) {
				e.stopPropagation(), b(e)
			}), c.bind("mousedown", function(e) {
				b(e, !0)
			})), e(window).resize(function() {
				r.update("relative")
			}), r.options.wheel && window.addEventListener ? i[0].addEventListener(f, E, !1) : r.options.wheel && (i[0].onmousewheel = E), r
		}
		e.fn[t] = function(n) {
			return this.each(function() {
				e.data(this, "plugin_" + t) || e.data(this, "plugin_" + t, new i(e(this), n))
			})
		}
	}), function(e, t) {
		"function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : e.PhotoSwipeUI_Default = t()
	}(this, function() {
		"use strict";
		return function(e, t) {
			var n, i, o, r, a, s, l, c, u, d, f, p, h, m, g, v, y, b, E = this,
				T = !1,
				w = !0,
				S = !0,
				C = {
					barsSize: {
						top: 44,
						bottom: "auto"
					},
					closeElClasses: ["item", "caption", "zoom-wrap", "ui", "top-bar"],
					timeToIdle: 4e3,
					timeToIdleOutside: 1e3,
					loadingIndicatorDelay: 1e3,
					addCaptionHTMLFn: function(e, t) {
						return e.title ? (t.children[0].innerHTML = e.title, !0) : (t.children[0].innerHTML = "", !1)
					},
					closeEl: !0,
					captionEl: !0,
					fullscreenEl: !0,
					zoomEl: !0,
					shareEl: !0,
					counterEl: !0,
					arrowEl: !0,
					preloaderEl: !0,
					tapToClose: !1,
					tapToToggleControls: !0,
					clickToCloseNonZoomable: !0,
					shareButtons: [{
						id: "facebook",
						label: "Share on Facebook",
						url: "https://www.facebook.com/sharer/sharer.php?u={{url}}"
					}, {
						id: "twitter",
						label: "Tweet",
						url: "https://twitter.com/intent/tweet?text={{text}}&url={{url}}"
					}, {
						id: "pinterest",
						label: "Pin it",
						url: "http://www.pinterest.com/pin/create/button/?url={{url}}&media={{image_url}}&description={{text}}"
					}, {
						id: "download",
						label: "Download image",
						url: "{{raw_image_url}}",
						download: !0
					}],
					getImageURLForShare: function() {
						return e.currItem.src || ""
					},
					getPageURLForShare: function() {
						return window.location.href
					},
					getTextForShare: function() {
						return e.currItem.title || ""
					},
					indexIndicatorSep: " / ",
					fitControlsWidth: 1200
				},
				I = function(e) {
					if (v) return !0;
					e = e || window.event, g.timeToIdle && g.mouseUsed && !u && k();
					for (var n, i, o = (e.target || e.srcElement).getAttribute("class") || "", r = 0; r < H.length; r++)(n = H[r]).onTap && o.indexOf("pswp__" + n.name) > -1 && (n.onTap(), i = !0);
					if (i) {
						e.stopPropagation && e.stopPropagation(), v = !0;
						var a = t.features.isOldAndroid ? 600 : 30;
						setTimeout(function() {
							v = !1
						}, a)
					}
				},
				x = function() {
					return !e.likelyTouchDevice || g.mouseUsed || screen.width > g.fitControlsWidth
				},
				A = function(e, n, i) {
					t[(i ? "add" : "remove") + "Class"](e, "pswp__" + n)
				},
				D = function() {
					var e = 1 === g.getNumItemsFn();
					e !== m && (A(i, "ui--one-slide", e), m = e)
				},
				L = function() {
					A(l, "share-modal--hidden", S)
				},
				N = function() {
					return (S = !S) ? (t.removeClass(l, "pswp__share-modal--fade-in"), setTimeout(function() {
						S && L()
					}, 300)) : (L(), setTimeout(function() {
						S || t.addClass(l, "pswp__share-modal--fade-in")
					}, 30)), S || M(), !1
				},
				O = function(t) {
					var n = (t = t || window.event).target || t.srcElement;
					return e.shout("shareLinkClick", t, n), !(!n.href || !n.hasAttribute("download") && (window.open(n.href, "pswp_share", "scrollbars=yes,resizable=yes,toolbar=no,location=yes,width=550,height=420,top=100,left=" + (window.screen ? Math.round(screen.width / 2 - 275) : 100)), S || N(), 1))
				},
				M = function() {
					for (var e, t, n, i, o = "", r = 0; r < g.shareButtons.length; r++) e = g.shareButtons[r], t = g.getImageURLForShare(e), n = g.getPageURLForShare(e), i = g.getTextForShare(e), o += '<a href="' + e.url.replace("{{url}}", encodeURIComponent(n)).replace("{{image_url}}", encodeURIComponent(t)).replace("{{raw_image_url}}", t).replace("{{text}}", encodeURIComponent(i)) + '" target="_blank" class="pswp__share--' + e.id + '"' + (e.download ? "download" : "") + ">" + e.label + "</a>", g.parseShareButtonOut && (o = g.parseShareButtonOut(e, o));
					l.children[0].innerHTML = o, l.children[0].onclick = O
				},
				_ = function(e) {
					for (var n = 0; n < g.closeElClasses.length; n++)
						if (t.hasClass(e, "pswp__" + g.closeElClasses[n])) return !0
				},
				R = 0,
				k = function() {
					clearTimeout(b), R = 0, u && E.setIdle(!1)
				},
				U = function(e) {
					var t = (e = e || window.event).relatedTarget || e.toElement;
					t && "HTML" !== t.nodeName || (clearTimeout(b), b = setTimeout(function() {
						E.setIdle(!0)
					}, g.timeToIdleOutside))
				},
				P = function(e) {
					p !== e && (A(f, "preloader--active", !e), p = e)
				},
				F = function(e) {
					var n = e.vGap;
					if (x()) {
						var a = g.barsSize;
						if (g.captionEl && "auto" === a.bottom)
							if (r || ((r = t.createEl("pswp__caption pswp__caption--fake")).appendChild(t.createEl("pswp__caption__center")), i.insertBefore(r, o), t.addClass(i, "pswp__ui--fit")), g.addCaptionHTMLFn(e, r, !0)) {
								var s = r.clientHeight;
								n.bottom = parseInt(s, 10) || 44
							} else n.bottom = a.top;
						else n.bottom = "auto" === a.bottom ? 0 : a.bottom;
						n.top = a.top
					} else n.top = n.bottom = 0
				},
				H = [{
					name: "caption",
					option: "captionEl",
					onInit: function(e) {
						o = e
					}
				}, {
					name: "share-modal",
					option: "shareEl",
					onInit: function(e) {
						l = e
					},
					onTap: function() {
						N()
					}
				}, {
					name: "button--share",
					option: "shareEl",
					onInit: function(e) {
						s = e
					},
					onTap: function() {
						N()
					}
				}, {
					name: "button--zoom",
					option: "zoomEl",
					onTap: e.toggleDesktopZoom
				}, {
					name: "counter",
					option: "counterEl",
					onInit: function(e) {
						a = e
					}
				}, {
					name: "button--close",
					option: "closeEl",
					onTap: e.close
				}, {
					name: "button--arrow--left",
					option: "arrowEl",
					onTap: e.prev
				}, {
					name: "button--arrow--right",
					option: "arrowEl",
					onTap: e.next
				}, {
					name: "button--fs",
					option: "fullscreenEl",
					onTap: function() {
						n.isFullscreen() ? n.exit() : n.enter()
					}
				}, {
					name: "preloader",
					option: "preloaderEl",
					onInit: function(e) {
						f = e
					}
				}];
			E.init = function() {
				t.extend(e.options, C, !0), g = e.options, i = t.getChildByClass(e.scrollWrap, "pswp__ui"), d = e.listen,
					function() {
						var e;
						d("onVerticalDrag", function(e) {
							w && e < .95 ? E.hideControls() : !w && e >= .95 && E.showControls()
						}), d("onPinchClose", function(t) {
							w && t < .9 ? (E.hideControls(), e = !0) : e && !w && t > .9 && E.showControls()
						}), d("zoomGestureEnded", function() {
							(e = !1) && !w && E.showControls()
						})
					}(), d("beforeChange", E.update), d("doubleTap", function(t) {
						var n = e.currItem.initialZoomLevel;
						e.getZoomLevel() !== n ? e.zoomTo(n, t, 333) : e.zoomTo(g.getDoubleTapZoom(!1, e.currItem), t, 333)
					}), d("preventDragEvent", function(e, t, n) {
						var i = e.target || e.srcElement;
						i && i.getAttribute("class") && e.type.indexOf("mouse") > -1 && (i.getAttribute("class").indexOf("__caption") > 0 || /(SMALL|STRONG|EM)/i.test(i.tagName)) && (n.prevent = !1)
					}), d("bindEvents", function() {
						t.bind(i, "pswpTap click", I), t.bind(e.scrollWrap, "pswpTap", E.onGlobalTap), e.likelyTouchDevice || t.bind(e.scrollWrap, "mouseover", E.onMouseOver)
					}), d("unbindEvents", function() {
						S || N(), y && clearInterval(y), t.unbind(document, "mouseout", U), t.unbind(document, "mousemove", k), t.unbind(i, "pswpTap click", I), t.unbind(e.scrollWrap, "pswpTap", E.onGlobalTap), t.unbind(e.scrollWrap, "mouseover", E.onMouseOver), n && (t.unbind(document, n.eventK, E.updateFullscreen), n.isFullscreen() && (g.hideAnimationDuration = 0, n.exit()), n = null)
					}), d("destroy", function() {
						g.captionEl && (r && i.removeChild(r), t.removeClass(o, "pswp__caption--empty")), l && (l.children[0].onclick = null), t.removeClass(i, "pswp__ui--over-close"), t.addClass(i, "pswp__ui--hidden"), E.setIdle(!1)
					}), g.showAnimationDuration || t.removeClass(i, "pswp__ui--hidden"), d("initialZoomIn", function() {
						g.showAnimationDuration && t.removeClass(i, "pswp__ui--hidden")
					}), d("initialZoomOut", function() {
						t.addClass(i, "pswp__ui--hidden")
					}), d("parseVerticalMargin", F),
					function() {
						var e, n, o, r = function(i) {
							if (i)
								for (var r = i.length, a = 0; a < r; a++) {
									e = i[a], n = e.className;
									for (var s = 0; s < H.length; s++) o = H[s], n.indexOf("pswp__" + o.name) > -1 && (g[o.option] ? (t.removeClass(e, "pswp__element--disabled"), o.onInit && o.onInit(e)) : t.addClass(e, "pswp__element--disabled"))
								}
						};
						r(i.children);
						var a = t.getChildByClass(i, "pswp__top-bar");
						a && r(a.children)
					}(), g.shareEl && s && l && (S = !0), D(), g.timeToIdle && d("mouseUsed", function() {
						t.bind(document, "mousemove", k), t.bind(document, "mouseout", U), y = setInterval(function() {
							2 == ++R && E.setIdle(!0)
						}, g.timeToIdle / 2)
					}), g.fullscreenEl && !t.features.isOldAndroid && (n || (n = E.getFullscreenAPI()), n ? (t.bind(document, n.eventK, E.updateFullscreen), E.updateFullscreen(), t.addClass(e.template, "pswp--supports-fs")) : t.removeClass(e.template, "pswp--supports-fs")), g.preloaderEl && (P(!0), d("beforeChange", function() {
						clearTimeout(h), h = setTimeout(function() {
							e.currItem && e.currItem.loading ? (!e.allowProgressiveImg() || e.currItem.img && !e.currItem.img.naturalWidth) && P(!1) : P(!0)
						}, g.loadingIndicatorDelay)
					}), d("imageLoadComplete", function(t, n) {
						e.currItem === n && P(!0)
					}))
			}, E.setIdle = function(e) {
				u = e, A(i, "ui--idle", e)
			}, E.update = function() {
				w && e.currItem ? (E.updateIndexIndicator(), g.captionEl && (g.addCaptionHTMLFn(e.currItem, o), A(o, "caption--empty", !e.currItem.title)), T = !0) : T = !1, S || N(), D()
			}, E.updateFullscreen = function(i) {
				i && setTimeout(function() {
					e.setScrollOffset(0, t.getScrollY())
				}, 50), t[(n.isFullscreen() ? "add" : "remove") + "Class"](e.template, "pswp--fs")
			}, E.updateIndexIndicator = function() {
				g.counterEl && (a.innerHTML = e.getCurrentIndex() + 1 + g.indexIndicatorSep + g.getNumItemsFn())
			}, E.onGlobalTap = function(n) {
				var i = (n = n || window.event).target || n.srcElement;
				if (!v)
					if (n.detail && "mouse" === n.detail.pointerType) {
						if (_(i)) return void e.close();
						t.hasClass(i, "pswp__img") && (1 === e.getZoomLevel() && e.getZoomLevel() <= e.currItem.fitRatio ? g.clickToCloseNonZoomable && e.close() : e.toggleDesktopZoom(n.detail.releasePoint))
					} else if (g.tapToToggleControls && (w ? E.hideControls() : E.showControls()), g.tapToClose && (t.hasClass(i, "pswp__img") || _(i))) return void e.close()
			}, E.onMouseOver = function(e) {
				var t = (e = e || window.event).target || e.srcElement;
				A(i, "ui--over-close", _(t))
			}, E.hideControls = function() {
				t.addClass(i, "pswp__ui--hidden"), w = !1
			}, E.showControls = function() {
				w = !0, T || E.update(), t.removeClass(i, "pswp__ui--hidden")
			}, E.supportsFullscreen = function() {
				var e = document;
				return !!(e.exitFullscreen || e.mozCancelFullScreen || e.webkitExitFullscreen || e.msExitFullscreen)
			}, E.getFullscreenAPI = function() {
				var t, n = document.documentElement,
					i = "fullscreenchange";
				return n.requestFullscreen ? t = {
					enterK: "requestFullscreen",
					exitK: "exitFullscreen",
					elementK: "fullscreenElement",
					eventK: i
				} : n.mozRequestFullScreen ? t = {
					enterK: "mozRequestFullScreen",
					exitK: "mozCancelFullScreen",
					elementK: "mozFullScreenElement",
					eventK: "moz" + i
				} : n.webkitRequestFullscreen ? t = {
					enterK: "webkitRequestFullscreen",
					exitK: "webkitExitFullscreen",
					elementK: "webkitFullscreenElement",
					eventK: "webkit" + i
				} : n.msRequestFullscreen && (t = {
					enterK: "msRequestFullscreen",
					exitK: "msExitFullscreen",
					elementK: "msFullscreenElement",
					eventK: "MSFullscreenChange"
				}), t && (t.enter = function() {
					return c = g.closeOnScroll, g.closeOnScroll = !1, "webkitRequestFullscreen" !== this.enterK ? e.template[this.enterK]() : void e.template[this.enterK](Element.ALLOW_KEYBOARD_INPUT)
				}, t.exit = function() {
					return g.closeOnScroll = c, document[this.exitK]()
				}, t.isFullscreen = function() {
					return document[this.elementK]
				}), t
			}
		}
	}), function(e, t) {
		"function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : e.PhotoSwipe = t()
	}(this, function() {
		"use strict";
		return function(e, t, n, i) {
			var o = {
				features: null,
				bind: function(e, t, n, i) {
					var o = (i ? "remove" : "add") + "EventListener";
					t = t.split(" ");
					for (var r = 0; r < t.length; r++) t[r] && e[o](t[r], n, !1)
				},
				isArray: function(e) {
					return e instanceof Array
				},
				createEl: function(e, t) {
					var n = document.createElement(t || "div");
					return e && (n.className = e), n
				},
				getScrollY: function() {
					var e = window.pageYOffset;
					return void 0 !== e ? e : document.documentElement.scrollTop
				},
				unbind: function(e, t, n) {
					o.bind(e, t, n, !0)
				},
				removeClass: function(e, t) {
					var n = new RegExp("(\\s|^)" + t + "(\\s|$)");
					e.className = e.className.replace(n, " ").replace(/^\s\s*/, "").replace(/\s\s*$/, "")
				},
				addClass: function(e, t) {
					o.hasClass(e, t) || (e.className += (e.className ? " " : "") + t)
				},
				hasClass: function(e, t) {
					return e.className && new RegExp("(^|\\s)" + t + "(\\s|$)").test(e.className)
				},
				getChildByClass: function(e, t) {
					for (var n = e.firstChild; n;) {
						if (o.hasClass(n, t)) return n;
						n = n.nextSibling
					}
				},
				arraySearch: function(e, t, n) {
					for (var i = e.length; i--;)
						if (e[i][n] === t) return i;
					return -1
				},
				extend: function(e, t, n) {
					for (var i in t)
						if (t.hasOwnProperty(i)) {
							if (n && e.hasOwnProperty(i)) continue;
							e[i] = t[i]
						}
				},
				easing: {
					sine: {
						out: function(e) {
							return Math.sin(e * (Math.PI / 2))
						},
						inOut: function(e) {
							return -(Math.cos(Math.PI * e) - 1) / 2
						}
					},
					cubic: {
						out: function(e) {
							return --e * e * e + 1
						}
					}
				},
				detectFeatures: function() {
					if (o.features) return o.features;
					var e = o.createEl().style,
						t = "",
						n = {};
					if (n.oldIE = document.all && !document.addEventListener, n.touch = "ontouchstart" in window, window.requestAnimationFrame && (n.raf = window.requestAnimationFrame, n.caf = window.cancelAnimationFrame), n.pointerEvent = !!window.PointerEvent || navigator.msPointerEnabled, !n.pointerEvent) {
						var i = navigator.userAgent;
						if (/iP(hone|od)/.test(navigator.platform)) {
							var r = navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
							r && r.length > 0 && (r = parseInt(r[1], 10)) >= 1 && r < 8 && (n.isOldIOSPhone = !0)
						}
						var a = i.match(/Android\s([0-9\.]*)/),
							s = a ? a[1] : 0;
						(s = parseFloat(s)) >= 1 && (s < 4.4 && (n.isOldAndroid = !0), n.androidVersion = s), n.isMobileOpera = /opera mini|opera mobi/i.test(i)
					}
					for (var l, c, u = ["transform", "perspective", "animationName"], d = ["", "webkit", "Moz", "ms", "O"], f = 0; f < 4; f++) {
						t = d[f];
						for (var p = 0; p < 3; p++) l = u[p], c = t + (t ? l.charAt(0).toUpperCase() + l.slice(1) : l), !n[l] && c in e && (n[l] = c);
						t && !n.raf && (t = t.toLowerCase(), n.raf = window[t + "RequestAnimationFrame"], n.raf && (n.caf = window[t + "CancelAnimationFrame"] || window[t + "CancelRequestAnimationFrame"]))
					}
					if (!n.raf) {
						var h = 0;
						n.raf = function(e) {
							var t = (new Date).getTime(),
								n = Math.max(0, 16 - (t - h)),
								i = window.setTimeout(function() {
									e(t + n)
								}, n);
							return h = t + n, i
						}, n.caf = function(e) {
							clearTimeout(e)
						}
					}
					return n.svg = !!document.createElementNS && !!document.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect, o.features = n, n
				}
			};
			o.detectFeatures(), o.features.oldIE && (o.bind = function(e, t, n, i) {
				t = t.split(" ");
				for (var o, r = (i ? "detach" : "attach") + "Event", a = function() {
						n.handleEvent.call(n)
					}, s = 0; s < t.length; s++)
					if (o = t[s])
						if ("object" == typeof n && n.handleEvent) {
							if (i) {
								if (!n["oldIE" + o]) return !1
							} else n["oldIE" + o] = a;
							e[r]("on" + o, n["oldIE" + o])
						} else e[r]("on" + o, n)
			});
			var r = this,
				a = {
					allowPanToNext: !0,
					spacing: .12,
					bgOpacity: 1,
					mouseUsed: !1,
					loop: !0,
					pinchToClose: !0,
					closeOnScroll: !0,
					closeOnVerticalDrag: !0,
					verticalDragRange: .75,
					hideAnimationDuration: 333,
					showAnimationDuration: 333,
					showHideOpacity: !1,
					focus: !0,
					escKey: !0,
					arrowKeys: !0,
					mainScrollEndFriction: .35,
					panEndFriction: .35,
					isClickableElement: function(e) {
						return "A" === e.tagName
					},
					getDoubleTapZoom: function(e, t) {
						return e ? 1 : t.initialZoomLevel < .7 ? 1 : 1.33
					},
					maxSpreadZoom: 1.33,
					modal: !0,
					scaleMode: "fit"
				};
			o.extend(a, i);
			var s, l, c, u, d, f, p, h, m, g, v, y, b, E, T, w, S, C, I, x, A, D, L, N, O, M, _, R, k, U, P, F, H, q, $, G, B, z, Y, j, K, W, V, X, Z, Q, J, ee, te, ne, ie, oe, re, ae, se, le, ce = {
					x: 0,
					y: 0
				},
				ue = {
					x: 0,
					y: 0
				},
				de = {
					x: 0,
					y: 0
				},
				fe = {},
				pe = 0,
				he = {},
				me = {
					x: 0,
					y: 0
				},
				ge = 0,
				ve = !0,
				ye = [],
				be = {},
				Ee = !1,
				Te = function(e, t) {
					o.extend(r, t.publicMethods), ye.push(e)
				},
				we = function(e) {
					var t = $t();
					return e > t - 1 ? e - t : e < 0 ? t + e : e
				},
				Se = {},
				Ce = function(e, t) {
					return Se[e] || (Se[e] = []), Se[e].push(t)
				},
				Ie = function(e) {
					var t = Se[e];
					if (t) {
						var n = Array.prototype.slice.call(arguments);
						n.shift();
						for (var i = 0; i < t.length; i++) t[i].apply(r, n)
					}
				},
				xe = function() {
					return (new Date).getTime()
				},
				Ae = function(e) {
					ae = e, r.bg.style.opacity = e * a.bgOpacity
				},
				De = function(e, t, n, i, o) {
					(!Ee || o && o !== r.currItem) && (i /= o ? o.fitRatio : r.currItem.fitRatio), e[D] = y + t + "px, " + n + "px" + b + " scale(" + i + ")"
				},
				Le = function(e) {
					te && (e && (g > r.currItem.fitRatio ? Ee || (Xt(r.currItem, !1, !0), Ee = !0) : Ee && (Xt(r.currItem), Ee = !1)), De(te, de.x, de.y, g))
				},
				Ne = function(e) {
					e.container && De(e.container.style, e.initialPosition.x, e.initialPosition.y, e.initialZoomLevel, e)
				},
				Oe = function(e, t) {
					t[D] = y + e + "px, 0px" + b
				},
				Me = function(e, t) {
					if (!a.loop && t) {
						var n = u + (me.x * pe - e) / me.x,
							i = Math.round(e - ut.x);
						(n < 0 && i > 0 || n >= $t() - 1 && i < 0) && (e = ut.x + i * a.mainScrollEndFriction)
					}
					ut.x = e, Oe(e, d)
				},
				_e = function(e, t) {
					var n = dt[e] - he[e];
					return ue[e] + ce[e] + n - n * (t / v)
				},
				Re = function(e, t) {
					e.x = t.x, e.y = t.y, t.id && (e.id = t.id)
				},
				ke = function(e) {
					e.x = Math.round(e.x), e.y = Math.round(e.y)
				},
				Ue = null,
				Pe = function() {
					Ue && (o.unbind(document, "mousemove", Pe), o.addClass(e, "pswp--has_mouse"), a.mouseUsed = !0, Ie("mouseUsed")), Ue = setTimeout(function() {
						Ue = null
					}, 100)
				},
				Fe = function(e, t) {
					var n = jt(r.currItem, fe, e);
					return t && (ee = n), n
				},
				He = function(e) {
					return e || (e = r.currItem), e.initialZoomLevel
				},
				qe = function(e) {
					return e || (e = r.currItem), e.w > 0 ? a.maxSpreadZoom : 1
				},
				$e = function(e, t, n, i) {
					return i === r.currItem.initialZoomLevel ? (n[e] = r.currItem.initialPosition[e], !0) : (n[e] = _e(e, i), n[e] > t.min[e] ? (n[e] = t.min[e], !0) : n[e] < t.max[e] && (n[e] = t.max[e], !0))
				},
				Ge = function(e) {
					var t = "";
					a.escKey && 27 === e.keyCode ? t = "close" : a.arrowKeys && (37 === e.keyCode ? t = "prev" : 39 === e.keyCode && (t = "next")), t && (e.ctrlKey || e.altKey || e.shiftKey || e.metaKey || (e.preventDefault ? e.preventDefault() : e.returnValue = !1, r[t]()))
				},
				Be = function(e) {
					e && (W || K || ne || B) && (e.preventDefault(), e.stopPropagation())
				},
				ze = function() {
					r.setScrollOffset(0, o.getScrollY())
				},
				Ye = {},
				je = 0,
				Ke = function(e) {
					Ye[e] && (Ye[e].raf && M(Ye[e].raf), je--, delete Ye[e])
				},
				We = function(e) {
					Ye[e] && Ke(e), Ye[e] || (je++, Ye[e] = {})
				},
				Ve = function() {
					for (var e in Ye) Ye.hasOwnProperty(e) && Ke(e)
				},
				Xe = function(e, t, n, i, o, r, a) {
					var s, l = xe();
					We(e);
					var c = function() {
						if (Ye[e]) {
							if ((s = xe() - l) >= i) return Ke(e), r(n), void(a && a());
							r((n - t) * o(s / i) + t), Ye[e].raf = O(c)
						}
					};
					c()
				},
				Ze = {
					shout: Ie,
					listen: Ce,
					viewportSize: fe,
					options: a,
					isMainScrollAnimating: function() {
						return ne
					},
					getZoomLevel: function() {
						return g
					},
					getCurrentIndex: function() {
						return u
					},
					isDragging: function() {
						return Y
					},
					isZooming: function() {
						return Q
					},
					setScrollOffset: function(e, t) {
						he.x = e, U = he.y = t, Ie("updateScrollOffset", he)
					},
					applyZoomPan: function(e, t, n, i) {
						de.x = t, de.y = n, g = e, Le(i)
					},
					init: function() {
						if (!s && !l) {
							var n;
							r.framework = o, r.template = e, r.bg = o.getChildByClass(e, "pswp__bg"), _ = e.className, s = !0, P = o.detectFeatures(), O = P.raf, M = P.caf, D = P.transform, k = P.oldIE, r.scrollWrap = o.getChildByClass(e, "pswp__scroll-wrap"), r.container = o.getChildByClass(r.scrollWrap, "pswp__container"), d = r.container.style, r.itemHolders = w = [{
									el: r.container.children[0],
									wrap: 0,
									index: -1
								}, {
									el: r.container.children[1],
									wrap: 0,
									index: -1
								}, {
									el: r.container.children[2],
									wrap: 0,
									index: -1
								}], w[0].el.style.display = w[2].el.style.display = "none",
								function() {
									if (D) {
										var t = P.perspective && !N;
										return y = "translate" + (t ? "3d(" : "("), void(b = P.perspective ? ", 0px)" : ")")
									}
									D = "left", o.addClass(e, "pswp--ie"), Oe = function(e, t) {
										t.left = e + "px"
									}, Ne = function(e) {
										var t = e.fitRatio > 1 ? 1 : e.fitRatio,
											n = e.container.style,
											i = t * e.w,
											o = t * e.h;
										n.width = i + "px", n.height = o + "px", n.left = e.initialPosition.x + "px", n.top = e.initialPosition.y + "px"
									}, Le = function() {
										if (te) {
											var e = te,
												t = r.currItem,
												n = t.fitRatio > 1 ? 1 : t.fitRatio,
												i = n * t.w,
												o = n * t.h;
											e.width = i + "px", e.height = o + "px", e.left = de.x + "px", e.top = de.y + "px"
										}
									}
								}(), m = {
									resize: r.updateSize,
									orientationchange: function() {
										clearTimeout(F), F = setTimeout(function() {
											fe.x !== r.scrollWrap.clientWidth && r.updateSize()
										}, 500)
									},
									scroll: ze,
									keydown: Ge,
									click: Be
								};
							var i = P.isOldIOSPhone || P.isOldAndroid || P.isMobileOpera;
							for (P.animationName && P.transform && !i || (a.showAnimationDuration = a.hideAnimationDuration = 0), n = 0; n < ye.length; n++) r["init" + ye[n]]();
							t && (r.ui = new t(r, o)).init(), Ie("firstUpdate"), u = u || a.index || 0, (isNaN(u) || u < 0 || u >= $t()) && (u = 0), r.currItem = qt(u), (P.isOldIOSPhone || P.isOldAndroid) && (ve = !1), e.setAttribute("aria-hidden", "false"), a.modal && (ve ? e.style.position = "fixed" : (e.style.position = "absolute", e.style.top = o.getScrollY() + "px")), void 0 === U && (Ie("initialLayout"), U = R = o.getScrollY());
							var c = "pswp--open ";
							for (a.mainClass && (c += a.mainClass + " "), a.showHideOpacity && (c += "pswp--animate_opacity "), c += N ? "pswp--touch" : "pswp--notouch", c += P.animationName ? " pswp--css_animation" : "", c += P.svg ? " pswp--svg" : "", o.addClass(e, c), r.updateSize(), f = -1, ge = null, n = 0; n < 3; n++) Oe((n + f) * me.x, w[n].el.style);
							k || o.bind(r.scrollWrap, h, r), Ce("initialZoomInEnd", function() {
								r.setContent(w[0], u - 1), r.setContent(w[2], u + 1), w[0].el.style.display = w[2].el.style.display = "block", a.focus && e.focus(), o.bind(document, "keydown", r), P.transform && o.bind(r.scrollWrap, "click", r), a.mouseUsed || o.bind(document, "mousemove", Pe), o.bind(window, "resize scroll orientationchange", r), Ie("bindEvents")
							}), r.setContent(w[1], u), r.updateCurrItem(), Ie("afterInit"), ve || (E = setInterval(function() {
								je || Y || Q || g !== r.currItem.initialZoomLevel || r.updateSize()
							}, 1e3)), o.addClass(e, "pswp--visible")
						}
					},
					close: function() {
						s && (s = !1, l = !0, Ie("close"), o.unbind(window, "resize scroll orientationchange", r), o.unbind(window, "scroll", m.scroll), o.unbind(document, "keydown", r), o.unbind(document, "mousemove", Pe), P.transform && o.unbind(r.scrollWrap, "click", r), Y && o.unbind(window, p, r), clearTimeout(F), Ie("unbindEvents"), Gt(r.currItem, null, !0, r.destroy))
					},
					destroy: function() {
						Ie("destroy"), Ut && clearTimeout(Ut), e.setAttribute("aria-hidden", "true"), e.className = _, E && clearInterval(E), o.unbind(r.scrollWrap, h, r), o.unbind(window, "scroll", r), ht(), Ve(), Se = null
					},
					panTo: function(e, t, n) {
						n || (e > ee.min.x ? e = ee.min.x : e < ee.max.x && (e = ee.max.x), t > ee.min.y ? t = ee.min.y : t < ee.max.y && (t = ee.max.y)), de.x = e, de.y = t, Le()
					},
					handleEvent: function(e) {
						e = e || window.event, m[e.type] && m[e.type](e)
					},
					goTo: function(e) {
						var t = (e = we(e)) - u;
						ge = t, u = e, r.currItem = qt(u), pe -= t, Me(me.x * pe), Ve(), ne = !1, r.updateCurrItem()
					},
					next: function() {
						r.goTo(u + 1)
					},
					prev: function() {
						r.goTo(u - 1)
					},
					updateCurrZoomItem: function(e) {
						if (e && Ie("beforeChange", 0), w[1].el.children.length) {
							var t = w[1].el.children[0];
							te = o.hasClass(t, "pswp__zoom-wrap") ? t.style : null
						} else te = null;
						ee = r.currItem.bounds, v = g = r.currItem.initialZoomLevel, de.x = ee.center.x, de.y = ee.center.y, e && Ie("afterChange")
					},
					invalidateCurrItems: function() {
						T = !0;
						for (var e = 0; e < 3; e++) w[e].item && (w[e].item.needsUpdate = !0)
					},
					updateCurrItem: function(e) {
						if (0 !== ge) {
							var t, n = Math.abs(ge);
							if (!(e && n < 2)) {
								r.currItem = qt(u), Ee = !1, Ie("beforeChange", ge), n >= 3 && (f += ge + (ge > 0 ? -3 : 3), n = 3);
								for (var i = 0; i < n; i++) ge > 0 ? (t = w.shift(), w[2] = t, Oe((++f + 2) * me.x, t.el.style), r.setContent(t, u - n + i + 1 + 1)) : (t = w.pop(), w.unshift(t), Oe(--f * me.x, t.el.style), r.setContent(t, u + n - i - 1 - 1));
								if (te && 1 === Math.abs(ge)) {
									var o = qt(S);
									o.initialZoomLevel !== g && (jt(o, fe), Xt(o), Ne(o))
								}
								ge = 0, r.updateCurrZoomItem(), S = u, Ie("afterChange")
							}
						}
					},
					updateSize: function(t) {
						if (!ve && a.modal) {
							var n = o.getScrollY();
							if (U !== n && (e.style.top = n + "px", U = n), !t && be.x === window.innerWidth && be.y === window.innerHeight) return;
							be.x = window.innerWidth, be.y = window.innerHeight, e.style.height = be.y + "px"
						}
						if (fe.x = r.scrollWrap.clientWidth, fe.y = r.scrollWrap.clientHeight, ze(), me.x = fe.x + Math.round(fe.x * a.spacing), me.y = fe.y, Me(me.x * pe), Ie("beforeResize"), void 0 !== f) {
							for (var i, s, l, c = 0; c < 3; c++) i = w[c], Oe((c + f) * me.x, i.el.style), l = u + c - 1, a.loop && $t() > 2 && (l = we(l)), (s = qt(l)) && (T || s.needsUpdate || !s.bounds) ? (r.cleanSlide(s), r.setContent(i, l), 1 === c && (r.currItem = s, r.updateCurrZoomItem(!0)), s.needsUpdate = !1) : -1 === i.index && l >= 0 && r.setContent(i, l), s && s.container && (jt(s, fe), Xt(s), Ne(s));
							T = !1
						}
						v = g = r.currItem.initialZoomLevel, (ee = r.currItem.bounds) && (de.x = ee.center.x, de.y = ee.center.y, Le(!0)), Ie("resize")
					},
					zoomTo: function(e, t, n, i, r) {
						t && (v = g, dt.x = Math.abs(t.x) - de.x, dt.y = Math.abs(t.y) - de.y, Re(ue, de));
						var a = Fe(e, !1),
							s = {};
						$e("x", a, s, e), $e("y", a, s, e);
						var l = g,
							c = de.x,
							u = de.y;
						ke(s);
						var d = function(t) {
							1 === t ? (g = e, de.x = s.x, de.y = s.y) : (g = (e - l) * t + l, de.x = (s.x - c) * t + c, de.y = (s.y - u) * t + u), r && r(t), Le(1 === t)
						};
						n ? Xe("customZoomTo", 0, 1, n, i || o.easing.sine.inOut, d) : d(1)
					}
				},
				Qe = {},
				Je = {},
				et = {},
				tt = {},
				nt = {},
				it = [],
				ot = {},
				rt = [],
				at = {},
				st = 0,
				lt = {
					x: 0,
					y: 0
				},
				ct = 0,
				ut = {
					x: 0,
					y: 0
				},
				dt = {
					x: 0,
					y: 0
				},
				ft = {
					x: 0,
					y: 0
				},
				pt = function(e, t) {
					return at.x = Math.abs(e.x - t.x), at.y = Math.abs(e.y - t.y), Math.sqrt(at.x * at.x + at.y * at.y)
				},
				ht = function() {
					V && (M(V), V = null)
				},
				mt = function() {
					Y && (V = O(mt), Lt())
				},
				gt = function(e, t) {
					return !(!e || e === document) && !(e.getAttribute("class") && e.getAttribute("class").indexOf("pswp__scroll-wrap") > -1) && (t(e) ? e : gt(e.parentNode, t))
				},
				vt = {},
				yt = function(e, t) {
					return vt.prevent = !gt(e.target, a.isClickableElement), Ie("preventDragEvent", e, t, vt), vt.prevent
				},
				bt = function(e, t) {
					return t.x = e.pageX, t.y = e.pageY, t.id = e.identifier, t
				},
				Et = function(e, t, n) {
					n.x = .5 * (e.x + t.x), n.y = .5 * (e.y + t.y)
				},
				Tt = function() {
					var e = de.y - r.currItem.initialPosition.y;
					return 1 - Math.abs(e / (fe.y / 2))
				},
				wt = {},
				St = {},
				Ct = [],
				It = function(e) {
					for (; Ct.length > 0;) Ct.pop();
					return L ? (le = 0, it.forEach(function(e) {
						0 === le ? Ct[0] = e : 1 === le && (Ct[1] = e), le++
					})) : e.type.indexOf("touch") > -1 ? e.touches && e.touches.length > 0 && (Ct[0] = bt(e.touches[0], wt), e.touches.length > 1 && (Ct[1] = bt(e.touches[1], St))) : (wt.x = e.pageX, wt.y = e.pageY, wt.id = "", Ct[0] = wt), Ct
				},
				xt = function(e, t) {
					var n, i, o, s, l = de[e] + t[e],
						c = t[e] > 0,
						u = ut.x + t.x,
						d = ut.x - ot.x;
					return n = l > ee.min[e] || l < ee.max[e] ? a.panEndFriction : 1, l = de[e] + t[e] * n, !a.allowPanToNext && g !== r.currItem.initialZoomLevel || (te ? "h" !== ie || "x" !== e || K || (c ? (l > ee.min[e] && (n = a.panEndFriction, ee.min[e], i = ee.min[e] - ue[e]), (i <= 0 || d < 0) && $t() > 1 ? (s = u, d < 0 && u > ot.x && (s = ot.x)) : ee.min.x !== ee.max.x && (o = l)) : (l < ee.max[e] && (n = a.panEndFriction, ee.max[e], i = ue[e] - ee.max[e]), (i <= 0 || d > 0) && $t() > 1 ? (s = u, d > 0 && u < ot.x && (s = ot.x)) : ee.min.x !== ee.max.x && (o = l))) : s = u, "x" !== e) ? void(ne || X || g > r.currItem.fitRatio && (de[e] += t[e] * n)) : (void 0 !== s && (Me(s, !0), X = s !== ot.x), ee.min.x !== ee.max.x && (void 0 !== o ? de.x = o : X || (de.x += t.x * n)), void 0 !== s)
				},
				At = function(e) {
					if (!("mousedown" === e.type && e.button > 0)) {
						if (Ht) return void e.preventDefault();
						if (!z || "mousedown" !== e.type) {
							if (yt(e, !0) && e.preventDefault(), Ie("pointerDown"), L) {
								var t = o.arraySearch(it, e.pointerId, "id");
								t < 0 && (t = it.length), it[t] = {
									x: e.pageX,
									y: e.pageY,
									id: e.pointerId
								}
							}
							var n = It(e),
								i = n.length;
							Z = null, Ve(), Y && 1 !== i || (Y = oe = !0, o.bind(window, p, r), G = se = re = B = X = W = j = K = !1, ie = null, Ie("firstTouchStart", n), Re(ue, de), ce.x = ce.y = 0, Re(tt, n[0]), Re(nt, tt), ot.x = me.x * pe, rt = [{
								x: tt.x,
								y: tt.y
							}], q = H = xe(), Fe(g, !0), ht(), mt()), !Q && i > 1 && !ne && !X && (v = g, K = !1, Q = j = !0, ce.y = ce.x = 0, Re(ue, de), Re(Qe, n[0]), Re(Je, n[1]), Et(Qe, Je, ft), dt.x = Math.abs(ft.x) - de.x, dt.y = Math.abs(ft.y) - de.y, J = pt(Qe, Je))
						}
					}
				},
				Dt = function(e) {
					if (e.preventDefault(), L) {
						var t = o.arraySearch(it, e.pointerId, "id");
						if (t > -1) {
							var n = it[t];
							n.x = e.pageX, n.y = e.pageY
						}
					}
					if (Y) {
						var i = It(e);
						if (ie || W || Q) Z = i;
						else if (ut.x !== me.x * pe) ie = "h";
						else {
							var r = Math.abs(i[0].x - tt.x) - Math.abs(i[0].y - tt.y);
							Math.abs(r) >= 10 && (ie = r > 0 ? "h" : "v", Z = i)
						}
					}
				},
				Lt = function() {
					if (Z) {
						var e = Z.length;
						if (0 !== e)
							if (Re(Qe, Z[0]), et.x = Qe.x - tt.x, et.y = Qe.y - tt.y, Q && e > 1) {
								if (tt.x = Qe.x, tt.y = Qe.y, !et.x && !et.y && function(e, t) {
										return e.x === t.x && e.y === t.y
									}(Z[1], Je)) return;
								Re(Je, Z[1]), K || (K = !0, Ie("zoomGestureStarted"));
								var t = pt(Qe, Je),
									n = Rt(t);
								n > r.currItem.initialZoomLevel + r.currItem.initialZoomLevel / 15 && (se = !0);
								var i = 1,
									o = He(),
									s = qe();
								if (n < o)
									if (a.pinchToClose && !se && v <= r.currItem.initialZoomLevel) {
										var l = 1 - (o - n) / (o / 1.2);
										Ae(l), Ie("onPinchClose", l), re = !0
									} else(i = (o - n) / o) > 1 && (i = 1), n = o - i * (o / 3);
								else n > s && ((i = (n - s) / (6 * o)) > 1 && (i = 1), n = s + i * o);
								i < 0 && (i = 0), Et(Qe, Je, lt), ce.x += lt.x - ft.x, ce.y += lt.y - ft.y, Re(ft, lt), de.x = _e("x", n), de.y = _e("y", n), G = n > g, g = n, Le()
							} else {
								if (!ie) return;
								if (oe && (oe = !1, Math.abs(et.x) >= 10 && (et.x -= Z[0].x - nt.x), Math.abs(et.y) >= 10 && (et.y -= Z[0].y - nt.y)), tt.x = Qe.x, tt.y = Qe.y, 0 === et.x && 0 === et.y) return;
								if ("v" === ie && a.closeOnVerticalDrag && "fit" === a.scaleMode && g === r.currItem.initialZoomLevel) {
									ce.y += et.y, de.y += et.y;
									var c = Tt();
									return B = !0, Ie("onVerticalDrag", c), Ae(c), void Le()
								}(function(e, t, n) {
									if (e - q > 50) {
										var i = rt.length > 2 ? rt.shift() : {};
										i.x = t, i.y = n, rt.push(i), q = e
									}
								})(xe(), Qe.x, Qe.y), W = !0, ee = r.currItem.bounds, xt("x", et) || (xt("y", et), ke(de), Le())
							}
					}
				},
				Nt = function(e) {
					if (P.isOldAndroid) {
						if (z && "mouseup" === e.type) return;
						e.type.indexOf("touch") > -1 && (clearTimeout(z), z = setTimeout(function() {
							z = 0
						}, 600))
					}
					var t;
					if (Ie("pointerUp"), yt(e, !1) && e.preventDefault(), L) {
						var n = o.arraySearch(it, e.pointerId, "id");
						n > -1 && (t = it.splice(n, 1)[0], navigator.msPointerEnabled ? (t.type = {
							4: "mouse",
							2: "touch",
							3: "pen"
						} [e.pointerType], t.type || (t.type = e.pointerType || "mouse")) : t.type = e.pointerType || "mouse")
					}
					var i, s = It(e),
						l = s.length;
					if ("mouseup" === e.type && (l = 0), 2 === l) return Z = null, !0;
					1 === l && Re(nt, s[0]), 0 !== l || ie || ne || (t || ("mouseup" === e.type ? t = {
						x: e.pageX,
						y: e.pageY,
						type: "mouse"
					} : e.changedTouches && e.changedTouches[0] && (t = {
						x: e.changedTouches[0].pageX,
						y: e.changedTouches[0].pageY,
						type: "touch"
					})), Ie("touchRelease", e, t));
					var c = -1;
					if (0 === l && (Y = !1, o.unbind(window, p, r), ht(), Q ? c = 0 : -1 !== ct && (c = xe() - ct)), ct = 1 === l ? xe() : -1, i = -1 !== c && c < 150 ? "zoom" : "swipe", Q && l < 2 && (Q = !1, 1 === l && (i = "zoomPointerUp"), Ie("zoomGestureEnded")), Z = null, W || K || ne || B)
						if (Ve(), $ || ($ = Ot()), $.calculateSwipeSpeed("x"), B)
							if (Tt() < a.verticalDragRange) r.close();
							else {
								var u = de.y,
									d = ae;
								Xe("verticalDrag", 0, 1, 300, o.easing.cubic.out, function(e) {
									de.y = (r.currItem.initialPosition.y - u) * e + u, Ae((1 - d) * e + d), Le()
								}), Ie("onVerticalDrag", 1)
							}
					else {
						if ((X || ne) && 0 === l) {
							if (_t(i, $)) return;
							i = "zoomPointerUp"
						}
						if (!ne) return "swipe" !== i ? void kt() : void(!X && g > r.currItem.fitRatio && Mt($))
					}
				},
				Ot = function() {
					var e, t, n = {
						lastFlickOffset: {},
						lastFlickDist: {},
						lastFlickSpeed: {},
						slowDownRatio: {},
						slowDownRatioReverse: {},
						speedDecelerationRatio: {},
						speedDecelerationRatioAbs: {},
						distanceOffset: {},
						backAnimDestination: {},
						backAnimStarted: {},
						calculateSwipeSpeed: function(i) {
							rt.length > 1 ? (e = xe() - q + 50, t = rt[rt.length - 2][i]) : (e = xe() - H, t = nt[i]), n.lastFlickOffset[i] = tt[i] - t, n.lastFlickDist[i] = Math.abs(n.lastFlickOffset[i]), n.lastFlickDist[i] > 20 ? n.lastFlickSpeed[i] = n.lastFlickOffset[i] / e : n.lastFlickSpeed[i] = 0, Math.abs(n.lastFlickSpeed[i]) < .1 && (n.lastFlickSpeed[i] = 0), n.slowDownRatio[i] = .95, n.slowDownRatioReverse[i] = 1 - n.slowDownRatio[i], n.speedDecelerationRatio[i] = 1
						},
						calculateOverBoundsAnimOffset: function(e, t) {
							n.backAnimStarted[e] || (de[e] > ee.min[e] ? n.backAnimDestination[e] = ee.min[e] : de[e] < ee.max[e] && (n.backAnimDestination[e] = ee.max[e]), void 0 !== n.backAnimDestination[e] && (n.slowDownRatio[e] = .7, n.slowDownRatioReverse[e] = 1 - n.slowDownRatio[e], n.speedDecelerationRatioAbs[e] < .05 && (n.lastFlickSpeed[e] = 0, n.backAnimStarted[e] = !0, Xe("bounceZoomPan" + e, de[e], n.backAnimDestination[e], t || 300, o.easing.sine.out, function(t) {
								de[e] = t, Le()
							}))))
						},
						calculateAnimOffset: function(e) {
							n.backAnimStarted[e] || (n.speedDecelerationRatio[e] = n.speedDecelerationRatio[e] * (n.slowDownRatio[e] + n.slowDownRatioReverse[e] - n.slowDownRatioReverse[e] * n.timeDiff / 10), n.speedDecelerationRatioAbs[e] = Math.abs(n.lastFlickSpeed[e] * n.speedDecelerationRatio[e]), n.distanceOffset[e] = n.lastFlickSpeed[e] * n.speedDecelerationRatio[e] * n.timeDiff, de[e] += n.distanceOffset[e])
						},
						panAnimLoop: function() {
							if (Ye.zoomPan && (Ye.zoomPan.raf = O(n.panAnimLoop), n.now = xe(), n.timeDiff = n.now - n.lastNow, n.lastNow = n.now, n.calculateAnimOffset("x"), n.calculateAnimOffset("y"), Le(), n.calculateOverBoundsAnimOffset("x"), n.calculateOverBoundsAnimOffset("y"), n.speedDecelerationRatioAbs.x < .05 && n.speedDecelerationRatioAbs.y < .05)) return de.x = Math.round(de.x), de.y = Math.round(de.y), Le(), void Ke("zoomPan")
						}
					};
					return n
				},
				Mt = function(e) {
					return e.calculateSwipeSpeed("y"), ee = r.currItem.bounds, e.backAnimDestination = {}, e.backAnimStarted = {}, Math.abs(e.lastFlickSpeed.x) <= .05 && Math.abs(e.lastFlickSpeed.y) <= .05 ? (e.speedDecelerationRatioAbs.x = e.speedDecelerationRatioAbs.y = 0, e.calculateOverBoundsAnimOffset("x"), e.calculateOverBoundsAnimOffset("y"), !0) : (We("zoomPan"), e.lastNow = xe(), void e.panAnimLoop())
				},
				_t = function(e, t) {
					var n, i, s;
					if (ne || (st = u), "swipe" === e) {
						var l = tt.x - nt.x,
							c = t.lastFlickDist.x < 10;
						l > 30 && (c || t.lastFlickOffset.x > 20) ? i = -1 : l < -30 && (c || t.lastFlickOffset.x < -20) && (i = 1)
					}
					i && ((u += i) < 0 ? (u = a.loop ? $t() - 1 : 0, s = !0) : u >= $t() && (u = a.loop ? 0 : $t() - 1, s = !0), s && !a.loop || (ge += i, pe -= i, n = !0));
					var d, f = me.x * pe,
						p = Math.abs(f - ut.x);
					return n || f > ut.x == t.lastFlickSpeed.x > 0 ? (d = Math.abs(t.lastFlickSpeed.x) > 0 ? p / Math.abs(t.lastFlickSpeed.x) : 333, d = Math.min(d, 400), d = Math.max(d, 250)) : d = 333, st === u && (n = !1), ne = !0, Ie("mainScrollAnimStart"), Xe("mainScroll", ut.x, f, d, o.easing.cubic.out, Me, function() {
						Ve(), ne = !1, st = -1, (n || st !== u) && r.updateCurrItem(), Ie("mainScrollAnimComplete")
					}), n && r.updateCurrItem(!0), n
				},
				Rt = function(e) {
					return 1 / J * e * v
				},
				kt = function() {
					var e = g,
						t = He(),
						n = qe();
					g < t ? e = t : g > n && (e = n);
					var i, a = ae;
					return re && !G && !se && g < t ? (r.close(), !0) : (re && (i = function(e) {
						Ae((1 - a) * e + a)
					}), r.zoomTo(e, 0, 200, o.easing.cubic.out, i), !0)
				};
			Te("Gestures", {
				publicMethods: {
					initGestures: function() {
						var e = function(e, t, n, i, o) {
							C = e + t, I = e + n, x = e + i, A = o ? e + o : ""
						};
						(L = P.pointerEvent) && P.touch && (P.touch = !1), L ? navigator.msPointerEnabled ? e("MSPointer", "Down", "Move", "Up", "Cancel") : e("pointer", "down", "move", "up", "cancel") : P.touch ? (e("touch", "start", "move", "end", "cancel"), N = !0) : e("mouse", "down", "move", "up"), p = I + " " + x + " " + A, h = C, L && !N && (N = navigator.maxTouchPoints > 1 || navigator.msMaxTouchPoints > 1), r.likelyTouchDevice = N, m[C] = At, m[I] = Dt, m[x] = Nt, A && (m[A] = m[x]), P.touch && (h += " mousedown", p += " mousemove mouseup", m.mousedown = m[C], m.mousemove = m[I], m.mouseup = m[x]), N || (a.allowPanToNext = !1)
					}
				}
			});
			var Ut, Pt, Ft, Ht, qt, $t, Gt = function(t, n, i, s) {
					var l;
					Ut && clearTimeout(Ut), Ht = !0, Ft = !0, t.initialLayout ? (l = t.initialLayout, t.initialLayout = null) : l = a.getThumbBoundsFn && a.getThumbBoundsFn(u);
					var d = i ? a.hideAnimationDuration : a.showAnimationDuration,
						f = function() {
							Ke("initialZoom"), i ? (r.template.removeAttribute("style"), r.bg.removeAttribute("style")) : (Ae(1), n && (n.style.display = "block"), o.addClass(e, "pswp--animated-in"), Ie("initialZoom" + (i ? "OutEnd" : "InEnd"))), s && s(), Ht = !1
						};
					if (!d || !l || void 0 === l.x) return Ie("initialZoom" + (i ? "Out" : "In")), g = t.initialZoomLevel, Re(de, t.initialPosition), Le(), e.style.opacity = i ? 0 : 1, Ae(1), void(d ? setTimeout(function() {
						f()
					}, d) : f());
					! function() {
						var n = c,
							s = !r.currItem.src || r.currItem.loadError || a.showHideOpacity;
						t.miniImg && (t.miniImg.style.webkitBackfaceVisibility = "hidden"), i || (g = l.w / t.w, de.x = l.x, de.y = l.y - R, r[s ? "template" : "bg"].style.opacity = .001, Le()), We("initialZoom"), i && !n && o.removeClass(e, "pswp--animated-in"), s && (i ? o[(n ? "remove" : "add") + "Class"](e, "pswp--animate_opacity") : setTimeout(function() {
							o.addClass(e, "pswp--animate_opacity")
						}, 30)), Ut = setTimeout(function() {
							if (Ie("initialZoom" + (i ? "Out" : "In")), i) {
								var r = l.w / t.w,
									a = {
										x: de.x,
										y: de.y
									},
									c = g,
									u = ae,
									p = function(t) {
										1 === t ? (g = r, de.x = l.x, de.y = l.y - U) : (g = (r - c) * t + c, de.x = (l.x - a.x) * t + a.x, de.y = (l.y - U - a.y) * t + a.y), Le(), s ? e.style.opacity = 1 - t : Ae(u - t * u)
									};
								n ? Xe("initialZoom", 0, 1, d, o.easing.cubic.out, p, f) : (p(1), Ut = setTimeout(f, d + 20))
							} else g = t.initialZoomLevel, Re(de, t.initialPosition), Le(), Ae(1), s ? e.style.opacity = 1 : Ae(1), Ut = setTimeout(f, d + 20)
						}, i ? 25 : 90)
					}()
				},
				Bt = {},
				zt = [],
				Yt = {
					index: 0,
					errorMsg: '<div class="pswp__error-msg"><a href="%url%" target="_blank">The image</a> could not be loaded.</div>',
					forceProgressiveLoading: !1,
					preload: [1, 1],
					getNumItemsFn: function() {
						return Pt.length
					}
				},
				jt = function(e, t, n) {
					if (e.src && !e.loadError) {
						var i = !n;
						if (i && (e.vGap || (e.vGap = {
								top: 0,
								bottom: 0
							}), Ie("parseVerticalMargin", e)), Bt.x = t.x, Bt.y = t.y - e.vGap.top - e.vGap.bottom, i) {
							var o = Bt.x / e.w,
								r = Bt.y / e.h;
							e.fitRatio = o < r ? o : r;
							var s = a.scaleMode;
							"orig" === s ? n = 1 : "fit" === s && (n = e.fitRatio), n > 1 && (n = 1), e.initialZoomLevel = n, e.bounds || (e.bounds = {
								center: {
									x: 0,
									y: 0
								},
								max: {
									x: 0,
									y: 0
								},
								min: {
									x: 0,
									y: 0
								}
							})
						}
						if (!n) return;
						return function(e, t, n) {
							var i = e.bounds;
							i.center.x = Math.round((Bt.x - t) / 2), i.center.y = Math.round((Bt.y - n) / 2) + e.vGap.top, i.max.x = t > Bt.x ? Math.round(Bt.x - t) : i.center.x, i.max.y = n > Bt.y ? Math.round(Bt.y - n) + e.vGap.top : i.center.y, i.min.x = t > Bt.x ? 0 : i.center.x, i.min.y = n > Bt.y ? e.vGap.top : i.center.y
						}(e, e.w * n, e.h * n), i && n === e.initialZoomLevel && (e.initialPosition = e.bounds.center), e.bounds
					}
					return e.w = e.h = 0, e.initialZoomLevel = e.fitRatio = 1, e.bounds = {
						center: {
							x: 0,
							y: 0
						},
						max: {
							x: 0,
							y: 0
						},
						min: {
							x: 0,
							y: 0
						}
					}, e.initialPosition = e.bounds.center, e.bounds
				},
				Kt = function(e, t, n, i, o, a) {
					t.loadError || i && (t.imageAppended = !0, Xt(t, i, t === r.currItem && Ee), n.appendChild(i), a && setTimeout(function() {
						t && t.loaded && t.placeholder && (t.placeholder.style.display = "none", t.placeholder = null)
					}, 500))
				},
				Wt = function(e) {
					e.loading = !0, e.loaded = !1;
					var t = e.img = o.createEl("pswp__img", "img"),
						n = function() {
							e.loading = !1, e.loaded = !0, e.loadComplete ? e.loadComplete(e) : e.img = null, t.onload = t.onerror = null, t = null
						};
					return t.onload = n, t.onerror = function() {
						e.loadError = !0, n()
					}, t.src = e.src, t
				},
				Vt = function(e, t) {
					if (e.src && e.loadError && e.container) return t && (e.container.innerHTML = ""), e.container.innerHTML = a.errorMsg.replace("%url%", e.src), !0
				},
				Xt = function(e, t, n) {
					if (e.src) {
						t || (t = e.container.lastChild);
						var i = n ? e.w : Math.round(e.w * e.fitRatio),
							o = n ? e.h : Math.round(e.h * e.fitRatio);
						e.placeholder && !e.loaded && (e.placeholder.style.width = i + "px", e.placeholder.style.height = o + "px"), t.style.width = i + "px", t.style.height = o + "px"
					}
				},
				Zt = function() {
					if (zt.length) {
						for (var e, t = 0; t < zt.length; t++)(e = zt[t]).holder.index === e.index && Kt(e.index, e.item, e.baseDiv, e.img, 0, e.clearPlaceholder);
						zt = []
					}
				};
			Te("Controller", {
				publicMethods: {
					lazyLoadItem: function(e) {
						e = we(e);
						var t = qt(e);
						t && (!t.loaded && !t.loading || T) && (Ie("gettingData", e, t), t.src && Wt(t))
					},
					initController: function() {
						o.extend(a, Yt, !0), r.items = Pt = n, qt = r.getItemAt, $t = a.getNumItemsFn, a.loop, $t() < 3 && (a.loop = !1), Ce("beforeChange", function(e) {
							var t, n = a.preload,
								i = null === e || e >= 0,
								o = Math.min(n[0], $t()),
								s = Math.min(n[1], $t());
							for (t = 1; t <= (i ? s : o); t++) r.lazyLoadItem(u + t);
							for (t = 1; t <= (i ? o : s); t++) r.lazyLoadItem(u - t)
						}), Ce("initialLayout", function() {
							r.currItem.initialLayout = a.getThumbBoundsFn && a.getThumbBoundsFn(u)
						}), Ce("mainScrollAnimComplete", Zt), Ce("initialZoomInEnd", Zt), Ce("destroy", function() {
							for (var e, t = 0; t < Pt.length; t++)(e = Pt[t]).container && (e.container = null), e.placeholder && (e.placeholder = null), e.img && (e.img = null), e.preloader && (e.preloader = null), e.loadError && (e.loaded = e.loadError = !1);
							zt = null
						})
					},
					getItemAt: function(e) {
						return e >= 0 && void 0 !== Pt[e] && Pt[e]
					},
					allowProgressiveImg: function() {
						return a.forceProgressiveLoading || !N || a.mouseUsed || screen.width > 1200
					},
					setContent: function(e, t) {
						a.loop && (t = we(t));
						var n = r.getItemAt(e.index);
						n && (n.container = null);
						var i, l = r.getItemAt(t);
						if (l) {
							Ie("gettingData", t, l), e.index = t, e.item = l;
							var c = l.container = o.createEl("pswp__zoom-wrap");
							if (!l.src && l.html && (l.html.tagName ? c.appendChild(l.html) : c.innerHTML = l.html), Vt(l), jt(l, fe), !l.src || l.loadError || l.loaded) l.src && !l.loadError && ((i = o.createEl("pswp__img", "img")).style.opacity = 1, i.src = l.src, Xt(l, i), Kt(0, l, c, i));
							else {
								if (l.loadComplete = function(n) {
										if (s) {
											if (e && e.index === t) {
												if (Vt(n, !0)) return n.loadComplete = n.img = null, jt(n, fe), Ne(n), void(e.index === u && r.updateCurrZoomItem());
												n.imageAppended ? !Ht && n.placeholder && (n.placeholder.style.display = "none", n.placeholder = null) : P.transform && (ne || Ht) ? zt.push({
													item: n,
													baseDiv: c,
													img: n.img,
													index: t,
													holder: e,
													clearPlaceholder: !0
												}) : Kt(0, n, c, n.img, 0, !0)
											}
											n.loadComplete = null, n.img = null, Ie("imageLoadComplete", t, n)
										}
									}, o.features.transform) {
									var d = "pswp__img pswp__img--placeholder";
									d += l.msrc ? "" : " pswp__img--placeholder--blank";
									var f = o.createEl(d, l.msrc ? "img" : "");
									l.msrc && (f.src = l.msrc), Xt(l, f), c.appendChild(f), l.placeholder = f
								}
								l.loading || Wt(l), r.allowProgressiveImg() && (!Ft && P.transform ? zt.push({
									item: l,
									baseDiv: c,
									img: l.img,
									index: t,
									holder: e
								}) : Kt(0, l, c, l.img, 0, !0))
							}
							Ft || t !== u ? Ne(l) : (te = c.style, Gt(l, i || l.img)), e.el.innerHTML = "", e.el.appendChild(c)
						} else e.el.innerHTML = ""
					},
					cleanSlide: function(e) {
						e.img && (e.img.onload = e.img.onerror = null), e.loaded = e.loading = e.img = e.imageAppended = !1
					}
				}
			});
			var Qt, Jt, en = {},
				tn = function(e, t, n) {
					var i = document.createEvent("CustomEvent"),
						o = {
							origEvent: e,
							target: e.target,
							releasePoint: t,
							pointerType: n || "touch"
						};
					i.initCustomEvent("pswpTap", !0, !0, o), e.target.dispatchEvent(i)
				};
			Te("Tap", {
				publicMethods: {
					initTap: function() {
						Ce("firstTouchStart", r.onTapStart), Ce("touchRelease", r.onTapRelease), Ce("destroy", function() {
							en = {}, Qt = null
						})
					},
					onTapStart: function(e) {
						e.length > 1 && (clearTimeout(Qt), Qt = null)
					},
					onTapRelease: function(e, t) {
						if (t && !W && !j && !je) {
							var n = t;
							if (Qt && (clearTimeout(Qt), Qt = null, function(e, t) {
									return Math.abs(e.x - t.x) < 25 && Math.abs(e.y - t.y) < 25
								}(n, en))) return void Ie("doubleTap", n);
							if ("mouse" === t.type) return void tn(e, t, "mouse");
							if ("BUTTON" === e.target.tagName.toUpperCase() || o.hasClass(e.target, "pswp__single-tap")) return void tn(e, t);
							Re(en, n), Qt = setTimeout(function() {
								tn(e, t), Qt = null
							}, 300)
						}
					}
				}
			}), Te("DesktopZoom", {
				publicMethods: {
					initDesktopZoom: function() {
						k || (N ? Ce("mouseUsed", function() {
							r.setupDesktopZoom()
						}) : r.setupDesktopZoom(!0))
					},
					setupDesktopZoom: function(t) {
						Jt = {};
						var n = "wheel mousewheel DOMMouseScroll";
						Ce("bindEvents", function() {
							o.bind(e, n, r.handleMouseWheel)
						}), Ce("unbindEvents", function() {
							Jt && o.unbind(e, n, r.handleMouseWheel)
						}), r.mouseZoomedIn = !1;
						var i, a = function() {
								r.mouseZoomedIn && (o.removeClass(e, "pswp--zoomed-in"), r.mouseZoomedIn = !1), g < 1 ? o.addClass(e, "pswp--zoom-allowed") : o.removeClass(e, "pswp--zoom-allowed"), s()
							},
							s = function() {
								i && (o.removeClass(e, "pswp--dragging"), i = !1)
							};
						Ce("resize", a), Ce("afterChange", a), Ce("pointerDown", function() {
							r.mouseZoomedIn && (i = !0, o.addClass(e, "pswp--dragging"))
						}), Ce("pointerUp", s), t || a()
					},
					handleMouseWheel: function(e) {
						if (g <= r.currItem.fitRatio) return a.modal && (!a.closeOnScroll || je || Y ? e.preventDefault() : D && Math.abs(e.deltaY) > 2 && (c = !0, r.close())), !0;
						if (e.stopPropagation(), Jt.x = 0, "deltaX" in e) 1 === e.deltaMode ? (Jt.x = 18 * e.deltaX, Jt.y = 18 * e.deltaY) : (Jt.x = e.deltaX, Jt.y = e.deltaY);
						else if ("wheelDelta" in e) e.wheelDeltaX && (Jt.x = -.16 * e.wheelDeltaX), e.wheelDeltaY ? Jt.y = -.16 * e.wheelDeltaY : Jt.y = -.16 * e.wheelDelta;
						else {
							if (!("detail" in e)) return;
							Jt.y = e.detail
						}
						Fe(g, !0);
						var t = de.x - Jt.x,
							n = de.y - Jt.y;
						(a.modal || t <= ee.min.x && t >= ee.max.x && n <= ee.min.y && n >= ee.max.y) && e.preventDefault(), r.panTo(t, n)
					},
					toggleDesktopZoom: function(t) {
						t = t || {
							x: fe.x / 2 + he.x,
							y: fe.y / 2 + he.y
						};
						var n = a.getDoubleTapZoom(!0, r.currItem),
							i = g === n;
						r.mouseZoomedIn = !i, r.zoomTo(i ? r.currItem.initialZoomLevel : n, t, 333), o[(i ? "remove" : "add") + "Class"](e, "pswp--zoomed-in")
					}
				}
			});
			var nn, on, rn, an, sn, ln, cn, un, dn, fn, pn, hn, mn = {
					history: !0,
					galleryUID: 1
				},
				gn = function() {
					return pn.hash.substring(1)
				},
				vn = function() {
					nn && clearTimeout(nn), rn && clearTimeout(rn)
				},
				yn = function() {
					var e = gn(),
						t = {};
					if (e.length < 5) return t;
					var n, i = e.split("&");
					for (n = 0; n < i.length; n++)
						if (i[n]) {
							var o = i[n].split("=");
							o.length < 2 || (t[o[0]] = o[1])
						} if (a.galleryPIDs) {
						var r = t.pid;
						for (t.pid = 0, n = 0; n < Pt.length; n++)
							if (Pt[n].pid === r) {
								t.pid = n;
								break
							}
					} else t.pid = parseInt(t.pid, 10) - 1;
					return t.pid < 0 && (t.pid = 0), t
				},
				bn = function() {
					if (rn && clearTimeout(rn), je || Y) rn = setTimeout(bn, 500);
					else {
						an ? clearTimeout(on) : an = !0;
						var e = u + 1,
							t = qt(u);
						t.hasOwnProperty("pid") && (e = t.pid);
						var n = cn + "&gid=" + a.galleryUID + "&pid=" + e;
						un || -1 === pn.hash.indexOf(n) && (fn = !0);
						var i = pn.href.split("#")[0] + "#" + n;
						hn ? "#" + n !== window.location.hash && history[un ? "replaceState" : "pushState"]("", document.title, i) : un ? pn.replace(i) : pn.hash = n, un = !0, on = setTimeout(function() {
							an = !1
						}, 60)
					}
				};
			Te("History", {
				publicMethods: {
					initHistory: function() {
						if (o.extend(a, mn, !0), a.history) {
							pn = window.location, fn = !1, dn = !1, un = !1, cn = gn(), hn = "pushState" in history, cn.indexOf("gid=") > -1 && (cn = (cn = cn.split("&gid=")[0]).split("?gid=")[0]), Ce("afterChange", r.updateURL), Ce("unbindEvents", function() {
								o.unbind(window, "hashchange", r.onHashChange)
							});
							var e = function() {
								ln = !0, dn || (fn ? history.back() : cn ? pn.hash = cn : hn ? history.pushState("", document.title, pn.pathname + pn.search) : pn.hash = ""), vn()
							};
							Ce("unbindEvents", function() {
								c && e()
							}), Ce("destroy", function() {
								ln || e()
							}), Ce("firstUpdate", function() {
								u = yn().pid
							});
							var t = cn.indexOf("pid=");
							t > -1 && "&" === (cn = cn.substring(0, t)).slice(-1) && (cn = cn.slice(0, -1)), setTimeout(function() {
								s && o.bind(window, "hashchange", r.onHashChange)
							}, 40)
						}
					},
					onHashChange: function() {
						return gn() === cn ? (dn = !0, void r.close()) : void(an || (sn = !0, r.goTo(yn().pid), sn = !1))
					},
					updateURL: function() {
						vn(), sn || (un ? nn = setTimeout(bn, 800) : bn())
					}
				}
			}), o.extend(r, Ze)
		}
	}), function(e) {
		"use strict";
		var t = ".dropdown-backdrop",
			n = '[data-toggle="dropdown"]',
			i = function(t) {
				e(t).on("click.bs.dropdown", this.toggle)
			};

		function o(t) {
			var n = t.attr("data-target");
			n || (n = (n = t.attr("href")) && /#[A-Za-z]/.test(n) && n.replace(/.*(?=#[^\s]*$)/, ""));
			var i = "#" !== n ? e(document).find(n) : null;
			return i && i.length ? i : t.parent()
		}

		function r(i) {
			i && 3 === i.which || (e(t).remove(), e(n).each(function() {
				var t = e(this),
					n = o(t),
					r = {
						relatedTarget: this
					};
				n.hasClass("open") && (i && "click" == i.type && /input|textarea/i.test(i.target.tagName) && e.contains(n[0], i.target) || (n.trigger(i = e.Event("hide.bs.dropdown", r)), i.isDefaultPrevented() || (t.attr("aria-expanded", "false"), n.removeClass("open").trigger(e.Event("hidden.bs.dropdown", r)))))
			}))
		}
		i.VERSION = "3.4.1", i.prototype.toggle = function(t) {
			var n = e(this);
			if (!n.is(".disabled, :disabled")) {
				var i = o(n),
					a = i.hasClass("open");
				if (r(), !a) {
					"ontouchstart" in document.documentElement && !i.closest(".navbar-nav").length && e(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(e(this)).on("click", r);
					var s = {
						relatedTarget: this
					};
					if (i.trigger(t = e.Event("show.bs.dropdown", s)), t.isDefaultPrevented()) return;
					n.trigger("focus").attr("aria-expanded", "true"), i.toggleClass("open").trigger(e.Event("shown.bs.dropdown", s))
				}
				return !1
			}
		}, i.prototype.keydown = function(t) {
			if (/(38|40|27|32)/.test(t.which) && !/input|textarea/i.test(t.target.tagName)) {
				var i = e(this);
				if (t.preventDefault(), t.stopPropagation(), !i.is(".disabled, :disabled")) {
					var r = o(i),
						a = r.hasClass("open");
					if (!a && 27 != t.which || a && 27 == t.which) return 27 == t.which && r.find(n).trigger("focus"), i.trigger("click");
					var s = r.find(".dropdown-menu li:not(.disabled):visible a");
					if (s.length) {
						var l = s.index(t.target);
						38 == t.which && l > 0 && l--, 40 == t.which && l < s.length - 1 && l++, ~l || (l = 0), s.eq(l).trigger("focus")
					}
				}
			}
		};
		var a = e.fn.dropdown;
		e.fn.dropdown = function(t) {
			return this.each(function() {
				var n = e(this),
					o = n.data("bs.dropdown");
				o || n.data("bs.dropdown", o = new i(this)), "string" == typeof t && o[t].call(n)
			})
		}, e.fn.dropdown.Constructor = i, e.fn.dropdown.noConflict = function() {
			return e.fn.dropdown = a, this
		}, e(document).on("click.bs.dropdown.data-api", r).on("click.bs.dropdown.data-api", ".dropdown form", function(e) {
			e.stopPropagation()
		}).on("click.bs.dropdown.data-api", n, i.prototype.toggle).on("keydown.bs.dropdown.data-api", n, i.prototype.keydown).on("keydown.bs.dropdown.data-api", ".dropdown-menu", i.prototype.keydown)
	}(jQuery), polyfill(Array, "from", function(e) {
		return Array.prototype.slice.call(e)
	}), polyfill(Array.prototype, "forEach", function(e) {
		var t, n;
		if (null == this) throw new TypeError("this is null or not defined");
		var i = Object(this),
			o = i.length >>> 0;
		if ("function" != typeof e) throw new TypeError(e + " is not a function");
		for (arguments.length > 1 && (t = arguments[1]), n = 0; n < o;) {
			var r;
			n in i && (r = i[n], e.call(t, r, n, i)), n++
		}
	}), polyfill(Array.prototype, "each", Array.prototype.forEach), polyfill(Function.prototype, "bind", function(e) {
		if ("function" != typeof this) throw new TypeError("Bind must be called on a function");
		var t = this,
			n = Array.from(arguments).slice(1);

		function i() {}
		var o = function() {
			var o = this instanceof i ? this : e;
			return t.apply(o, n.concat(Array.from(arguments)))
		};
		return i.prototype = t.prototype, o.prototype = new i, o
	}), polyfill(Object, "assign", function(e, t) {
		return e = null == e ? {} : Object(e), Array.from(arguments).slice(1).map(function(t) {
			null != t && Object.keys(t).map(function(t, n) {
				var i = Object.getOwnPropertyDescriptor(t, n);
				void 0 !== i && i.enumerable && (e[n] = t[n])
			}.bind(t, t))
		}), e
	}), polyfill(Element.prototype, "matches", Element.prototype.msMatchesSelector), ["indexOf", "slice", "forEach", "each", "map", "reduce", "filter", "every", "some"].each(function(e) {
		polyfill(NodeList.prototype, e, Array.prototype[e])
	}), polyfill(NodeList.prototype, "matches", function(e) {
		return this.filter(function(t) {
			return t.matches(e)
		})
	}), polyfill(NodeList.prototype, "match", function(e) {
		var t, n = this.length;
		for (t = 0; t < n; t++)
			if (this[t].matches(e)) return this[t];
		return null
	}), Object.defineProperty(Node.prototype, "textNodes", {
		enumerable: !1,
		configurable: !0,
		get: function() {
			for (var e, t = {
					SCRIPT: !0,
					NOSCRIPT: !0,
					STYLE: !0
				}, n = [], i = document.createTreeWalker(this, NodeFilter.SHOW_TEXT, null, !1); e = i.nextNode();) t[e.parentNode.nodeName] || n.push(e);
			return n
		}
	}), polyfill(Element.prototype, "attributeSelector", function(e) {
		var t = this,
			n = [];
		return Array.prototype.map.call(arguments, function(e) {
			var i = t.getAttribute(e);
			null == i || "" === i ? n.push("[" + e + "]") : n.push("[" + e + '="' + i + '"]')
		}), n.join("")
	}), polyfill(Array.prototype, "sortBy", function(e, t) {
		if (!this.length) return this;
		var n, i, o = function() {
			return this
		};
		return e && (o = "function" == typeof e ? e : function() {
			return this[e]
		}), !t && "number" == typeof(e ? o.call(this[this.length - 1]) : this[this.length - 1]) && (t = function(e, t) {
			return e - t
		}), e && (n = Object.prototype.toString, i = Array.prototype.toString, Object.prototype.toString = o, Array.prototype.toString = o), t ? Array.prototype.sort.call(this, t) : Array.prototype.sort.call(this), e && (Object.prototype.toString = n, Array.prototype.toString = i), this
	}), !("classList" in document.documentElement)) {
	function DOMTokenList(e) {
		this.element = e;
		var t = e.className.trim().split(/\s+/);
		Array.prototype.push.apply(this, t)
	}
	DOMTokenList.prototype = {
		add: function(e) {
			this.contains(e) || (Array.prototype.push.call(this, e), this.element.className = this.toString())
		},
		contains: function(e) {
			return (" " + this.element.className + " ").indexOf(" " + e + " ") >= 0
		},
		item: function(e) {
			return this[e] || null
		},
		remove: function(e) {
			if (this.contains(e)) {
				for (var t = 0; t < this.length; t++) this[t] == e && Array.prototype.splice.call(this, t--, 1);
				this.element.className = this.toString()
			}
		},
		toString: function() {
			return Array.prototype.join.call(this, " ")
		},
		toggle: function(e) {
			return this.contains(e) ? this.remove(e) : this.add(e), this.contains(e)
		}
	}, window.DOMTokenList = DOMTokenList, Object.defineProperty(Element.prototype, "classList", {
		get: function() {
			return new DOMTokenList(this)
		}
	})
}

function CustomEvent(e, t) {
	t = t || {
		bubbles: !1,
		cancelable: !1,
		detail: void 0
	};
	var n = document.createEvent("CustomEvent");
	return n.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), n
}

function trigger(e) {
	var t;
	switch (e) {
		case "resize":
			"function" == typeof UIEvent ? t = new UIEvent(e) : (t = document.createEvent("UIEvent")).initUIEvent(e, !0, !0, window, 1);
			break;
		default:
			t = new CustomEvent(e)
	}
	this.dispatchEvent(t)
}

function updateIfFullscreen() {
	var e = window.outerWidth == window.screen.width && window.outerHeight == window.screen.height;
	document.body.classList[e ? "add" : "remove"]("is-fullscreen")
}

function querySelectorAlways(e, t) {
	if (!t) throw new Error("querySelectorAlways expects a callback");
	querySelectorAlways.init(), querySelectorAlways.addSelector(e, t)
}
CustomEvent.prototype = window.Event.prototype, window.CustomEvent = CustomEvent, polyfill(Element.prototype, "trigger", trigger), window.trigger = trigger, polyfill(Date, "now", function() {
		return (new Date).getTime()
	}), window.performance = window.performance || {}, polyfill(performance, "now", function() {
		return Date.now()
	}), window.setImmediate || window.setImmediate,
	function() {
		for (var e = 0, t = ["ms", "moz", "webkit", "o"], n = 0; n < t.length && !window.requestAnimationFrame; ++n) window.requestAnimationFrame = window[t[n] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[t[n] + "CancelAnimationFrame"] || window[t[n] + "CancelRequestAnimationFrame"];
		window.requestAnimationFrame || (window.requestAnimationFrame = function(t, n) {
			var i = (new Date).getTime();
			var o = Math.max(0, 16 - (i - e));
			return e = i + o, window.setTimeout(function() {
				t(i + o)
			}, o)
		}), window.cancelAnimationFrame || (window.cancelAnimationFrame = function(e) {
			clearTimeout(e)
		})
	}(), window.addEventListener("resize", updateIfFullscreen), window.addEventListener("load", updateIfFullscreen), querySelectorAlways.attribute = "queryselectoralways", querySelectorAlways.init = function() {
		querySelectorAlways.style || (querySelectorAlways.style = document.createElement("style"), querySelectorAlways.style.id = "querySelectorAlways", querySelectorAlways.style.appendChild(document.createTextNode("")), document.head.appendChild(querySelectorAlways.style), ["animationstart", "MSAnimationStart", "webkitAnimationStart"].map(function(e) {
			document.addEventListener(e, querySelectorAlways.onanimationstart, !1)
		}), document.addEventListener("DOMContentLoaded", querySelectorAlways.update))
	}, querySelectorAlways.selectors = {}, querySelectorAlways.callbacks = [], querySelectorAlways.addSelector = function(e, t) {
		e = e.trim();
		var n = querySelectorAlways.selectors[e];
		return n ? querySelectorAlways.callbacks[n].push(t) : (n = querySelectorAlways.callbacks.length, querySelectorAlways.selectors[e] = n, querySelectorAlways.callbacks[n] = [t], querySelectorAlways.install(n, e)), n
	}, querySelectorAlways.update = function() {
		var e, t;
		for (e in querySelectorAlways.selectors) {
			t = querySelectorAlways.selectors[e];
			var n = document.querySelectorAll(e);
			Array.prototype.map.call(n, function(e) {
				querySelectorAlways.addNode(t, e)
			})
		}
	}, querySelectorAlways.install = function(e, t) {
		querySelectorAlways.style;
		var n = "querySelectorAlways" + e,
			i = ":not([" + querySelectorAlways.attribute + '~="' + e + '"])';

		function o(e) {
			querySelectorAlways.style.textContent += "\n" + e
		}
		o((t = t.replace(/(,|$)/g, function(e) {
			return i + e
		})) + " { visibility:hidden!important; animation: 0.001ms " + n + "!important; -webkit-animation: 0.001ms " + n + "!important; }"), o("@keyframes " + n + " { from { opacity: 0.999; } to { opacity: 1; } }"), o("@-webkit-keyframes " + n + " { from { opacity: 0.999; } to { opacity: 1; } }\n")
	}, querySelectorAlways.regexEvent = /querySelectorAlways(\d+)/, querySelectorAlways.onanimationstart = function(e) {
		var t = e.animationName.match(querySelectorAlways.regexEvent);
		if (t) {
			var n = parseInt(t[1]),
				i = e.target;
			querySelectorAlways.addNode.call(this, n, i)
		}
	}, querySelectorAlways.addNode = function(e, t) {
		var n = t.getAttribute(querySelectorAlways.attribute),
			i = n ? n.split(" ") : [];
		if (i.indexOf(String(e)) < 0) {
			i.push(e), t.setAttribute(querySelectorAlways.attribute, i.join(" "));
			var o = querySelectorAlways.callbacks[e];
			o && o.map(function(e) {
				e(t)
			})
		}
	}, document.querySelectorAlways = querySelectorAlways;
var Mouse = {
	x: 0,
	y: 0,
	lastX: 0,
	lastY: 0,
	dX: 0,
	dY: 0,
	timestamp: 0,
	timeElapsed: 0,
	init: function() {
		window.addEventListener("mousemove", Mouse.update), window.addEventListener("touchstart", Mouse.update), window.addEventListener("touchmove", Mouse.update), Mouse.timestamp = Date.now(), requestAnimationFrame(Mouse.tick)
	},
	update: function(e) {
		var t = e.changedTouches ? e.changedTouches[0] : e;
		Mouse.x = t.pageX, Mouse.y = t.pageY
	},
	snapshot: function() {
		return {
			x: Mouse.x,
			y: Mouse.y,
			lastX: Mouse.lastX,
			lastY: Mouse.lastY,
			dX: Mouse.dX,
			dY: Mouse.dY,
			timestamp: Mouse.timestamp,
			timeElapsed: Mouse.timeElapsed
		}
	},
	tick: function() {
		var e = Mouse.snapshot(),
			t = Date.now();
		Mouse.dX = e.x - e.lastX, Mouse.dY = e.y - e.lastY, Mouse.lastX = e.x, Mouse.lastY = e.y, Mouse.timeElapsed = t - e.timestamp, Mouse.timestamp = t, requestAnimationFrame(Mouse.tick)
	}
};

function Animation(e) {
	this.fn = e, this.paused = !0, this.timestamp = 0, this.update = this.update.bind(this)
}

function SVG(e) {
	if (this.elem = e, this.href = e.getAttribute("xlink:href"), this.href) {
		var t = this.href.indexOf("#");
		this.url = this.href.substr(0, t), this.id = this.href.substr(t + 1), this.init()
	}
}
Animation.prototype = {
	start: function() {
		this.paused && (this.paused = !1, this.timestamp = performance.now(), requestAnimationFrame(this.update))
	},
	stop: function(e) {
		this.paused = !0, !0 !== e && (this.timestamp = 0)
	},
	update: function(e) {
		if (this.timestamp) {
			var t = e - this.timestamp;
			this.timestamp = e, this.fn(t), this.paused || requestAnimationFrame(this.update)
		}
	}
}, Object.assign(SVG, {
	svgs: {},
	support: !/\bTrident\/\d+\b/.test(navigator.userAgent),
	init: function() {
		SVG.support || document.querySelectorAlways("svg use", SVG.create)
	},
	create: function(e) {
		new SVG(e)
	}
}), SVG.prototype = {
	init: function() {
		var e = this.svg();
		e instanceof XMLHttpRequest ? e.addEventListener("load", this.load.bind(this)) : this.load()
	},
	svg: function() {
		var e = document;
		return this.url && ((e = SVG.svgs[this.url]) || (e = SVG.svgs[this.url] = this.ajax(this.url))), e
	},
	ajax: function(e) {
		var t = new XMLHttpRequest;
		return t.open("GET", encodeURI(e), !0), t.addEventListener("load", function() {
			if (t.status < 400) {
				var n = document.implementation.createHTMLDocument("");
				n.body.innerHTML = t.responseText, SVG.svgs[e] = n.querySelector("svg")
			}
		}), t.send(), t
	},
	load: function() {
		this.set(this.svg().getElementById(this.id))
	},
	set: function(e) {
		if (e) {
			for (var t = e.cloneNode(!0), n = document.createDocumentFragment(); t.firstChild;) n.appendChild(t.firstChild);
			this.elem.appendChild(n)
		}
	}
}, SVG.init();
var UI = {
	KEY_BEFORE_INIT_HANDLER: "beforeInit",
	KEY_INIT_HANDLER: "init",
	KEY_AFTER_INIT_HANDLER: "afterInit",
	KEY_BEFORE_LOAD_HANDLER: "beforeLoad",
	KEY_LOAD_HANDLER: "load",
	KEY_AFTER_LOAD_HANDLER: "afterLoad",
	KEY_REFRESH_HANDLER: "refresh",
	KEY_RESIZE_HANDLER: "resize",
	KEY_SCROLL_HANDLER: "scroll",
	KEY_DOCUMENT_BLUR_HANDLER: "documentBlur",
	EVENTS_TRANSITION_END: "webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend",
	EVENTS_ANIMATION_END: "webkitAnimationEnd oanimationend msAnimationEnd animationend",
	DEFAULT_ANIMATION_DURATION: 200,
	DEFAULT_SLIDE_ANIMATION_DURATION: 250,
	DEFAULT_NAVIGATION_CONTAINER: "#nav-client-header",
	SCROLL_TARGET: $("html, body"),
	BREAKPOINTS: {
		BASE: 0,
		XS: 480,
		SM: 768,
		MD: 992,
		LG: 1200,
		HG: 1600
	},
	components: [],
	beforeInitHandlers: [],
	initHandlers: [],
	afterInitHandlers: [],
	beforeLoadHandlers: [],
	loadHandlers: [],
	afterLoadHandlers: [],
	refreshHandlers: [],
	resizeHandlers: [],
	scrollHandlers: [],
	documentBlurHandlers: [],
	historyPopHandlers: [],
	resizing: !1,
	scrolling: !1,
	scrollingPage: !1,
	uuids: 0,
	lastTouchEvent: 0,
	DEFAULT_MILLISECONDS_FOR_TOUCH: 500,
	mouse: Mouse,
	registerHandler: function(e, t, n) {
		var i = e[t];
		$.isFunction(i) && n.push(i)
	},
	register: function(e) {
		e && UI.components.indexOf(e) < 0 && (UI.registerHandler(e, UI.KEY_BEFORE_INIT_HANDLER, UI.beforeInitHandlers), UI.registerHandler(e, UI.KEY_INIT_HANDLER, UI.initHandlers), UI.registerHandler(e, UI.KEY_AFTER_INIT_HANDLER, UI.afterInitHandlers), UI.registerHandler(e, UI.KEY_BEFORE_LOAD_HANDLER, UI.beforeLoadHandlers), UI.registerHandler(e, UI.KEY_LOAD_HANDLER, UI.loadHandlers), UI.registerHandler(e, UI.KEY_AFTER_LOAD_HANDLER, UI.afterLoadHandlers), UI.registerHandler(e, UI.KEY_REFRESH_HANDLER, UI.refreshHandlers), UI.registerHandler(e, UI.KEY_RESIZE_HANDLER, UI.resizeHandlers), UI.registerHandler(e, UI.KEY_SCROLL_HANDLER, UI.scrollHandlers), UI.registerHandler(e, UI.KEY_DOCUMENT_BLUR_HANDLER, UI.documentBlurHandlers), UI.components.push(e))
	},
	init: function(e) {
		e || (UI.mouse.init(), $(document).on("touchend", function() {
			UI.handleTouchEnd()
		})), UI.beforeInitHandlers.forEach(function(t, n) {
			t(e)
		}), UI.initHandlers.forEach(function(t, n) {
			t(e)
		}), UI.refresh(e, !0), UI.afterInitHandlers.forEach(function(t, n) {
			t(e)
		}), e || ($(window).on("resize", UI.resize), $(window).on("scroll", UI.scroll), UI.SCROLL_TARGET.on("scroll mousedown wheel DOMMouseScroll mousewheel keyup", UI.scrollInterrupt), $(document).on("visibilitychange", UI.handleDocumentBlur), $(window).on("popstate", UI.handleBrowserHistoryPop))
	},
	load: function(e) {
		UI.beforeLoadHandlers.forEach(function(t, n) {
			t(e)
		}), UI.loadHandlers.forEach(function(t, n) {
			t(e)
		}), UI.afterLoadHandlers.forEach(function(t, n) {
			t(e)
		})
	},
	refresh: function(e, t) {
		UI.refreshHandlers.forEach(function(n, i) {
			n(e, t)
		})
	},
	resize: function() {
		UI.resizing || (UI.resizing = !0, requestAnimationFrame(UI.resizeRunner))
	},
	resizeRunner: function() {
		UI.resizeHandlers.forEach(function(e) {
			e()
		}), UI.resizing = !1
	},
	scroll: function() {
		UI.scrolling || (UI.scrolling = !0, requestAnimationFrame(UI.scrollRunner))
	},
	scrollRunner: function() {
		UI.scrollHandlers.forEach(function(e) {
			e()
		}), UI.scrolling = !1
	},
	scrollInterrupt: function(e) {
		((e = e.originalEvent || e).which > 0 || "mousedown" === e.type || "mousewheel" === e.type || "wheel" === e.type) && UI.scrollStop()
	},
	handleDocumentBlur: function() {
		UI.documentBlurHandlers.forEach(function(e, t) {
			e()
		})
	},
	generateUUID: function(e) {
		return (e = e || "Object") + ++UI.uuids + "-" + Date.now()
	},
	isDesktopMode: function() {
		return "desktop" === $("body").attr("data-device")
	},
	isMobileMode: function() {
		return "desktop" !== $("body").attr("data-device")
	},
	isMatchBreakpoint: function(e) {
		return window.matchMedia("(min-width: " + e + "px)").matches
	},
	getCurrentBreakpoint: function() {
		if (window.matchMedia) return UI.isMatchBreakpoint(UI.BREAKPOINTS.HG) ? UI.BREAKPOINTS.HG : UI.isMatchBreakpoint(UI.BREAKPOINTS.LG) ? UI.BREAKPOINTS.LG : UI.isMatchBreakpoint(UI.BREAKPOINTS.MD) ? UI.BREAKPOINTS.MD : UI.isMatchBreakpoint(UI.BREAKPOINTS.SM) ? UI.BREAKPOINTS.SM : UI.isMatchBreakpoint(UI.BREAKPOINTS.XS) ? UI.BREAKPOINTS.XS : UI.BREAKPOINTS.BASE;
		var e = $(window).width();
		return e >= UI.BREAKPOINTS.HG ? UI.BREAKPOINTS.HG : e >= UI.BREAKPOINTS.LG ? UI.BREAKPOINTS.LG : e >= UI.BREAKPOINTS.MD ? UI.BREAKPOINTS.MD : e >= UI.BREAKPOINTS.SM ? UI.BREAKPOINTS.SM : e >= UI.BREAKPOINTS.XS ? UI.BREAKPOINTS.XS : UI.BREAKPOINTS.BASE
	},
	isAboveBreakpoint: function(e) {
		return UI.getCurrentBreakpoint() >= e
	},
	isBelowBreakpoint: function(e) {
		return UI.getCurrentBreakpoint() < e
	},
	onTransitionEnd: function(e, t, n) {
		var i = $(e);
		n ? i.one(UI.EVENTS_TRANSITION_END, t) : i.on(UI.EVENTS_TRANSITION_END, t)
	},
	isFocusedInWindow: function(e) {
		var t = e.getBoundingClientRect(),
			n = window.innerHeight,
			i = n / 2;
		return t.top < i && n - t.bottom < i
	},
	updateBrowserHistory: function(e, t, n, i) {
		e = e || {}, i = i || "", window.history ? n ? window.history.pushState(e, i, t) : window.history.replaceState(e, i, t) : console.error("Fatal: unable to manipulate browser history")
	},
	addBrowserHistoryHandler: function(e) {
		e && $.isFunction(e) && UI.historyPopHandlers.push(e)
	},
	handleBrowserHistoryPop: function(e) {
		UI.historyPopHandlers.forEach(function(t) {
			t(e)
		})
	},
	scrollIntoView: function(e, t, n) {
		if (e) {
			t = parseInt(t) || 0, UI.isBelowBreakpoint(UI.BREAKPOINTS.SM) && (t -= $(UI.DEFAULT_NAVIGATION_CONTAINER).outerHeight() || 0);
			var i, o = e.getBoundingClientRect();
			if (!(o.top < t || o.bottom > window.innerHeight)) return;
			i = $(e).offset().top + t, n = "number" == typeof n ? n : UI.DEFAULT_ANIMATION_DURATION, UI.scrollToHeight(i, n)
		}
	},
	scrollTo: function(e, t, n) {
		if (e) {
			t = parseInt(t) || 0, UI.isBelowBreakpoint(UI.BREAKPOINTS.SM) && (t -= $(UI.DEFAULT_NAVIGATION_CONTAINER).outerHeight() || 0);
			var i = $(e).offset().top + t;
			n = "number" == typeof n ? n : UI.DEFAULT_ANIMATION_DURATION, UI.scrollToHeight(i, n)
		}
	},
	scrollStop: function() {
		UI.scrollingPage && (UI.SCROLL_TARGET.stop(), UI.scrollingPage = !1)
	},
	scrollToHeight: function(e, t) {
		UI.scrollStop(), UI.scrollingPage = !0, UI.SCROLL_TARGET.animate({
			scrollTop: e
		}, {
			duration: t,
			easing: "easeOutCubic",
			complete: function() {
				UI.scrollingPage = !1
			}
		})
	},
	clearHeight: function(e) {
		var t = Array.prototype.slice.call(arguments);
		t && t.forEach(function(e) {
			e instanceof $ && e.height("")
		})
	},
	syncHeight: function(e) {
		if (e && e.length > 0) {
			var t = null,
				n = Array.prototype.slice.call(arguments);
			n && n.forEach(function(e, n) {
				n > 0 && e instanceof $ && (t = t ? t.add(e) : e)
			}), UI.clearHeight(t || e);
			var i = Math.max.apply(null, e.map(function() {
				return $(this).outerHeight()
			}).get());
			return (t || e).css("height", i + "px"), i
		}
		return 0
	},
	handleTouchEnd: function(e) {
		UI.lastTouchEvent = Date.now()
	},
	isRecentTouch: function(e) {
		return void 0 === e && (e = UI.DEFAULT_MILLISECONDS_FOR_TOUCH), 0 === e ? 0 !== UI.lastTouchEvent : Date.now() - UI.lastTouchEvent <= e
	},
	toggleModalLock: function(e) {
		$("body").toggleClass("modal-lock", e)
	},
	debounce: function(e, t, n) {
		var i;
		return function() {
			var o = this,
				r = arguments,
				a = n && !i;
			clearTimeout(i), i = setTimeout(function() {
				i = null, n || e.apply(o, r)
			}, t), a && e.apply(o, r)
		}
	},
	supports: {
		touch: "ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch,
		transitionEnd: function() {
			var e, t = document.createElement("fakeelement"),
				n = {
					transition: "transitionend",
					OTransition: "oTransitionEnd",
					MozTransition: "transitionend",
					WebkitTransition: "webkitTransitionEnd"
				};
			for (e in n)
				if (void 0 !== t.style[e]) return n[e];
			return !1
		}(),
		video: function() {
			var e = document.createElement("video"),
				t = {};
			return t = "canPlayType" in e ? {
				webm: e.canPlayType("video/webm"),
				mp4: e.canPlayType("video/mp4")
			} : {
				webm: !1,
				mp4: !1
			}, e = null, (t.webm || t.mp4) && !window.navigator.userAgent.match(/iPhone|iPad|iPod/i)
		}(),
		audioMp3: function() {
			var e = document.createElement("audio");
			return !(!e.canPlayType || !e.canPlayType("audio/mpeg;").replace(/no/, ""))
		}()
	}
};
window && void 0 === window.UI && (window.UI = UI), $(document).ready(function() {
		UI.init()
	}), $(window).on("load", function() {
		UI.load()
	}), UI.TouchScroll = {
		KEY_DATA: "UITouchScrollData",
		SCROLL_THRESHOLD: 10,
		ANIMATION_SNAP_DURATION: 100,
		DRAG_THRESHOLD_RESISTANCE: .75,
		DRAG_MOMENTUM_MULTIPLIER: 150,
		EXTRA_MARGIN: 160,
		bind: function(e) {
			e.$root && e.$wrapper && e.$container || console.error("Error: invalid bindings object"), e.$container.on("touchstart", UI.TouchScroll.handleStart.bind(null, e)), e.$container.on("touchend", UI.TouchScroll.handleEnd.bind(null, e))
		},
		checkOverflows: function(e, t, n, i) {
			e.toggleClass("is-rightMax", t <= n), e.toggleClass("is-leftMax", t >= i)
		},
		handleStart: function(e, t) {
			var n = e.$root,
				i = (e.$wrapper, e.$container);
			UI.mouse.update(t.originalEvent);
			var o = UI.mouse.snapshot();
			n.hasClass("is-constrained") && (n.data(UI.TouchScroll.KEY_DATA, {
				x: o.x,
				x0: o.x,
				left: i.position().left + UI.TouchScroll.EXTRA_MARGIN,
				active: !1
			}), i.stop(!0), i.on("touchmove", UI.TouchScroll.handleMove.bind(null, e)))
		},
		handleMove: function(e, t) {
			requestAnimationFrame(UI.TouchScroll.move.bind(null, e))
		},
		move: function(e) {
			var t = e.$root,
				n = e.$wrapper,
				i = e.$container,
				o = UI.mouse.snapshot(),
				r = t.data(UI.TouchScroll.KEY_DATA),
				a = o.x - r.x;
			if (r.active || Math.abs(a) >= UI.TouchScroll.SCROLL_THRESHOLD) {
				r.active = !0, r.x = o.x;
				var s = i.width() - n.width(),
					l = o.x - r.x0,
					c = r.left + l;
				c < -s ? c = -s - Math.pow(Math.abs(c + s), UI.TouchScroll.DRAG_THRESHOLD_RESISTANCE) : c > 0 && (c = 0 + Math.pow(Math.abs(c - 0), UI.TouchScroll.DRAG_THRESHOLD_RESISTANCE)), c -= UI.TouchScroll.EXTRA_MARGIN, i.css("left", c + "px"), UI.TouchScroll.checkOverflows(t, c, -s, 0)
			}
		},
		handleEnd: function(e, t) {
			var n = e.$root,
				i = e.$wrapper,
				o = e.$container,
				r = n.data(UI.TouchScroll.KEY_DATA);
			o.off("touchmove");
			var a = UI.mouse.snapshot(),
				s = a.x - r.x,
				l = a.dX / a.timeElapsed * UI.TouchScroll.DRAG_MOMENTUM_MULTIPLIER;
			if (r.active || Math.abs(s) >= UI.TouchScroll.SCROLL_THRESHOLD) {
				r.active = !0, r.x = a.x;
				var c = o.width() - i.width(),
					u = o.position().left + UI.TouchScroll.EXTRA_MARGIN,
					d = u + l;
				d < -c ? d = -c - Math.pow(Math.abs(d + c), UI.TouchScroll.DRAG_THRESHOLD_RESISTANCE) : d > 0 && (d = 0 + Math.pow(Math.abs(d - 0), UI.TouchScroll.DRAG_THRESHOLD_RESISTANCE)), l = Math.abs(d - u) / 2, u = e.snap && "function" == typeof e.snap ? e.snap(d, 0, c) : Math.min(0, Math.max(d, -c)), UI.TouchScroll.checkOverflows(n, u, -c, 0), d -= UI.TouchScroll.EXTRA_MARGIN, u -= UI.TouchScroll.EXTRA_MARGIN, o.animate({
					left: d
				}, {
					duration: l,
					easing: "easeOutCubic"
				}).animate({
					left: u
				}, {
					duration: UI.TouchScroll.ANIMATION_SNAP_DURATION,
					easing: "easeOutCubic"
				}), t.preventDefault(), r.active && (t.stopPropagation(), r.active = !1)
			}
		},
		isActive: function(e) {
			var t = e.data(UI.TouchScroll.KEY_DATA);
			return !(!t || !t.active)
		}
	},
	function(e) {
		if ("object" == typeof exports && "undefined" != typeof module) module.exports = e();
		else if ("function" == typeof define && define.amd) define([], e);
		else {
			("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).navbar = e()
		}
	}(function() {
		return function() {
			return function e(t, n, i) {
				function o(a, s) {
					if (!n[a]) {
						if (!t[a]) {
							var l = "function" == typeof require && require;
							if (!s && l) return l(a, !0);
							if (r) return r(a, !0);
							var c = new Error("Cannot find module '" + a + "'");
							throw c.code = "MODULE_NOT_FOUND", c
						}
						var u = n[a] = {
							exports: {}
						};
						t[a][0].call(u.exports, function(e) {
							return o(t[a][1][e] || e)
						}, u, u.exports, e, t, n, i)
					}
					return n[a].exports
				}
				for (var r = "function" == typeof require && require, a = 0; a < i.length; a++) o(i[a]);
				return o
			}
		}()({
			1: [function(e, t, n) {
				t.exports = 'a[href], area[href], input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex="0"], [contenteditable], audio[controls], video[controls], summary, [tabindex^="0"], [tabindex^="1"], [tabindex^="2"], [tabindex^="3"], [tabindex^="4"], [tabindex^="5"], [tabindex^="6"], [tabindex^="7"], [tabindex^="8"], [tabindex^="9"]'
			}, {}],
			2: [function(e, t, n) {
				! function(e) {
					"use strict";
					if ("document" in e)
						if ("classList" in document.createElement("_") && (!document.createElementNS || "classList" in document.createElementNS("http://www.w3.org/2000/svg", "svg").appendChild(document.createElement("g")))) {
							var t = document.createElement("_");
							if (t.classList.add("c1", "c2"), !t.classList.contains("c2")) {
								var n = function(e) {
									var t = DOMTokenList.prototype[e];
									DOMTokenList.prototype[e] = function(e) {
										var n, i = arguments.length;
										for (n = 0; n < i; n++) e = arguments[n], t.call(this, e)
									}
								};
								n("add"), n("remove")
							}
							if (t.classList.toggle("c3", !1), t.classList.contains("c3")) {
								var i = DOMTokenList.prototype.toggle;
								DOMTokenList.prototype.toggle = function(e, t) {
									return 1 in arguments && !this.contains(e) == !t ? t : i.call(this, e)
								}
							}
							t = null
						} else {
							if (!("Element" in e)) return;
							var o = e.Element.prototype,
								r = Object,
								a = String.prototype.trim || function() {
									return this.replace(/^\s+|\s+$/g, "")
								},
								s = Array.prototype.indexOf || function(e) {
									for (var t = 0, n = this.length; t < n; t++)
										if (t in this && this[t] === e) return t;
									return -1
								},
								l = function(e, t) {
									this.name = e, this.code = DOMException[e], this.message = t
								},
								c = function(e, t) {
									if ("" === t) throw new l("SYNTAX_ERR", "An invalid or illegal string was specified");
									if (/\s/.test(t)) throw new l("INVALID_CHARACTER_ERR", "String contains an invalid character");
									return s.call(e, t)
								},
								u = function(e) {
									for (var t = a.call(e.getAttribute("class") || ""), n = t ? t.split(/\s+/) : [], i = 0, o = n.length; i < o; i++) this.push(n[i]);
									this._updateClassName = function() {
										e.setAttribute("class", this.toString())
									}
								},
								d = u.prototype = [],
								f = function() {
									return new u(this)
								};
							if (l.prototype = Error.prototype, d.item = function(e) {
									return this[e] || null
								}, d.contains = function(e) {
									return -1 !== c(this, e += "")
								}, d.add = function() {
									var e, t = arguments,
										n = 0,
										i = t.length,
										o = !1;
									do {
										e = t[n] + "", -1 === c(this, e) && (this.push(e), o = !0)
									} while (++n < i);
									o && this._updateClassName()
								}, d.remove = function() {
									var e, t, n = arguments,
										i = 0,
										o = n.length,
										r = !1;
									do {
										for (e = n[i] + "", t = c(this, e); - 1 !== t;) this.splice(t, 1), r = !0, t = c(this, e)
									} while (++i < o);
									r && this._updateClassName()
								}, d.toggle = function(e, t) {
									e += "";
									var n = this.contains(e),
										i = n ? !0 !== t && "remove" : !1 !== t && "add";
									return i && this[i](e), !0 === t || !1 === t ? t : !n
								}, d.toString = function() {
									return this.join(" ")
								}, r.defineProperty) {
								var p = {
									get: f,
									enumerable: !0,
									configurable: !0
								};
								try {
									r.defineProperty(o, "classList", p)
								} catch (e) {
									-2146823252 === e.number && (p.enumerable = !1, r.defineProperty(o, "classList", p))
								}
							} else r.prototype.__defineGetter__ && o.__defineGetter__("classList", f)
						}
				}("undefined" != typeof window ? window : {}),
				function() {
					for (var e = 0, t = ["ms", "moz", "webkit", "o"], n = 0; n < t.length && !window.requestAnimationFrame; ++n) window.requestAnimationFrame = window[t[n] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[t[n] + "CancelAnimationFrame"] || window[t[n] + "CancelRequestAnimationFrame"];
					window.requestAnimationFrame || (window.requestAnimationFrame = function(t, n) {
						var i = (new Date).getTime();
						var o = Math.max(0, 16 - (i - e));
						return e = i + o, window.setTimeout(function() {
							t(i + o)
						}, o)
					}), window.cancelAnimationFrame || (window.cancelAnimationFrame = function(e) {
						clearTimeout(e)
					})
				}()
			}, {}],
			3: [function(e, t, n) {
				var i, o = e("focusable"),
					r = {
						TICK_MULTIPLIER: 1 / Math.cos(Math.PI / 4),
						DEFAULT_ANIMATION_DURATION: 200,
						DEFAULT_POPUP_DELAY: 2e3,
						MAX_PROMOTION_LENGTH: 100,
						MAX_NUM_GAMES_PER_ROW: 8,
						MARGIN_BETWEEN_GAMES: 20,
						KEY_PROMOTIONS_READ: "NavbarPromotionsRead",
						DATA_PROMOTION_ID: "data-promotion-id",
						EXTERNAL_EVENTS: {
							CLOSE_ALL_MENUS: "navbarCloseAllMenus",
							UPDATE_LOGIN_URL: "updateLoginUrl",
							ADD_FOOTER_LINKS: "navbarAddFooterLinks",
							UPDATE_LOCALE_SELECTOR_URLS: "navbarUpdateLocaleSelectorUrls",
							UPDATE_USER_INFO: "navbarUpdateUserInfo",
							UPDATE_MAIN_CONTENT_SKIP_LINK: "navbarUpdateMainContentId"
						},
						MODE_SIMPLE: "simple",
						MODE_COMPACT: "compact",
						MODE_DEFAULT: "default",
						WINDOW_LOAD_EVENT: "load",
						DURATION_LOAD_DELAY: 500,
						viewportWidth: 0,
						viewportWidthFooter: 0,
						loadTimeoutId: null,
						lastUpdateTimestamp: 0,
						lastFooterUpdateTimestamp: 0,
						getCurrentMode: function() {
							var e = document.querySelector(".Navbar");
							return e ? e.classList.contains("is-compact") ? r.MODE_COMPACT : e.classList.contains("is-simple") ? r.MODE_SIMPLE : r.MODE_DEFAULT : "default"
						},
						calcViewportWidth: function() {
							return Math.max(document.documentElement.clientWidth, window.innerWidth || 0)
						},
						init: function(e) {
							if (r.setupExternalEventListeners(e), !e.classList.contains("is-disabled")) {
								e.addEventListener("click", r.rootClickHandler.bind(e)), r.keyboardMode(e), r.forEach(e.querySelectorAll(".Navbar-overlay"), function(t) {
									t.addEventListener("click", r.closeModals.bind(e))
								}), window.addEventListener("resize", r.resize.bind(e)), r.forEach(e.getElementsByClassName("Navbar-modalClose"), function(t) {
									var n = function(n) {
										r.closeModalButtonPressed(n, t, e)
									};
									t.addEventListener("keyup", n), t.addEventListener("mousedown", n)
								}), r.forEach(e.querySelectorAll(".Navbar-modalToggle"), function(t) {
									var n = r.toggleModal.bind({
										root: e,
										toggle: t
									});
									t.addEventListener("keyup", n), t.addEventListener("click", n)
								});
								var t = e.querySelector("#skip-link-container");
								t && t.children && (t.addEventListener("keydown", r.skipLinkHandler), t.addEventListener("click", r.skipLinkHandler)), r.forEach(e.querySelectorAll(".Navbar-promotion"), function(e) {
									r.trapFocus(e)
								}), r.forEach(e.querySelectorAll(".Navbar-modal"), function(e) {
									r.trapFocus(e), e.classList.contains("is-animated") && (e.addEventListener("animationend", r.setModalDisplayStateAfterAnimation.bind(e)), e.addEventListener("transitionend", r.setModalDisplayStateAfterAnimation.bind(e)))
								}), r.forEach(e.querySelectorAll(".Navbar-expandable"), function(t) {
									var n = t.querySelector(".Navbar-expandableToggle"),
										i = function(n) {
											r.toggleExpandable.call(e, t, n)
										};
									t.addEventListener("keyup", i), n.addEventListener("click", i)
								}), e.hasAttribute("data-ajax") && r.authenticate(e), setTimeout(function() {
									r.checkPromotions.call(r, e)
								}, r.DEFAULT_POPUP_DELAY), e.classList.contains("is-authenticated") && (e.getAttribute("data-notification-count") ? r.setSupportNotificationCount.call(r, e, {
									total: parseInt(e.getAttribute("data-notification-count"))
								}) : r.checkSupportNotifications(e));
								var n = e.getAttribute("data-current-site");
								if (n) {
									var i = e.querySelector('.Navbar-desktop .Navbar-item[data-name="' + n + '"]');
									i && i.classList.add("is-current")
								}
								var o = navigator.userAgent.toLowerCase();
								(o.indexOf("iphone") >= 0 || o.indexOf("ipad") >= 0) && (e.addEventListener("touchmove", r.touchMoveHandler), e.addEventListener("touchend", r.touchEndHandler), r.forEach(e.querySelectorAll(".Navbar-accountModal .Navbar-modalContent, .Navbar-siteMenu .Navbar-modalContent"), function(e) {
									r.forEach(e.querySelectorAll("a, .Navbar-expandableToggle"), function(e) {
										e.addEventListener("click", r.touchClickHandler)
									})
								}))
							}
						},
						initFooter: function(e) {
							if (e.querySelector(".NavbarFooter-selector")) {
								r.keyboardMode(e);
								var t = e.querySelector(".NavbarFooter-selectorToggle");
								t && (t.addEventListener("click", function(t) {
									r.toggleLocaleSelector.call(e, t)
								}), t.addEventListener("keydown", function(t) {
									r.toggleLocaleSelector.call(e, t)
								})), r.forEach(e.querySelectorAll(".NavbarFooter-selectorSection"), function(e) {
									r.trapFocus(e)
								}), r.forEach(e.getElementsByClassName("Navbar-modalClose"), function(t) {
									var n = function(n) {
										r.closeModalButtonPressed(n, t, e)
									};
									t.addEventListener("keyup", n), t.addEventListener("mousedown", n)
								});
								var n = e.querySelector(".NavbarFooter-selectorCloserAnchor");
								n && n.addEventListener("click", r.closeLocaleSelector.bind(e));
								var i = e.querySelector(".NavbarFooter-overlay");
								i && i.addEventListener("click", r.closeLocaleSelector.bind(e)), window.addEventListener("resize", r.resizeFooter.bind(e)), (e.classList.contains("is-region-limited") || e.classList.contains("is-region-hybrid")) && r.forEach(e.querySelectorAll(".NavbarFooter-selectorRegion:not(.is-external)"), function(t) {
									t.addEventListener("click", r.changeFooterRegionLimit.bind(e, t)), t.addEventListener("keydown", r.changeFooterRegionLimit.bind(e, t))
								})
							}
							r.getAdministrativeDivision(e), r.getLegal(e)
						},
						checkValidResize: function() {
							var e = document.activeElement || {
								tagName: "",
								type: ""
							};
							return !/textarea/i.test(e.tagName) && (!/input/i.test(e.tagName) || !(/text/i.test(e.type) || /password/i.test(e.type) || /search/i.test(e.type) || /email/i.test(e.type) || /number/i.test(e.type)))
						},
						updateNavbar: function(e, t) {
							if (t > r.lastUpdateTimestamp) {
								r.lastUpdateTimestamp = t;
								var n = r.calcViewportWidth();
								if (n === r.viewportWidth) return;
								r.viewportWidth = n, r.checkValidResize() && e && e.classList.contains("is-focused") && r.closeModals.call(e), r.testForOverlappingElementsAndSwitchToCollapsed()
							}
						},
						resize: function() {
							var e = this;
							requestAnimationFrame(function(t) {
								r.updateNavbar(e, t)
							})
						},
						setupExternalEventListeners: function(e) {
							for (var t in r.EXTERNAL_EVENTS) window.addEventListener(r.EXTERNAL_EVENTS[t], r.handleExternalEvent.bind(e))
						},
						handleExternalEvent: function(e) {
							switch (e.type) {
								case r.EXTERNAL_EVENTS.CLOSE_ALL_MENUS:
									r.closeModals.call(this);
									break;
								case r.EXTERNAL_EVENTS.UPDATE_LOGIN_URL:
									r.updateLoginUrl.call(this, e);
									break;
								case r.EXTERNAL_EVENTS.ADD_FOOTER_LINKS:
									r.addFooterLinks.call(this, e.detail);
									break;
								case r.EXTERNAL_EVENTS.UPDATE_LOCALE_SELECTOR_URLS:
									r.updateLocaleSelectorUrls.call(this, e.detail);
									break;
								case r.EXTERNAL_EVENTS.UPDATE_USER_INFO:
									r.updateUserInfo.call(this, e.detail);
									break;
								case r.EXTERNAL_EVENTS.UPDATE_MAIN_CONTENT_SKIP_LINK:
									r.updateMainContentId.call(this, e.detail)
							}
						},
						testForOverlappingElementsAndSwitchToCollapsed: function() {
							var e = document.querySelector(".Navbar-desktop .Navbar-items");
							if (e && 0 != e.offsetHeight) {
								var t = document.querySelector(".Navbar-collapsedItems");
								t && (r.useCollapsedDesktop(e) ? (e.classList.add("is-invisible"), r.forEach(e.children, function(e) {
									if (!e.hasAttribute("tabindex")) return !1;
									e.setAttribute("tabindex", "-1")
								}), t.classList.remove("is-hidden")) : (e.classList.remove("is-invisible"), r.forEach(e.children, function(e) {
									if (!e.hasAttribute("tabindex")) return !1;
									e.setAttribute("tabindex", "0")
								}), t.classList.add("is-hidden")))
							}
						},
						useCollapsedDesktop: function(e) {
							var t = document.querySelector(".Navbar-desktop .Navbar-profileItems").getBoundingClientRect(),
								n = e.getBoundingClientRect(),
								i = r.calcViewportWidth();
							return n.right + (i - t.left) >= i
						},
						rootClickHandler: function() {
							var e = this.querySelector(".Navbar-promotion.is-open");
							e && r.dismissPromotion.call(e)
						},
						touchMoving: !1,
						touchMoveHandler: function() {
							r.touchMoving = !0
						},
						touchEndHandler: function() {
							r.touchMoving = !1
						},
						touchClickHandler: function(e) {
							if (r.touchMoving) return e.stopPropagation(), e.preventDefault(), !1
						},
						toggleModal: function(e) {
							if (r.isNotEnterPressOrMouseClick(e)) return !1;
							var t = this.toggle,
								n = t ? t.getAttribute("data-target") : null,
								i = t ? t.getAttribute("data-site-mode") : null,
								o = r.getCurrentMode(),
								a = !1;
							return r.forEach(this.root.querySelectorAll(".Navbar-modal"), function(t) {
								var s = this.toggle,
									l = !i || t.getAttribute("data-" + o + "-mode");
								if ((t === this.target || t.classList.contains(n)) && l) {
									if (r.isOpen(t)) r.close(t), t.classList.contains("is-scroll-blocking") && r.unblockScrolling(), s && (s.classList.remove("is-active"), s.setAttribute("aria-expanded", !1));
									else {
										r.open(t), t.classList.contains("is-scroll-blocking") && r.blockScrolling(), s && (s.classList.add("is-active"), s.setAttribute("aria-expanded", !0));
										var c = t.querySelector(".Navbar-tick");
										if (c) {
											c.style.left = "";
											var u = s.querySelector(".Navbar-dropdownIcon");
											u && 0 !== u.offsetLeft || (u = s.querySelector(".Navbar-label")), u && 0 !== u.offsetLeft || (u = s);
											var d = r.setTickOffset(u, c);
											if (!t.classList.contains("is-constrained")) {
												var f = t.offsetWidth / 2,
													p = d > f ? d - f : f - d,
													h = t.offsetHeight / f,
													m = Math.atan(h),
													g = f / Math.cos(m);
												c.querySelector(".Navbar-tickInner").style.opacity = p / g
											}
										}
										a = !0
									}
									var v = r.getFocusableElements(t)[0],
										y = ("keyup" === e.type || "keydown" === e.type) && "Enter" === e.key;
									v && y && v.focus()
								} else r.close(t), r.forEach(this.root.querySelectorAll('.Navbar-modalToggle[data-name="' + t.getAttribute("data-toggle") + '"]'), function(e) {
									e.classList.remove("is-active")
								})
							}.bind(this)), r.forEach(this.root.querySelectorAll(".Navbar-item"), function(e) {
								a ? e.getAttribute("data-target") === n ? e.classList.remove("is-faded") : e.classList.add("is-faded") : e.classList.remove("is-faded")
							}.bind(this)), this.root.classList.toggle("is-focused", a), r.rootClickHandler.call(this.root), r.toggleExpandable.call(this.root), e.stopPropagation(), e.preventDefault(), !1
						},
						closeModals: function() {
							r.forEach((this || document).querySelectorAll(".Navbar .Navbar-item"), function(e) {
								e.classList.remove("is-active"), e.classList.remove("is-faded")
							}), r.forEach(document.querySelectorAll(".Navbar-modalToggle"), function(e) {
								e.setAttribute("aria-expanded", !1)
							}), r.forEach((this || document).querySelectorAll(".Navbar .Navbar-modal.is-open"), function(e) {
								r.close(e)
							}), this && this.classList ? this.classList.remove("is-focused") : r.forEach(document.querySelectorAll(".Navbar"), function(e) {
								e.classList.remove("is-focused")
							}), this && r.toggleExpandable.call(this), r.unblockScrolling()
						},
						updateLoginUrl: function(e) {
							r.forEach((this || document).querySelectorAll("div.Navbar-accountDropdownLoggedOut > div > a"), function(t) {
								t.href = e.detail
							})
						},
						addFooterLinks: function(e) {
							e = e || {};
							var t = document.querySelector(".NavbarFooter-linksRight");
							r.forEach(e.primary, function(e) {
								if (e.text && e.href && t) {
									var n = function(e) {
										var t = i(e);
										return t.classList.add("NavbarFooter-mainLink"), t
									}(e);
									t.appendChild(n)
								}
							});
							var n = document.querySelector(".NavbarFooter-links.NavbarFooter-subLinks");

							function i(e) {
								var t = document.createElement("div");
								t.classList.add("NavbarFooter-link");
								var n = document.createElement("a");
								n.classList.add("NavbarFooter-anchor"), n.href = e.href;
								var i = e.attributes || {};
								Object.keys(i).forEach(function(e) {
									n.setAttribute(e, i[e])
								});
								var o = document.createTextNode(e.text);
								return n.appendChild(o), t.appendChild(n), t
							}
							r.forEach(e.secondary, function(e) {
								if (e.text && e.href && n) {
									var t = function(e) {
										var t = i(e);
										return t.classList.add("NavbarFooter-subLink"), t.setAttribute("role", "presentation"), t
									}(e);
									n.appendChild(t)
								}
							})
						},
						updateLocaleSelectorUrls: function(e) {
							var t = document.querySelectorAll(".NavbarFooter-selectorLocale");
							r.forEach(t, function(t) {
								e.hasOwnProperty(t.dataset.id) && (t.href = e[t.dataset.id])
							})
						},
						updateUserInfo: function(e) {
							if (e && e.battletag) {
								var t = document.querySelectorAll(".Navbar");
								r.forEach(t, function(t) {
									r.checkDisabled(t) || r.displayUserInfo(t, e)
								})
							}
						},
						isOpen: function(e) {
							return e.classList.contains("is-open")
						},
						open: function(e) {
							e.classList.add("is-open")
						},
						close: function(e) {
							e.classList.remove("is-open")
						},
						blockScrolling: function() {
							document.body.classList.add("Navbar-blockScrolling")
						},
						unblockScrolling: function() {
							document.body.classList.remove("Navbar-blockScrolling")
						},
						setModalDisplayStateAfterAnimation: function(e) {
							return r.isOpen(this) ? r.showModal(this) : r.hideModal(this), e.stopPropagation(), e.preventDefault(), !1
						},
						showModal: function(e) {
							e.classList.add("is-displayed")
						},
						hideModal: function(e) {
							e.classList.remove("is-displayed")
						},
						toggleExpandable: function(e, t) {
							if (r.isNotEnterPressOrMouseClick(t)) return !1;
							r.forEach(this.querySelectorAll(".Navbar-expandable"), function(t) {
								var n = t.querySelector(".Navbar-expandableContainer");
								if (t != e || r.isOpen(t)) n.style.height = "0px", t.NavbarAnimationTimeout = setTimeout(function() {
									r.close(t), t.setAttribute("aria-expanded", !1)
								}.bind(t), r.DEFAULT_ANIMATION_DURATION);
								else {
									t.NavbarAnimationTimeout && clearTimeout(t.NavbarAnimationTimeout), n.style.height = "0px", r.open(t), t.setAttribute("aria-expanded", !0);
									var i = t.querySelector(".Navbar-expandableContent");
									n.style.height = i.offsetHeight + "px"
								}
							})
						},
						checkDisabled: function(e) {
							return e && e.classList && e.classList.contains("is-disabled")
						},
						checkPromotionId: function(e) {
							return !!localStorage && !!(localStorage.getItem(r.KEY_PROMOTIONS_READ) ? JSON.parse(localStorage.getItem(r.KEY_PROMOTIONS_READ)) : {})[e]
						},
						savePromotionId: function(e) {
							if (localStorage) {
								var t = localStorage.getItem(r.KEY_PROMOTIONS_READ) ? JSON.parse(localStorage.getItem(r.KEY_PROMOTIONS_READ)) : {};
								t[e] = !0, localStorage.setItem(r.KEY_PROMOTIONS_READ, JSON.stringify(t))
							}
						},
						checkPromotions: function(e) {
							if (!r.checkDisabled(e)) {
								var t = e.getAttribute("data-notification-url");
								r.get(t, function(t) {
									if (t && !r.checkDisabled(e)) {
										var n = {};
										try {
											var i = (n = JSON.parse(t)).notifications || n.notificationsList;
											if (n.totalNotifications && i)
												for (var o in i) {
													var a = i[o];
													if (!r.checkPromotionId(a.id)) {
														var s = e.querySelector(".Navbar-promotion");
														r.showPromotion(s, a.id, a.img ? a.img.url : null, a.title, a.content, a.httpLink ? a.httpLink.content : "", a.httpLink ? a.httpLink.link : ""), s.querySelector(".Navbar-promotionLink").addEventListener("click", r.setPromotionAsRead.bind(s)), s.querySelector(".Navbar-toastClose").addEventListener("click", r.dismissPromotion.bind(s, !0)), s.querySelector(".Navbar-toastClose").addEventListener("keyup", r.dismissPromotion.bind(s, !0)), r.focusAnchor = document.activeElement, s.querySelector("#Navbar-promotionContent").focus();
														break
													}
												}
										} catch (e) {
											console.error(e)
										}
									}
								}, function(e) {
									console.error("Couldn't retrieve notification count", e)
								})
							}
						},
						focusAnchor: null,
						showPromotion: function(e, t, n, i, o, a, s) {
							if (t && e.setAttribute(r.DATA_PROMOTION_ID, t), n && (e.querySelector(".Navbar-promotionImage").src = n), i && (e.querySelector(".Navbar-promotionLabel").innerHTML = i), o && "string" == typeof o && (o = o.trim(), e.querySelector(".Navbar-promotionText").innerHTML = o), a && (e.querySelector(".Navbar-promotionLink").innerHTML = a), s) {
								var l = e.querySelector(".Navbar-promotionLink");
								l.href = s, e.addEventListener("click", r.promotionClickHandler), l.addEventListener("click", r.promotionLinkClickHandler.bind(e))
							}
							e.classList.add("is-open"), e.addEventListener("click", r.promotionClickHandler);
							var c = e.querySelector(".Navbar-promotionLabel").innerHTML;
							r.pushGlobalNotificationAnalyticsEvent("Open - Automatic", t, c)
						},
						dismissPromotion: function(e, t) {
							if (r.isNotEnterPressOrMouseClick(t)) return !1;
							var n = r.hideToast.bind(this);
							this.hideToast = n, this.addEventListener("animationend", n), this.classList.add("is-dismissed");
							var i = parseInt(this.getAttribute(r.DATA_PROMOTION_ID)),
								o = this.querySelector(".Navbar-promotionLabel").innerHTML;
							e && (r.setPromotionAsRead.call(this), t.stopPropagation(), t.preventDefault()), r.pushGlobalNotificationAnalyticsEvent(e ? "Close - X" : "Close - Background", i, o), r.focusAnchor.focus()
						},
						setPromotionAsRead: function() {
							var e = parseInt(this.getAttribute(r.DATA_PROMOTION_ID));
							r.savePromotionId(e)
						},
						hideToast: function() {
							this.hideToast && this.removeEventListener("animationend", this.hideToast), this.classList.remove("is-dismissed"), this.classList.remove("is-open")
						},
						promotionClickHandler: function(e) {
							return e.stopPropagation(), !1
						},
						promotionLinkClickHandler: function() {
							var e = parseInt(this.getAttribute(r.DATA_PROMOTION_ID)),
								t = this.querySelector(".Navbar-promotionLabel").innerHTML;
							try {
								r.pushGlobalNotificationAnalyticsEvent("Click - Button", e, t)
							} catch (e) {
								console.error(e)
							}
							return !0
						},
						checkSupportNotifications: function(e) {
							var t = e.getAttribute("data-support-url"),
								n = "NavbarSupportTicketCallback" + (new Date).getTime() + "_" + Math.round(1e5 * Math.random());
							window[n] = r.setSupportNotificationCount.bind(r, e);
							var i = document.createElement("script");
							i.src = t + "window." + n, document.getElementsByTagName("head")[0].appendChild(i)
						},
						setSupportNotificationCount: function(e, t) {
							var n = t && t.total ? t.total : 0;
							n && n > 0 ? (this.forEach(e.querySelectorAll(".Navbar-supportCounter, .Navbar-accountDropdownSupport .Navbar-accountDropdownCounter"), function(e) {
								e.innerHTML = "" + n
							}), e.classList.add("is-support-active")) : (e.classList.remove("is-support-active"), this.forEach(e.querySelectorAll(".Navbar-supportCounter, .Navbar-accountDropdownSupport .Navbar-accountDropdownCounter"), function(e) {
								e.innerHTML = "0"
							}))
						},
						forEach: function(e, t) {
							if (e && e.length && "function" == typeof t)
								for (var n = 0; n < e.length; n++) t(e[n], n, e)
						},
						request: function(e, t, n, i) {
							var o = new XMLHttpRequest;
							o.open(e, t), o.onreadystatechange = function(e, t) {
								4 === this.readyState && (200 === this.status ? e(this.responseText) : t(this.status))
							}.bind(o, n, i), o.send()
						},
						get: function(e, t, n) {
							return r.request("GET", e, t, n)
						},
						authenticate: function(e) {
							var t = e.getAttribute("data-auth-url");
							r.get(t, function(t) {
								if (t) {
									var n = {};
									try {
										n = JSON.parse(t), r.displayUserInfo(e, n)
									} catch (e) {
										console.error(e)
									}
								}
							}, function(e) {
								console.error("Couldn't verify user", e)
							})
						},
						displayUserInfo: function(e, t) {
							if ((e = e || document.querySelector(".Navbar")) && t) {
								var n = "",
									i = "",
									o = "",
									a = (t.email || "").toLowerCase();
								if (t.account && t.account.battleTag) n = i = t.account.battleTag.name || i, (o = t.account.battleTag.code || o) && "#" !== o.charAt(0) && (o = "#" + o);
								else if (t.battletag) {
									var s = t.battletag.split("#");
									n = i = s[0] || i, (o = s[1] || o) && "#" !== o.charAt(0) && (o = "#" + o)
								} else a && (n = a.length > 12 ? a.substring(0, 12) : a);
								e.classList.add("is-authenticated"), t.flags && t.flags.employee && e.classList.add("is-employee"), r.forEach(e.querySelectorAll(".Navbar-accountAuthenticated"), function(e) {
									e.innerHTML = n
								}), r.forEach(e.querySelectorAll(".Navbar-accountDropdownLoggedIn"), function(e) {
									e.querySelector(".Navbar-accountDropdownBattleTag").innerHTML = i, e.querySelector(".Navbar-accountDropdownBattleTagNumber").innerHTML = o, e.querySelector(".Navbar-accountDropdownEmail").innerHTML = a
								}), r.checkSupportNotifications(e)
							}
						},
						getAdministrativeDivision: function(e) {
							var t = e.getAttribute("data-geoip-service-url") || "http://127.0.0.1";

							function n(t, n) {
								e.setAttribute("data-country", t), e.setAttribute("data-administrative-division", n)
							}

							function i() {
								n("US", "CA")
							}
							r.get(t, function(e) {
								"string" == typeof e && (e = JSON.parse(e)), "object" == typeof e && e.country && e.subdivision ? n(e.country, e.subdivision) : i()
							}, i)
						},
						getLegal: function(e) {
							var t = (e || document).querySelector(".NavbarFooter-legal"),
								n = e.getAttribute("data-locale"),
								i = t.getAttribute("data-country"),
								o = t.getAttribute("data-legal-id"),
								a = t.getAttribute("data-sub-title-id"),
								s = "true" == t.getAttribute("data-disable-legal"),
								l = "true" == t.getAttribute("data-disable-additional"),
								c = t.getAttribute("data-legal-url"),
								u = c.indexOf("?"),
								d = ~u ? u : c.length;
							c = c.substring(0, d) + "?titleId={titleId}&countryCode={countryCode}&locale={locale}".replace(/{locale}/g, n).replace("{titleId}", o).replace("{countryCode}", i), a && (c += "&subtitleId=" + a);
							r.get(c, function(e) {
								if (e) try {
									r.generateLegal(t, JSON.parse(e), s, l)
								} catch (e) {
									console.error(e)
								}
							}, function(e) {
								console.error("Couldn't retrieve legal data", e)
							})
						},
						generateLegal: function(e, t, n, i) {
							if (t.success) {
								if (!i && t.additional && t.additional.length) e.innerHTML = t.additional.join("");
								else
									for (var o = e.children, a = 0; a < o.length; a++) {
										var s = o[a];
										s.classList.contains("NavbarFooter-customLegal") || e.removeChild(s)
									}
								if (!n) {
									t.ratings.items = t.ratings.items.map(function(e) {
										var t = [];
										return e.ratingContentGroups = e.ratingContentGroups.sort(function(e, t) {
											return e.position - t.position
										}).filter(function(e) {
											return e.ratingContents.length > 0
										}).map(function(n, i, o) {
											return "ESRB" === e.ratingBoardName && (n.ratingContents.sort(function(e, t) {
												return e.position - t.position
											}), t = t.concat(n.ratingContents), n.ratingContents = [], i !== o.length - 1 ? t.push({
												hr: !0
											}) : n.ratingContents = n.ratingContents.concat(t)), n
										}), e
									});
									var l = function(e) {
											return null !== e && void 0 !== e ? " " + e : ""
										},
										c = function(e, t, n) {
											var i = document.createElement(e);
											if (t)
												for (var o = Object.keys(t), a = 0; a < o.length; a++) {
													var s = o[a],
														l = t[s];
													l && i.setAttribute(s, l)
												}
											return r.forEach(n, function(e) {
												i.append(e)
											}), i
										},
										u = c("div", {
											class: "NavbarFooter-legalRatings",
											role: "presentation"
										});
									r.forEach(t.ratings.items, function(e) {
										var t = c("div", {
												class: "NavbarFooter-legalRatingDescriptorsWrapper",
												role: "presentation",
												id: "NavbarFooter-legalRatingDescriptorsWrapper"
											}),
											n = c("img", {
												class: "NavbarFooter-legalRatingDetailImage",
												src: e.ratingImageUrl,
												alt: e.ratingBoardName + l(e.localizedDescription)
											}),
											i = c("a", {
												class: "NavbarFooter-legalLink",
												href: e.referenceUrl,
												title: e.ratingBoardName + l(e.localizedDescription),
												"aria-labelledby": "NavbarFooter-aria-name NavbarFooter-legalRatingDescriptorsWrapper"
											}, [n]);
										e.ratingContentGroups.length > 0 && r.forEach(e.ratingContentGroups, function(e) {
											r.forEach(e.ratingContents, function(e) {
												if (e.imageUrl) {
													var n = c("img", {
															class: "NavbarFooter-legalRatingDetailImage",
															src: e.imageUrl,
															alt: l(e.localizedName)
														}),
														i = c("a", {
															class: "NavbarFooter-legalLink",
															title: l(e.localizedDescription)
														}, [n]);
													t.appendChild(i)
												} else if (e.hr) {
													var o = c("hr", {
														class: "NavbarFooter-esrbHR"
													});
													t.appendChild(o)
												} else {
													var r = c("div", {
														class: "NavbarFooter-esrbDescriptor",
														title: e.localizedDescription,
														"aria-label": e.localizedDescription
													}, [document.createTextNode(e.localizedName)]);
													t.appendChild(r)
												}
											})
										});
										var o = [i];
										if (e.ratingContentGroups.length > 0 && o.push(t), u.appendChild(c("div", {
												class: "NavbarFooter-legalRatingWrapper",
												role: "presentation"
											}, o)), e.localizedName) {
											var a = c("a", {
												class: "is-ariaInvisible",
												id: "NavbarFooter-aria-name",
												"aria-hidden": "true"
											}, [document.createTextNode(e.localizedName)]);
											u.appendChild(a)
										}
										if (e.customImageUrl) {
											var s = c("a", {
												class: "NavbarFooter-legalLink",
												title: e.ratingBoardName + l(e.localizedDescription)
											}, [c("img", {
												class: "NavbarFooter-legalRatingDetailImage",
												src: e.customImageUrl,
												alt: e.ratingBoardName + l(e.localizedDescription)
											})]);
											u.append(s)
										}
									}), e.appendChild(u)
								}
							}
						},
						setTickOffset: function(e, t) {
							t.style.left = "";
							var n = e.offsetWidth / 2 + e.getBoundingClientRect().left - t.getBoundingClientRect().left - r.TICK_MULTIPLIER * t.offsetWidth / 2;
							return t.style.left = n + "px", n
						},
						setVerticalTickOffset: function(e, t) {
							t.style.top = "";
							var n = t.offsetHeight + e.getBoundingClientRect().top - t.getBoundingClientRect().top - r.TICK_MULTIPLIER * t.offsetHeight / 2;
							return t.style.top = n + "px", n
						},
						toggleLocaleSelector: function(e) {
							if (r.isNotEnterPressOrMouseClick(e)) return !1;
							this.querySelector(".NavbarFooter-selector").classList.contains("is-open") ? r.closeLocaleSelector.call(this) : r.openLocaleSelector.call(this);
							var t = r.getFocusableElements(".NavbarFooter-selectorDropdownContainer")[0];
							return t && t.focus(), e.stopPropagation(), e.preventDefault(), !1
						},
						openLocaleSelector: function() {
							this.classList.add("is-focused"), this.querySelector(".NavbarFooter-selector").classList.add("is-open");
							var e = this.querySelector(".NavbarFooter-selectorToggleArrow"),
								t = this.querySelector(".NavbarFooter-selectorTick");
							r.setTickOffset(e, t), (this.classList.contains("is-region-limited") || this.classList.contains("is-region-hybrid")) && r.changeFooterRegionLimit.call(this, this.querySelector(".NavbarFooter-selectorRegion.is-active"));
							var n = document.querySelector(".Navbar-promotion.is-open");
							n && r.dismissPromotion.call(n, !1), r.blockScrolling()
						},
						closeLocaleSelector: function() {
							this.classList.remove("is-focused");
							var e = this.querySelector(".NavbarFooter-selector");
							e && e.classList.remove("is-open"), r.unblockScrolling()
						},
						updateFooter: function(e) {
							if (e > r.lastFooterUpdateTimestamp) {
								r.lastFooterUpdateTimestamp = e;
								var t = r.calcViewportWidth();
								if (t === r.viewportWidthFooter) return;
								r.viewportWidthFooter = t, this && this.classList.contains("is-focused") && r.closeLocaleSelector.call(this)
							}
						},
						resizeFooter: function() {
							var e = this;
							requestAnimationFrame(function(t) {
								r.updateFooter.call(e, t)
							})
						},
						changeFooterRegionLimit: function(e) {
							var t = e.getAttribute("data-id");
							if (r.isNotEnterPressOrMouseClick(event)) return !1;
							r.forEach(this.querySelectorAll(".NavbarFooter-selectorSectionPage.is-open:not([data-region='" + t + "'])"), function(e) {
								e.classList.remove("is-open")
							});
							var n = this.querySelector(".NavbarFooter-selectorSectionPage[data-region='" + t + "']");
							n.classList.add("is-open"), n.querySelectorAll("a")[0].focus(), r.forEach(this.querySelectorAll(".NavbarFooter-selectorRegion.is-selected:not([data-id='" + t + "'])"), function(e) {
								e.classList.remove("is-selected")
							}), e.classList.add("is-selected");
							var i = this.querySelector(".NavbarFooter-selectorRegionTick"),
								o = r.setVerticalTickOffset(e, i);
							i.querySelector(".NavbarFooter-selectorRegionTickOverlay").style.opacity = o / this.querySelector(".NavbarFooter-selectorRegions").offsetHeight, event.preventDefault()
						},
						getLocalDomainName: function() {
							var e = window.location.href;
							return (e.indexOf("://") > -1 ? e.split("/")[2] : e.split("/")[0]).split(":")[0]
						},
						pushAnalyticsEvent: function(e) {
							window.dataLayer || (window.dataLayer = []), window.dataLayer.push(e)
						},
						pushGlobalNotificationAnalyticsEvent: function(e, t, n) {
							r.pushAnalyticsEvent({
								event: "globalNotification",
								analytics: {
									eventPlacement: e,
									eventPanel: "id:" + t + " || " + n
								}
							})
						},
						loadHandler: function() {
							r.testForOverlappingElementsAndSwitchToCollapsed(), r.loadTimeoutId && (clearTimeout(r.loadTimeoutId), r.loadTimeoutId = null)
						},
						trapFocus: function(e) {
							e.addEventListener("keydown", function(t) {
								switch (t.key) {
									case "Tab":
										break;
									case "Esc":
									case "Escape":
										var n = e.querySelectorAll(".Navbar-modalClose")[0],
											i = document.createEvent("Event");
										i.key = "Enter", i.initEvent("keyup", !0, !1), n.dispatchEvent(i);
									default:
										return
								}
								var o = r.getFocusableElements(e),
									a = o[0],
									s = o[o.length - 1];
								t.shiftKey && document.activeElement === a ? (s.focus(), t.preventDefault()) : t.shiftKey || document.activeElement !== s || (a.focus(), t.preventDefault())
							})
						},
						getFocusableElements: function(e) {
							for (var t = [], n = "string" == typeof e ? document.querySelectorAll(e)[0].querySelectorAll(o) : e.querySelectorAll(o), i = 0; i < n.length; i++) {
								var r = n[i];
								r.offsetParent && t.push(r)
							}
							return t
						},
						isNotEnterPressOrMouseClick: function(e) {
							if (e) {
								var t = ("keyup" === e.type || "keydown" === e.type) && "Enter" === e.key,
									n = "click" === e.type || "mousedown" === e.type;
								if (!t && !n) return !0
							}
							return !1
						},
						closeModalButtonPressed: function(e, t, n) {
							var i = t.attributes["data-target"];
							if (r.isNotEnterPressOrMouseClick(e) || !i) return !1;
							var o = document.querySelectorAll(i.textContent)[0];
							r.closeModals.call(n), r.closeLocaleSelector.call(n), o.focus()
						},
						skipLinkHandler: function() {
							if ("Enter" === event.key || "click" === event.type) {
								event.preventDefault();
								var e = event.target.id,
									t = event.target.href.split("#")[1],
									n = document.querySelector("#" + t);
								n && n.getAttribute("tabindex") ? n.focus() : n && (n.tabIndex = n.tabIndex, n.focus(), n.removeAttribute("tabindex")), r.pushAnalyticsEvent({
									event: "skipLink",
									analytics: {
										eventPlacement: "Click - Skip Link",
										eventPanel: "id:" + e + " || target: " + t
									}
								})
							}
						},
						keyboardMode: function(e) {
							e.addEventListener("mousedown", function() {
								this.classList.remove("keyboardMode")
							}), e.addEventListener("keyup", function() {
								this.classList.add("keyboardMode")
							})
						},
						updateMainContentId: function(e) {
							e && (document.getElementById("main-skip-link").href = "#" + e.id)
						}
					};
				i = [], r.forEach(document.querySelectorAll(".Navbar"), function(e) {
					r.init(e), i.push(e)
				}), r.forEach(document.querySelectorAll(".NavbarFooter"), function(e) {
					r.initFooter(e)
				}), document.addEventListener("DOMContentLoaded", function(e) {
					r.forEach(i, r.updateNavbar), r.loadTimeoutId = setTimeout(r.loadHandler, r.DURATION_LOAD_DELAY)
				}), window.addEventListener(r.WINDOW_LOAD_EVENT, r.loadHandler), t && (t.exports = r)
			}, {
				focusable: 1
			}]
		}, {}, [2, 3])(3)
	});
var Accordion = {
	getRootElement: function(e) {
		return $(e).closest(".Accordion")
	},
	getItemElements: function(e) {
		return e.find(".AccordionItem")
	},
	update: function(e) {
		var t = $(e.target).closest(".AccordionItem"),
			n = Accordion.getRootElement(e.target),
			i = n.attr("data-exclusive-above") || "";
		if (!i || UI.isAboveBreakpoint(UI.BREAKPOINTS[i.toUpperCase()])) {
			var o = n.attr("data-exclusive-below") || "";
			o && !UI.isBelowBreakpoint(UI.BREAKPOINTS[o.toUpperCase()]) || t.hasClass("is-open") && Accordion.closeAllBut(n, t)
		}
	},
	closeAllBut: function(e, t) {
		Accordion.getItemElements(e).each(function(e, n) {
			var i = $(n);
			i.is(t) || Expandable.close(i)
		})
	},
	afterInit: function(e) {
		(e ? $(e).find(".Accordion") : $(".Accordion")).each(function(e, t) {
			var n = $(t),
				i = n.attr("data-is-exclusive"),
				o = n.attr("data-exclusive-above") || "",
				r = n.attr("data-exclusive-below") || "";
			(i || o || r) && Accordion.getItemElements(n).each(function(e, t) {
				var n = $(t);
				Expandable.addClickHandler(n, Accordion.update)
			})
		})
	}
};
UI.register(Accordion);
var Button = {
	getRootElement: function(e) {
		return $(e).closest(".Button")
	},
	isDisabled: function(e) {
		return !!Button.getRootElement(e).prop("disabled")
	},
	isLoading: function(e) {
		return Button.getRootElement(e).hasClass("is-loading")
	},
	toggleDisabled: function(e, t) {
		var n = Button.getRootElement(e);
		void 0 === t && (t = !n.prop("disabled")), n.prop("disabled", !!t), n.toggleClass("is-disabled", !!t)
	},
	toggleLoading: function(e, t) {
		var n = Button.getRootElement(e);
		void 0 === t && (t = !n.hasClass("is-loading")), n.toggleClass("is-loading", !!t)
	}
};
UI.register(Button);
var Card = {
	resize: function(e) {
		$(e || document).find(".Card").each(function(e, t) {
			var n = $(t),
				i = parseInt(n.attr("data-offset")),
				o = parseFloat(n.attr("data-ratio"));
			if (!Card.isPrimary(n) || UI.isBelowBreakpoint(UI.BREAKPOINTS.XS)) {
				var r = n.outerWidth(),
					a = Math.floor((r + i) * o);
				Card.isAdaptive(n) ? n.find(".Card-imageWrapper").height(a) : n.height(a)
			} else Card.isAdaptive(n) ? n.find(".Card-imageWrapper").height("") : n.height("");
			if (n.attr("data-image-ratio")) {
				var s = parseFloat(n.attr("data-image-ratio")) / o * 100;
				n.find(".Card-imageWrapper").css("height", s + "%");
				var l = 100 - s;
				n.find(".Card-content").css("height", l + "%")
			}
		})
	},
	refresh: function(e) {
		Card.resize(e)
	},
	isPrimary: function(e) {
		return e.hasClass("is-primary")
	},
	isAdaptive: function(e) {
		return e.hasClass("is-adaptive")
	}
};
UI.register(Card);
var CardFooter = {
	resize: function(e) {
		$(e || document).find(".CardFooter.CardFooter--auto").each(function(e, t) {
			var n = $(t),
				i = n.find(".CardFooter-space");
			if (n.hasClass("CardFooter--adaptive") || n.hasClass("CardFooter--adaptiveXs") && UI.isAboveBreakpoint(UI.BREAKPOINTS.XS) || n.hasClass("CardFooter--adaptiveSm") && UI.isAboveBreakpoint(UI.BREAKPOINTS.SM)) {
				var o = n.find(".CardFooter-content").height();
				i.css("height", o)
			} else UI.clearHeight(i)
		})
	},
	refresh: function(e) {
		CardFooter.resize(e)
	}
};
UI.register(CardFooter);
var CardGroup = {
	syncHandlers: [],
	init: function(e) {
		$(e || document).find(".CardGroup").each(function(e, t) {
			var n, i = $(t);
			i.hasClass("CardGroup--adaptiveLg") ? n = CardGroup.sync.bind(null, t, UI.BREAKPOINTS.LG) : i.hasClass("CardGroup--adaptiveMd") ? n = CardGroup.sync.bind(null, t, UI.BREAKPOINTS.MD) : i.hasClass("CardGroup--adaptiveSm") ? n = CardGroup.sync.bind(null, t, UI.BREAKPOINTS.SM) : i.hasClass("CardGroup--adaptive") && (n = CardGroup.sync.bind(null, t, null)), n && (UI.resizeHandlers.push(n), CardGroup.syncHandlers.push(n))
		})
	},
	load: function(e) {
		CardGroup.syncHandlers.map(function(e) {
			e()
		})
	},
	sync: function(e, t) {
		if (e) {
			var n = $(e).find(".Card.is-adaptive .Card-content");
			t && UI.isBelowBreakpoint(t) ? UI.clearHeight(n) : UI.syncHeight(n)
		}
	}
};
UI.register(CardGroup);
var Carousel = {
	DEFAULT_IN_DELAY: 300,
	DEFAULT_OUT_DELAY: 300,
	DEFAULT_LOCKOUT_DELAY: 0,
	ANALYTICS_LEFT_ARROW_CLICKED_ACTION: "left",
	ANALYTICS_RIGHT_ARROW_CLICKED_ACTION: "right",
	ANALYTICS_SCROLL_BUTTON_CLICKED_ACTION: "square",
	THROTTLE_FOCUS_TIMEOUT: "throttleFocusTimeout",
	THROTTLE_FOCUS_DELAY: 100,
	getRootElement: function(e) {
		return $(e).closest(".Carousel")
	},
	getContainerElement: function(e) {
		return e.children(".Carousel-container")
	},
	getItemElements: function(e) {
		return e.children(".CarouselItem")
	},
	getActiveElement: function(e) {
		return e.children(".CarouselItem.is-active")
	},
	getScrollSelector: function(e) {
		return e.attr("data-scroll")
	},
	isInfinite: function(e) {
		return e.hasClass("is-infinite")
	},
	init: function(e) {
		(e ? $(e).find(".Carousel") : $(".Carousel")).each(function(e, t) {
			var n = $(t),
				i = Carousel.getContainerElement(n),
				o = Carousel.getItemElements(i),
				r = n.find(".Carousel-prev"),
				a = n.find(".Carousel-next");
			Carousel.keyboardMode(n), o.length <= 1 ? ($(r).hide(), $(a).hide()) : ($(r).click(Carousel.prev), $(r).keyup(Carousel.prev), $(a).click(Carousel.next), $(a).keyup(Carousel.next)), i.hammer().bind("swipeleft", Carousel.next), i.hammer().bind("swiperight", Carousel.prev), i.keyup(function(e) {
				"Enter" == e.key && Carousel.getActiveElement(i).find(".Home-heroButtonContainer a").get(0).click()
			}), n.focusin(Carousel.focusIn), n.focusout(Carousel.focusOut), n.hover(Carousel.focusIn, Carousel.hoverOut)
		})
	},
	focusIn: function(e) {
		if (CarouselScroll.HARD_STOP_AUTOSCROLL) return !1;
		Carousel.throttleFocus(e, function() {
			var t = Carousel.getRootElement(e.target),
				n = Carousel.getScrollSelector(t);
			n && CarouselScroll.stopAutoscroll($(n))
		})
	},
	focusOut: function(e) {
		if (CarouselScroll.HARD_STOP_AUTOSCROLL) return !1;
		Carousel.throttleFocus(e, function() {
			Carousel.load()
		})
	},
	hoverOut: function(e) {
		if (CarouselScroll.HARD_STOP_AUTOSCROLL) return !1;
		Carousel.focusOut(e), $(document.activeElement).blur()
	},
	throttleFocus: function(e, t) {
		var n = Carousel.getRootElement(e.target),
			i = n.data(Carousel.THROTTLE_FOCUS_TIMEOUT);
		clearTimeout(i), i = setTimeout(t, Carousel.THROTTLE_FOCUS_DELAY), n.data(Carousel.THROTTLE_FOCUS_TIMEOUT, i)
	},
	isInvalidEvent: function(e) {
		if (e) {
			var t = ("keyup" === e.type || "keydown" === e.type) && "Enter" === e.key,
				n = "click" === e.type || "mousedown" === e.type,
				i = "swipeleft" === e.type || "swiperight" === e.type;
			if (!(t || n || i)) return !0
		}
		return !1
	},
	keyboardMode: function(e) {
		e.mousedown(function() {
			this.classList.remove("keyboardMode")
		}), e.keyup(function() {
			this.classList.add("keyboardMode")
		})
	},
	load: function(e) {
		(e ? $(e).find(".Carousel") : $(".Carousel")).each(function(e, t) {
			var n = $(t),
				i = Carousel.getContainerElement(n),
				o = Carousel.getItemElements(i);
			o.length > 0 && Carousel.getActiveElement(i).length < 1 && (CarouselItem.activate(o[0]), n.addClass("is-leftMax"));
			var r = Carousel.getScrollSelector(n);
			r && CarouselScroll.sync(r, Carousel.getData(t));
			var a = Carousel.getActiveElement(i),
				s = o.index(a);
			Carousel.checkBounds(n, o, s)
		})
	},
	checkBounds: function(e, t, n) {
		e.toggleClass("is-leftMax", n < 1), e.toggleClass("is-rightMax", n > t.length - 2)
	},
	resize: function(e) {
		$(e || document).find(".Carousel").each(function(e, t) {
			var n = $(t),
				i = Carousel.getContainerElement(n),
				o = Carousel.getItemElements(i),
				r = UI.syncHeight(o);
			i.height(r)
		})
	},
	refresh: function(e) {
		Carousel.resize(e)
	},
	activate: function(e, t, n) {
		if (t < 0) return !1;
		n = n || {};
		var i = Carousel.getRootElement(e),
			o = Carousel.getContainerElement(i),
			r = Carousel.getItemElements(o),
			a = Carousel.getActiveElement(o);
		if (t >= r.length) return !1;
		if (i.hasClass("is-transitioning")) return !1;
		var s = r.index(a);
		if (t !== s || CarouselScroll.HARD_STOP_AUTOSCROLL) {
			i.addClass("is-transitioning");
			var l = i.attr("data-out");
			l = void 0 !== l ? parseInt(l) : Carousel.DEFAULT_OUT_DELAY;
			var c = i.attr("data-in");
			c = c ? parseInt(c) : Carousel.DEFAULT_IN_DELAY;
			var u = i.attr("data-lockout");
			u = u ? parseInt(u) : Carousel.DEFAULT_LOCKOUT_DELAY;
			var d = (n.direction ? n.direction : s > t ? "prev" : "next") || "next";
			CarouselItem.deactivate(a, l, function() {
				(a = $(r[t])).addClass("is-active"), Carousel.checkBounds(i, r, t), CarouselItem.activate(a, {
					delay: c,
					callback: function() {
						u > 0 ? setTimeout(function() {
							i.removeClass("is-transitioning")
						}, u) : i.removeClass("is-transitioning")
					},
					direction: d
				})
			})
		}
		var f = Carousel.getScrollSelector(i);
		return f && CarouselScroll.activate(f, t, n), n.analyticsEvent && Carousel.pushAnalyticsToDataLayer(i, e, t, n.analyticsEvent), !0
	},
	prev: function(e) {
		if (Carousel.isInvalidEvent(e)) return !1;
		var t = Carousel.getRootElement(e.target),
			n = Carousel.getContainerElement(t),
			i = Carousel.getItemElements(n),
			o = Carousel.getActiveElement(n),
			r = i.index(o);
		return r > 0 ? (r--, Carousel.activate(e.target, r, {
			direction: "prev",
			analyticsEvent: Carousel.ANALYTICS_LEFT_ARROW_CLICKED_ACTION
		})) : Carousel.isInfinite(t) && (r = i.length - 1, Carousel.activate(e.target, r, {
			direction: "prev",
			analyticsEvent: Carousel.ANALYTICS_LEFT_ARROW_CLICKED_ACTION
		})), Carousel.getActiveElement(n).find(".Home-heroPaneInner").focus(), !1
	},
	next: function(e) {
		if (Carousel.isInvalidEvent(e)) return !1;
		var t = Carousel.getRootElement(e.target),
			n = Carousel.getContainerElement(t),
			i = Carousel.getItemElements(n),
			o = Carousel.getActiveElement(n),
			r = i.index(o) + 1;
		return r < i.length ? Carousel.activate(e.target, r, {
			direction: "next",
			analyticsEvent: Carousel.ANALYTICS_RIGHT_ARROW_CLICKED_ACTION
		}) : Carousel.isInfinite(t) && (r = 0, Carousel.activate(e.target, r, {
			direction: "next",
			analyticsEvent: Carousel.ANALYTICS_RIGHT_ARROW_CLICKED_ACTION
		})), Carousel.getActiveElement(n).find(".Home-heroPaneInner").focus(), CarouselScroll.HARD_STOP_AUTOSCROLL = !0, !1
	},
	getData: function(e) {
		var t = Carousel.getRootElement(e),
			n = Carousel.getContainerElement(t),
			i = Carousel.getItemElements(n),
			o = Carousel.getActiveElement(n);
		return {
			count: i.length,
			active: o.index()
		}
	},
	pushAnalyticsToDataLayer: function(e, t, n, i) {
		var o = e.attr("data-analytics"),
			r = e.attr("data-analytics-placement");
		o && r && window.dataLayer && window.dataLayer.push({
			event: o,
			dataAnalyticsPlacement: r + " || Homepage - position:" + n + " - " + i
		})
	}
};
UI.register(Carousel);
var CarouselItem = {
	DEFAULT_TRANSITION_DELAY: 20,
	EVENT_ANIMATE_IN: "animatein.CarouselItem",
	EVENT_ANIMATE_OUT: "animateout.CarouselItem",
	getRootElement: function(e) {
		return $(e).closest(".CarouselItem")
	},
	getContentElement: function(e) {
		return e.children(".CarouselItem-content")
	},
	activate: function(e, t) {
		t = t || {};
		var n = parseInt(t.delay) || 0,
			i = t.callback,
			o = CarouselItem.getRootElement(e);
		o.removeClass("is-active is-in is-prev-in is-next-in"), o.addClass("is-active"), "prev" === t.direction ? o.addClass("is-prev-in") : "next" === t.direction ? o.addClass("is-next-in") : o.addClass("is-in"), n > 0 ? setTimeout(function() {
			o.trigger(CarouselItem.EVENT_ANIMATE_IN), $.isFunction(i) && (n > 0 ? setTimeout(i, n) : i())
		}, CarouselItem.DEFAULT_TRANSITION_DELAY) : (o.trigger(CarouselItem.EVENT_ANIMATE_IN), $.isFunction(i) && i())
	},
	deactivate: function(e, t, n) {
		t = parseInt(t) || 0;
		var i = CarouselItem.getRootElement(e);
		i.trigger(CarouselItem.EVENT_ANIMATE_OUT), t > 0 ? setTimeout(function() {
			i.removeClass("is-active"), $.isFunction(n) && n()
		}, t) : (i.removeClass("is-active"), $.isFunction(n) && n())
	},
	toggle: function(e) {
		CarouselItem.getRootElement(e).hasClass("is-active") ? CarouselItem.deactivate(e) : CarouselItem.activate(e)
	}
};
UI.register(CarouselItem);
var CarouselScroll = {
	AUTOSCROLL_TIMEOUT: "autoscrollTimeout",
	DEFAULT_AUTOSCROLL_DELAY: 5e3,
	DEFAULT_TRANSITION_DELAY: 600,
	HARD_STOP_AUTOSCROLL: !1,
	getRootElement: function(e) {
		return $(e).closest(".CarouselScroll")
	},
	getContainerElement: function(e) {
		return e.children(".CarouselScroll-container")
	},
	getItemTemplate: function(e) {
		return e.find(".CarouselScroll-template .CarouselScroll-item")
	},
	getItemElements: function(e) {
		return e.children(".CarouselScroll-item")
	},
	getActiveElement: function(e) {
		return e.children(".CarouselScroll-item.is-active")
	},
	getCarouselSelector: function(e) {
		return e.attr("data-carousel")
	},
	isAutoscroll: function(e) {
		return e.hasClass("is-autoscroll")
	},
	isAutoscrollInterrupt: function(e) {
		return e.hasClass("is-autoscroll-interrupt")
	},
	sync: function(e, t) {
		var n = CarouselScroll.getRootElement(e);
		if (!t) {
			var i = CarouselScroll.getCarouselSelector(n);
			i ? t = Carousel.getData(i) : console.error("Could not find data source for CarouselScroll component.")
		}
		var o = CarouselScroll.getContainerElement(n);
		o.empty();
		for (var r, a = CarouselScroll.getItemTemplate(n), s = null, l = 0; l < t.count; l++)(r = a.clone()).click(CarouselScroll.click.bind(null, e, l)), l === t.active && (r.addClass("is-active"), s = r), o.append(r);
		CarouselScroll.isAutoscroll(n) && (CarouselScroll.stopAutoscroll(n), s && CarouselScroll.startAutoscroll(n, s))
	},
	stopAutoscroll: function(e) {
		var t = e.data(CarouselScroll.AUTOSCROLL_TIMEOUT);
		t && clearTimeout(t);
		var n = CarouselScroll.getContainerElement(e);
		CarouselScroll.getItemElements(n).children(".CarouselScroll-inner").stop().css("width", "")
	},
	startAutoscroll: function(e, t) {
		var n = e.attr("data-scroll-delay");
		n = void 0 === n ? CarouselScroll.DEFAULT_AUTOSCROLL_DELAY : parseInt(n);
		var i = e.attr("data-transition-delay");
		i = void 0 === i ? CarouselScroll.DEFAULT_TRANSITION_DELAY : parseInt(i);
		var o = setTimeout(CarouselScroll.autoscroll.bind(null, e), n + i);
		e.data(CarouselScroll.AUTOSCROLL_TIMEOUT, o);
		var r = t.find(".CarouselScroll-inner");
		i > 0 ? setTimeout(CarouselScroll.startAutoscrollAnimation.bind(null, r, n), i) : CarouselScroll.startAutoscrollAnimation(r, n)
	},
	startAutoscrollAnimation: function(e, t) {
		e.css("width", 0), e.animate({
			width: "100%"
		}, t, "linear")
	},
	autoscroll: function(e) {
		var t = CarouselScroll.getContainerElement(e),
			n = CarouselScroll.getItemElements(t),
			i = CarouselScroll.getActiveElement(t),
			o = i.length ? i.index() + 1 : 0;
		o >= n.length && (o = 0);
		var r = CarouselScroll.getCarouselSelector(e);
		Carousel.activate(r, o, {
			automatic: !0
		})
	},
	click: function(e, t) {
		var n = CarouselScroll.getRootElement(e),
			i = CarouselScroll.getCarouselSelector(n),
			o = CarouselScroll.getContainerElement(n),
			r = CarouselScroll.getActiveElement(o);
		if (CarouselScroll.HARD_STOP_AUTOSCROLL = !0, r.index() === t) return !1;
		Carousel.activate(i, t, {
			analyticsEvent: Carousel.ANALYTICS_SCROLL_BUTTON_CLICKED_ACTION
		})
	},
	select: function(e, t, n) {
		Carousel.activate(t, n)
	},
	activate: function(e, t, n) {
		n = n || {};
		var i = CarouselScroll.getRootElement(e),
			o = CarouselScroll.getContainerElement(i),
			r = CarouselScroll.getItemElements(o);
		t = Math.max(0, Math.min(t, r.length - 1)), r.removeClass("is-active");
		var a = $(r[t]);
		a.addClass("is-active"), CarouselScroll.isAutoscroll(i) && (CarouselScroll.stopAutoscroll(i), a.stop(), !n.automatic && CarouselScroll.isAutoscrollInterrupt(i) || CarouselScroll.startAutoscroll(i, a))
	}
};
UI.register(CarouselScroll);
var Counter = {
	init: function(e) {
		(e ? $(e).find(".Counter") : $(".Counter")).each(function(e, t) {
			$(t).children("input.Counter-input").change(Counter.update)
		})
	},
	generateText: function(e, t, n) {
		var i = e.attr("data-replacement");
		return i ? t.replace(i, n) : n + " " + t
	},
	update: function(e) {
		var t, n, i = $(e.target).closest(".Counter"),
			o = i.children("input.Counter-input"),
			r = parseInt(o.val()) || 0;
		t = 0 == r && (n = i.attr("data-empty-text")) ? Counter.generateText(i, n, r) : 1 == r && (n = i.attr("data-singular-text")) ? Counter.generateText(i, n, r) : Counter.generateText(i, i.attr("data-text"), r), i.find(".Counter-text").text(t)
	},
	getValue: function(e) {
		var t = $(e).closest(".Counter").children("input.Counter-input");
		return parseInt(t.val())
	},
	setValue: function(e, t) {
		var n = $(e).closest(".Counter").children("input.Counter-input");
		"object" == typeof t ? n.val(t[n.attr("name")]) : n.val(t), n.change()
	}
};
UI.register(Counter);
var Debug = {
	init: function(e) {
		(e ? $(e).find(".Debug") : $(".Debug")).each(function(e, t) {
			$(t).children(".Debug-toggle").click(Debug.toggle)
		})
	},
	toggle: function(e) {
		$(e.target).closest(".Debug").toggleClass("is-active")
	}
};
UI.register(Debug);
var EmbeddedMedia = {
	init: function(e) {
		$(e || document).find(".EmbeddedMedia").each(function(e, t) {
			UI.resizeHandlers.push(EmbeddedMedia.sync.bind(null, t)), $(t).find(".EmbeddedMedia-preview").click(EmbeddedMedia.activate.bind(null, t))
		})
	},
	load: function(e) {
		$(e || document).find(".EmbeddedMedia").each(function(e, t) {
			EmbeddedMedia.sync(t)
		})
	},
	sync: function(e) {
		var t = $(e),
			n = t.attr("data-height") / t.attr("data-width");
		t.css("height", t.width() * n + "px"), t.children().css("height", t.width() * n + "px")
	},
	activate: function(e) {
		var t = $(e),
			n = t.attr("data-type"),
			i = t.attr("data-name");
		switch (n) {
			case "youtube":
			default:
				t.html('<iframe class="EmbeddedMedia-frame" src="https://www.youtube.com/embed/' + i + '?autoplay=1" allowfullscreen></iframe>'), t.children().css("height", t.height() + "px")
		}
	}
};
UI.register(EmbeddedMedia);
var Expandable = {
	init: function(e) {
		(e ? $(e).find(".Expandable") : $(".Expandable")).each(function(e, t) {
			$(t).find(".Expandable-toggle").click(Expandable.toggle)
		})
	},
	load: function(e) {
		(e ? $(e).find(".Expandable") : $(".Expandable")).each(function(e, t) {
			Expandable.render(t)
		})
	},
	render: function(e) {
		var t = $(e);
		if (t.hasClass("is-open")) {
			var n = t.find(".Expandable-container"),
				i = t.find(".Expandable-content");
			n.css("height", i.outerHeight())
		}
	},
	refresh: function(e) {
		Expandable.resize(e)
	},
	resize: function(e) {
		$(e || document).find(".Expandable:visible").each(function(e, t) {
			Expandable.render(t)
		})
	},
	toggle: function(e) {
		var t = $(e.target),
			n = t.closest(".Expandable");
		n.hasClass("is-caretOnly") && UI.isAboveBreakpoint(UI.BREAKPOINTS.SM) && !t.hasClass("Expandable-caret") ? e.stopImmediatePropagation() : (n.hasClass("is-open") ? Expandable.close(e.target) : Expandable.open(e.target), e.preventDefault())
	},
	reset: function(e) {
		var t = $(e.target).closest(".Expandable");
		t.removeClass("is-transitioning"), t.hasClass("is-open") && UI.scrollIntoView(t.find(".Expandable-toggle")[0])
	},
	open: function(e) {
		var t = $(e).closest(".Expandable");
		if (!t.hasClass("is-open")) {
			t.addClass("is-transitioning"), UI.onTransitionEnd(t, Expandable.reset, !0);
			var n = t.find(".Expandable-container"),
				i = t.find(".Expandable-content");
			n.css("height", i.outerHeight()), t.addClass("is-open")
		}
	},
	close: function(e) {
		var t = $(e).closest(".Expandable");
		t.hasClass("is-open") && (t.addClass("is-transitioning"), UI.onTransitionEnd(t, Expandable.reset, !0), t.find(".Expandable-container").css("height", ""), t.removeClass("is-open"))
	},
	addClickHandler: function(e, t) {
		$(e).find(".Expandable-toggle").on("click", t)
	}
};
UI.register(Expandable);
var FluidGrid = {
	getGridItems: function(e) {
		return e.children(".FluidGridItem")
	},
	load: function(e) {},
	refresh: function(e) {
		$(e || document).find(".FluidGrid").each(function(e, t) {
			var n = $(t),
				i = FluidGrid.getGridItems(n),
				o = .025 * window.innerWidth,
				r = n.attr("data-max-width");
			r = r ? parseInt(r) : 300;
			var a = n.attr("data-min-columns");
			a = a ? parseInt(a) : 1;
			var s = Math.floor(t.getBoundingClientRect().width),
				l = Math.max(a, Math.ceil((s - o) / r)),
				c = ["FluidGridItem", "FluidGridItem--" + l];
			"true" === n.attr("data-rescale") && c.push("fluid-rescale-columns-" + l), i.attr("class", c.join(" ")), UI.refresh(i)
		})
	},
	resize: function() {
		FluidGrid.refresh()
	}
};
UI.register(FluidGrid);
var FormField = {
	init: function(e) {
		(e ? $(e).find(".FormField") : $(".FormField")).each(function(e, t) {
			var n = $(t),
				i = n.children(".FormField-clear");
			i.length > 0 && (n.children(".FormField-input").on("keyup", FormField.update), i.click(FormField.clear))
		})
	},
	update: function(e) {
		var t = $(e.target).closest(".FormField"),
			n = t.children(".FormField-input"),
			i = t.children(".FormField-clear"),
			o = n.val();
		i.toggleClass("hide", !o || o.length < 1)
	},
	clear: function(e) {
		$(e.target).closest(".FormField").children(".FormField-input").val("").trigger("keyup")
	}
};
UI.register(FormField);
var Gallery = {
	GALLERY_BREAKPOINT_MAX: 1720,
	CLASS_SCROLL_FULL_WIDTH: "is-scrollFullWidth",
	CLASS_DISABLE_SNAP: "is-disableSnap",
	ANIMATION_DURATION: UI.DEFAULT_SLIDE_ANIMATION_DURATION,
	CENTERLINE_THRESHOLD: 50,
	getRootElement: function(e) {
		return $(e).closest(".Gallery")
	},
	getWrapperElement: function(e) {
		return e.children(".Gallery-wrapper")
	},
	getContainerElement: function(e) {
		return e.find(".Gallery-container")
	},
	getInnerElement: function(e) {
		return e.find(".Gallery-inner")
	},
	getItemElements: function(e) {
		var t = e.find(".GalleryItem");
		return t.length > 0 ? t : (galleryCard = e.find(".GalleryCard"), galleryCard)
	},
	getFocusElement: function(e) {
		var t = e.find(".GalleryItem.is-focus");
		return t.length > 0 ? t : (galleryCard = e.find(".GalleryCard.is-focus"), galleryCard)
	},
	getData: function(e) {
		var t = Gallery.getRootElement(event.target),
			n = Gallery.getContainerElement(t),
			i = Gallery.getItemElements(n),
			o = Math.floor(n.width / i[0].offsetWidth);
		return {
			count: i.length,
			span: o,
			width: t.width()
		}
	},
	isAdaptive: function(e) {
		return e.hasClass("is-adaptive")
	},
	init: function(e) {
		$(e || document).find(".Gallery").each(function(e, t) {
			var n = $(t);
			n.find(".Gallery-left").click(Gallery.left), n.find(".Gallery-right").click(Gallery.right);
			var i = Gallery.getContainerElement(n),
				o = Gallery.getItemElements(i);
			o.click(Gallery.click), o.length < 2 && n.addClass("is-arrows-disabled")
		})
	},
	load: function(e) {
		Gallery.resize()
	},
	resize: function(e) {
		$(e || document).find(".Gallery").each(function(e, t) {
			var n = $(t);
			if (n.is(":visible")) {
				Gallery.getWrapperElement(n);
				var i = Gallery.getContainerElement(n),
					o = (Gallery.getItemElements(i), n.width()),
					r = !1,
					a = !1,
					s = !1,
					l = !1;
				o >= Gallery.GALLERY_BREAKPOINT_MAX ? l = !0 : o >= UI.BREAKPOINTS.LG ? s = !0 : o >= UI.BREAKPOINTS.SM ? a = !0 : o >= UI.BREAKPOINTS.XS && (r = !0), n.toggleClass("is-xs", r), n.toggleClass("is-sm", a), n.toggleClass("is-lg", s), n.toggleClass("is-hg", l), GalleryItem.sync(i, o, n.hasClass("Gallery--compact")), i[0].scrollWidth > i[0].clientWidth ? n.addClass("is-constrained") : n.removeClass("is-constrained"), Gallery.checkLimits(t, i[0].scrollLeft), UI.refresh(i, !1)
			}
		})
	},
	refresh: function(e) {
		Gallery.resize(e)
	},
	nearest: function(e, t, n) {
		var i = e[0].getBoundingClientRect().left + e.width() / 2,
			o = null,
			r = null;
		return n.each(function(e, t) {
			var n = t.getBoundingClientRect().left + $(t).width() / 2,
				a = i - n;
			(null === r || Math.abs(a) < Math.abs(o)) && (r = t, o = a)
		}), {
			$elem: $(r),
			distance: o
		}
	},
	getScrollDistance: function(e, t, n) {
		var i = n[0];
		return e.hasClass(Gallery.CLASS_SCROLL_FULL_WIDTH) ? t.width() : i.offsetWidth + parseInt((i.currentStyle || window.getComputedStyle(i)).marginRight.replace(/\D/g, ""))
	},
	getInnerWidth: function(e) {
		if (e.length < 1) return 0;
		var t = e.first(),
			n = t[0].getBoundingClientRect().left - parseInt(t.css("marginLeft")),
			i = e.last();
		return i[0].getBoundingClientRect().right + parseInt(i.css("marginRight")) - n
	},
	left: function(e) {
		var t = Gallery.getRootElement(e.target),
			n = Gallery.getContainerElement(t),
			i = Gallery.getItemElements(n),
			o = Gallery.getScrollDistance(t, n, i),
			r = Gallery.getInnerWidth(i) - n.width(),
			a = Math.max(0, Math.min(n.scrollLeft() - o, r));
		a < 5 && (a = 0), Gallery.checkLimitsInner(t, a, r), n.animate({
			scrollLeft: a
		}, {
			duration: Gallery.ANIMATION_DURATION,
			easing: "easeOutCubic"
		})
	},
	right: function(e) {
		var t = Gallery.getRootElement(e.target),
			n = Gallery.getContainerElement(t),
			i = Gallery.getItemElements(n),
			o = Gallery.getScrollDistance(t, n, i),
			r = Gallery.getInnerWidth(i) - n.width(),
			a = Math.max(0, Math.min(n.scrollLeft() + o, r));
		a + 5 > r && (a = r), Gallery.checkLimitsInner(t, a, r), n.animate({
			scrollLeft: a
		}, {
			duration: Gallery.ANIMATION_DURATION,
			easing: "easeOutCubic"
		})
	},
	checkLimits: function(e, t) {
		var n = Gallery.getRootElement(e),
			i = Gallery.getContainerElement(n),
			o = Gallery.getItemElements(i),
			r = Gallery.getInnerWidth(o) - i.width();
		Gallery.checkLimitsInner(n, t, r)
	},
	checkLimitsInner: function(e, t, n) {
		e.toggleClass("is-leftMax", t <= 0), e.toggleClass("is-rightMax", t >= n)
	},
	focus: function(e, t, n) {
		var i = Gallery.getItemElements(n);
		Gallery.snapTo($(i[0]), i, e, n, t)
	},
	snapTo: function(e, t, n, i, o, r) {
		if (e && e.length > 0) {
			var a = o.width() / 2 - e.width() / 2,
				s = e[0].offsetLeft - a;
			t.removeClass("is-focus"), e.addClass("is-focus"), n.removeClass("is-leftMax is-rightMax"), 0 === t.index(e) ? n.addClass("is-leftMax") : t.index(e) === t.length - 1 && n.addClass("is-rightMax");
			var l = r ? 0 : Gallery.ANIMATION_DURATION;
			i.animate({
				scrollLeft: s
			}, {
				duration: l,
				easing: "easeOutCubic"
			})
		}
	},
	snapIndexLeft: function(e, t) {
		var n = Gallery.getRootElement(e),
			i = Gallery.getContainerElement(n),
			o = Gallery.getItemElements(i),
			r = $(o[t]);
		if (r.length) {
			var a = r[0].getBoundingClientRect(),
				s = Gallery.getInnerWidth(o) - i.width(),
				l = i.getBoundingClientRect().left - a.left;
			if (l > 0) {
				var c = Math.max(0, Math.min(i.scrollLeft() + l, s));
				n.toggleClass("is-leftMax", c <= 0), n.toggleClass("is-rightMax", c >= s), i.animate({
					scrollLeft: c
				}, {
					duration: Gallery.ANIMATION_DURATION,
					easing: "easeOutCubic"
				})
			}
		}
	},
	click: function(e) {
		var t = $(e.target).closest(".GalleryItem");
		if (null !== GalleryItem.getMetadata(t[0])) {
			var n = Gallery.getRootElement(e.target),
				i = Gallery.getContainerElement(n),
				o = Gallery.getItemElements(i);
			t.hasClass("is-focus") || (o.removeClass("is-focus"), t.addClass("is-focus"));
			var r = {
					items: [],
					modal: !0,
					index: 0
				},
				a = 0;
			o.each(function(e, n) {
				var i = GalleryItem.getMetadata(n);
				i && r.items.push(i), t.index() === e && (a = e, i.type === Lightbox.TYPE_YOUTUBE && (i.cancelAutoplay = !1)), 0
			}), r.index = a, Lightbox.activate(r)
		}
	}
};
UI.register(Gallery);
var GalleryCard = {
	beforeLoad: function(e) {
		$(e || document).find(".GalleryCard").each(function(e, t) {
			$(t).css("width", GalleryCard.calcWidth(t) || "")
		})
	},
	getMetadata: function(e) {
		var t = $(e).closest(".GalleryCard");
		if (!t) return null;
		var n = t.children("img.GalleryCard-image");
		return n.length ? {
			url: n.attr("src"),
			width: n[0].naturalWidth,
			height: n[0].naturalHeight
		} : null
	},
	calcWidth: function(e) {
		var t = $(e),
			n = t.children(".GalleryCard-image"),
			i = t.attr("data-ratio");
		return i ? parseFloat(i) * (n.length ? n.height() : t.height()) : n.length ? n.width() : ""
	}
};
UI.register(GalleryCard);
var GalleryItem = {
	GALLERY_BREAKPOINT_MAX: 1720,
	BREAKPOINT_DATA_DEFAULT: {
		xs: {
			margin: 30,
			gap: 20,
			columns: 2
		},
		sm: {
			margin: 40,
			gap: 20,
			columns: 2
		},
		md: {
			margin: 40,
			gap: 20,
			columns: 2
		},
		lg: {
			margin: 40,
			gap: 30,
			columns: 3
		},
		hg: {
			margin: 80,
			gap: 40,
			columns: 4
		}
	},
	BREAKPOINT_DATA_COMPACT: {
		xs: {
			margin: 30,
			gap: 20,
			columns: 2
		},
		sm: {
			margin: 40,
			gap: 20,
			columns: 2
		},
		md: {
			margin: 40,
			gap: 20,
			columns: 3
		},
		lg: {
			margin: 40,
			gap: 30,
			columns: 4
		},
		hg: {
			margin: 80,
			gap: 40,
			columns: 4
		}
	},
	sync: function(e, t, n) {
		var i = !1,
			o = !1,
			r = !1,
			a = !1,
			s = !1,
			l = n ? GalleryItem.BREAKPOINT_DATA_COMPACT : GalleryItem.BREAKPOINT_DATA_DEFAULT,
			c = {
				margin: UI.isDesktopMode() ? 20 : 25,
				gap: 15,
				columns: 1
			};
		t >= GalleryItem.GALLERY_BREAKPOINT_MAX ? (c = l.hg, s = !0) : t >= UI.BREAKPOINTS.LG ? (c = l.lg, a = !0) : t >= UI.BREAKPOINTS.MD ? (c = l.md, r = !0) : t >= UI.BREAKPOINTS.SM ? (c = l.sm, o = !0) : t >= UI.BREAKPOINTS.XS && (c = l.xs, i = !0), e.find(".GalleryItem").each(function(e, n) {
			var l = $(n),
				u = l.attr("data-width");
			u = u ? parseInt(u) : (t - 2 * c.margin - (c.columns - 1) * c.gap) / c.columns, l.css("width", u + "px"), l.toggleClass("is-xs", i), l.toggleClass("is-sm", o), l.toggleClass("is-md", r), l.toggleClass("is-lg", a), l.toggleClass("is-hg", s);
			var d = l.attr("data-ratio");
			d && (d = parseFloat(d), l.css("height", u / d + "px"))
		})
	},
	getMetadata: function(e) {
		var t = $(e).closest(".GalleryItem");
		if (!t) return null;
		var n = t.attr("data-videoUrl");
		if (n) return {
			type: Lightbox.TYPE_YOUTUBE,
			id: n,
			cancelAutoplay: !0,
			width: t.attr("data-videoWidth"),
			height: t.attr("data-videoHeight")
		};
		var i = t.children("img.GalleryItem-image");
		return i.length ? {
			url: i.attr("src"),
			width: i[0].naturalWidth,
			height: i[0].naturalHeight
		} : null
	}
};
UI.register(GalleryItem);
var GalleryScroll = {
	getRootElement: function(e) {
		return $(e).closest(".GalleryScroll")
	},
	getContainerElement: function(e) {
		return e.children(".GalleryScroll-container")
	},
	getItemTemplate: function(e) {
		return e.find(".GalleryScroll-template .GalleryScroll-item")
	},
	getItemElements: function(e) {
		return e.children(".GalleryScroll-item")
	},
	getActiveElement: function(e) {
		return e.children(".GalleryScroll-item.is-active")
	},
	getGallerySelector: function(e) {
		return e.attr("data-gallery")
	},
	init: function(e) {
		$(e || document).find(".GalleryScroll").each(function(e, t) {
			GalleryScroll.sync(t)
		})
	},
	sync: function(e, t) {
		var n = GalleryScroll.getRootElement(e);
		if (!t) {
			var i = GalleryScroll.getGallerySelector(n);
			i ? t = Gallery.getData(i) : console.error("Could not find data source for GalleryScroll component.")
		}
		var o = GalleryScroll.getContainerElement(n);
		o.empty();
		for (var r, a = GalleryScroll.getItemTemplate(n), s = 0; s < t.count; s += t.span || 1)(r = a.clone()).click(GalleryScroll.click.bind(null, e, s)), s === t.active && (r.addClass("is-active"), r), o.append(r)
	},
	click: function(e, t) {
		var n = GalleryScroll.getRootElement(e),
			i = GalleryScroll.getGallerySelector(n);
		Gallery.activate(i, t)
	},
	select: function(e, t, n) {
		Gallery.activate(t, n)
	},
	activate: function(e, t) {
		var n = GalleryScroll.getRootElement(e),
			i = GalleryScroll.getContainerElement(n),
			o = GalleryScroll.getItemElements(i);
		t = Math.max(0, Math.min(t, o.length - 1)), o.removeClass("is-active"), $(o[t]).addClass("is-active")
	}
};
UI.register(GalleryScroll);
var Grid = {
	syncHandlers: [],
	getItemElements: function(e) {
		return e.children(".GridItem")
	},
	init: function(e) {
		$(e || document).find(".Grid").each(function(e, t) {
			var n, i = $(t);
			i.hasClass("Grid--syncLg") ? n = Grid.sync.bind(null, t, UI.BREAKPOINTS.LG) : i.hasClass("Grid--syncMd") ? n = Grid.sync.bind(null, t, UI.BREAKPOINTS.MD) : i.hasClass("Grid--syncSm") ? n = Grid.sync.bind(null, t, UI.BREAKPOINTS.SM) : i.hasClass("Grid--sync") && (n = Grid.sync.bind(null, t, null)), n && (UI.resizeHandlers.push(n), Grid.syncHandlers.push(n))
		})
	},
	load: function(e) {
		Grid.syncHandlers.map(function(e) {
			e()
		})
	},
	sync: function(e, t) {
		var n = $(e),
			i = Grid.getItemElements(n);
		!t || UI.isAboveBreakpoint(t) ? UI.syncHeight(i) : UI.clearHeight(i)
	}
};
UI.register(Grid);
var Hider = {
	toggle: function(e, t) {
		$(e).closest(".Hider").toggleClass("is-hidden", t)
	}
};
UI.register(Hider);
var ImageSlider = {
	DEFAULT_ANIMATION_DELAY: UI.DEFAULT_SLIDE_ANIMATION_DURATION,
	init: function(e) {
		(e ? $(e).find(".ImageSlider") : $(".ImageSlider")).each(function(e, t) {
			var n = $(t),
				i = n.closest(".CarouselItem");
			i.length > 0 && (i.on(CarouselItem.EVENT_ANIMATE_IN, ImageSlider.animateIn.bind(null, t)), i.on(CarouselItem.EVENT_ANIMATE_OUT, ImageSlider.animateOut.bind(null, t))), n.children(".ImageSlider-container").children(".ImageSlider-item").each(function(e, t) {
				$(t).click(ImageSlider.clickHandler.bind(null, t, e))
			})
		})
	},
	animateIn: function(e) {
		$(e).addClass("is-active")
	},
	animateOut: function(e) {
		$(e).removeClass("is-active")
	},
	clickHandler: function(e, t) {
		var n = $(e).closest(".Carousel");
		n.length > 0 && Carousel.activate(n, t)
	}
};
UI.register(ImageSlider);
var Lightbox = {
		DEFAULT_IMAGE_WIDTH: 480,
		DEFAULT_IMAGE_HEIGHT: 320,
		TYPE_YOUTUBE: "youtube",
		TYPE_PAGE: "page",
		TYPE_HTML5_VIDEO: "video",
		currentVideo: null,
		processDeck: function(e, t) {
			for (var n = [], i = 0; i < t.items.length; ++i) {
				var o = t.items[i],
					r = {
						id: o.id,
						type: o.type
					};
				if (Lightbox.TYPE_YOUTUBE == o.type) {
					var a = o.cancelAutoplay ? 0 : 1;
					r.html = Lightbox.addLightboxVideoWrapperHTML("Lightbox-youtubeVideo", '<iframe data-id="' + o.id + '" width="' + (o.width || Lightbox.DEFAULT_IMAGE_WIDTH) + '" height="' + (o.height || Lightbox.DEFAULT_IMAGE_HEIGHT) + '" src="https://www.youtube.com/embed/' + o.id + "?enablejsapi=1&autoplay=" + a + '" frameborder="0" allowfullscreen></iframe>')
				} else if (Lightbox.TYPE_HTML5_VIDEO == o.type) {
					a = o.cancelAutoplay ? "" : "autoplay";
					var s = '<video data-id="' + o.id + '" width="100%" height="100%" ' + a + ' controls controlsList="nodownload" preload="auto" x-webkit-airplay="allow">';
					for (i = 0; i < o.sources.length; i++) {
						var l = o.sources[i];
						s += '<source src="' + l.videoUrl + '" type="' + l.type + '">'
					}
					o.altText && (s += o.altText), s += "</video>", r.html = Lightbox.addLightboxVideoWrapperHTML("Lightbox-html5Video", s)
				} else Lightbox.TYPE_PAGE == o.type ? r.html = '<div class="Lightbox-pageWrapper"><div class="Lightbox-page">' + o.html + "</div></div>" : (r.w = o.width || Lightbox.DEFAULT_IMAGE_WIDTH, r.h = o.height || Lightbox.DEFAULT_IMAGE_HEIGHT, r.src = o.url);
				n.push(r)
			}
			return n
		},
		addLightboxVideoWrapperHTML: function(e, t) {
			var n = '<div class="Lightbox-videoWrapper"><div class="' + e + '">';
			return n += t, n += "</div></div>"
		},
		stopVideo: function() {
			if (Lightbox.currentVideo) {
				var e = $(".Lightbox");
				Lightbox.stopCurrentYoutubeVideo(e), Lightbox.stopCurrentHTML5Video(e), Lightbox.currentVideo = null
			}
		},
		stopCurrentYoutubeVideo: function(e) {
			if (Lightbox.currentVideo.type == Lightbox.TYPE_YOUTUBE) {
				var t = e.find("iframe[data-id=" + Lightbox.currentVideo.id + "]");
				t.length && Lightbox.stopIFrameVideo(t[0])
			}
		},
		stopCurrentHTML5Video: function(e) {
			if (Lightbox.currentVideo.type == Lightbox.TYPE_HTML5_VIDEO) {
				var t = e.find("video[data-id=" + Lightbox.currentVideo.id + "]");
				t.length && Lightbox.stopHTML5Video(t[0])
			}
		},
		stopHTML5Video: function(e) {
			e.pause(), e.currentTime = 0
		},
		stopIFrameVideo: function(e) {
			e.contentWindow.postMessage(JSON.stringify({
				event: "command",
				func: "stopVideo",
				args: []
			}), "*")
		},
		activate: function(e) {
			var t = $(".Lightbox");
			if (t) {
				var n, i = {
					modal: !0,
					index: 0,
					history: !1,
					closeOnScroll: !1
				};
				if ("string" == typeof e) {
					var o = t.attr("data-sets"),
						r = (o ? JSON.parse(o) : {})[e];
					void 0 !== r.modal && (i.modal = !!r.modal), n = Lightbox.processDeck(t, r)
				} else n = Lightbox.processDeck(t, e), i.modal = e.modal, e.index && (i.index = e.index), 1 == e.items.length && "page" == e.items[0].type && (UI.toggleModalLock(!0), i.closeOnScroll = !1, i.closeOnVerticalDrag = !1);
				var a = new PhotoSwipe(t[0], PhotoSwipeUI_Default, n, i);
				Lightbox.gallery = a, a.listen("gettingData", function(e, t) {
					if (void 0 === t.html && void 0 === t.onloading && (t.w < 1 || t.h < 1)) {
						t.onloading = !0;
						var n = new Image;
						n.onload = function() {
							t.w = this.width, t.h = this.height, a.invalidateCurrItems(), a.updateSize(!0)
						}, n.src = t.src
					}
				}), a.listen("destroy", function() {
					Lightbox.stopVideo(), Array.prototype.slice.call(a.container.getElementsByClassName("pswp__item")).forEach(function(e) {
						for (; e.lastChild;) e.removeChild(e.lastChild)
					}), UI.toggleModalLock(!1)
				}), a.listen("beforeChange", function() {
					Lightbox.stopVideo();
					var e = a.currItem;
					e.type != Lightbox.TYPE_YOUTUBE && e.type != Lightbox.TYPE_HTML5_VIDEO || (Lightbox.currentVideo = {
						id: e.id,
						type: e.type
					})
				}), a.init(), Lightbox.disablePhotoswipeInterceptorsForHTML5VideoPlayback(t), t.find(".Lightbox-pageWrapper").on("click touchstart touchmove touchend mousedown mousemove mouseup wheel mousewheel DOMMouseScroll scroll", Lightbox.contentClickHandler)
			}
		},
		deactivate: function() {
			Lightbox.gallery.close()
		},
		contentClickHandler: function(e) {
			e.stopImmediatePropagation()
		},
		disablePhotoswipeInterceptorsForHTML5VideoPlayback: function(e) {
			e.find(".Lightbox-html5Video").on("pointerdown touchstart touchmove touchend keydown click mousemove mouseover", Lightbox.contentClickHandler)
		}
	},
	LightboxDeck = {
		activate: function(e) {
			var t = $(e).closest(".LightboxDeck");
			if (t.length > 0) {
				var n = {
					items: [],
					modal: !0,
					index: 0
				};
				t.children(".LightboxDeckItem").each(function(e, t) {
					n.items.push(LightboxDeckItem.getMetadata(t))
				}), Lightbox.activate(n)
			}
		}
	};
UI.register(LightboxDeck);
var LightboxDeckItem = {
	TYPE_PAGE: "page",
	getMetadata: function(e) {
		var t = $(e).closest(".LightboxDeckItem");
		return t.attr("data-type") == LightboxDeckItem.TYPE_PAGE ? {
			type: LightboxDeckItem.TYPE_PAGE,
			html: t.html()
		} : {
			url: t.attr("data-url"),
			width: t.attr("data-width"),
			height: t.attr("data-height")
		}
	}
};
UI.register(LightboxDeckItem);
var MultiSelectDropdown = {
	KEY_CODE_TAB: 9,
	KEY_CODE_ENTER: 13,
	KEY_CODE_SPACE: 32,
	KEY_CODE_UP: 38,
	KEY_CODE_DOWN: 40,
	DOCUMENT_MARGIN: 20,
	SCROLLBAR_MARGIN: 10,
	SCROLL_THRESHOLD: 10,
	KEY_DATA: "touchData",
	getRootElement: function(e) {
		return $(e).closest(".MultiSelectDropdown")
	},
	getToggleElement: function(e) {
		return e.children(".MultiSelectDropdown-toggle")
	},
	getInputElement: function(e) {
		return e.children(".MultiSelectDropdown-input")
	},
	getInputOptions: function(e, t) {
		return e.children("option" + (t ? ":selected" : ""))
	},
	getListContainer: function(e) {
		return e.children(".MultiSelectDropdown-listContainer")
	},
	getScrollable: function(e) {
		return e.find(".MultiSelectDropdown-scrollable")
	},
	getListElement: function(e) {
		return e.find(".MultiSelectDropdown-list")
	},
	getListOptions: function(e) {
		return e.children(".MultiSelectDropdown-option")
	},
	getListSelectAll: function(e) {
		return e.children(".MultiSelectDropdown-selectAll")
	},
	getListChildren: function(e) {
		return e.children(".MultiSelectDropdown-option, .MultiSelectDropdown-selectAll")
	},
	init: function(e) {
		(e ? $(e).find(".MultiSelectDropdown") : $(".MultiSelectDropdown")).each(function(e, t) {
			var n = $(t),
				i = MultiSelectDropdown.getToggleElement(n);
			i.on("touchstart", MultiSelectDropdown.handleStart), i.on("touchend", MultiSelectDropdown.handleEnd), $("html").get(0).addEventListener("touchmove", function(e) {
				var t = document.elementFromPoint(e.touches[0].clientX, e.touches[0].clientY);
				~$(t).attr("class").indexOf("MultiSelectDropdown") ? e.preventDefault() : $("html").click()
			}, {
				passive: !1
			}), i.click(MultiSelectDropdown.handleToggleClick), MultiSelectDropdown.getInputElement(n).on("change", MultiSelectDropdown.render);
			var o = MultiSelectDropdown.getListElement(n);
			MultiSelectDropdown.getListOptions(o).click(MultiSelectDropdown.handleOptionClick), MultiSelectDropdown.getListSelectAll(o).click(MultiSelectDropdown.handleSelectAllClick), n.on("keydown.selectDropdown", MultiSelectDropdown.handleKeyPress), n.on("shown.bs.dropdown", MultiSelectDropdown.render)
		})
	},
	handleStart: function(e) {
		UI.mouse.update(e.originalEvent);
		var t = UI.mouse.snapshot(),
			n = MultiSelectDropdown.getRootElement(e.target);
		n.data(MultiSelectDropdown.KEY_DATA, {
			x: t.x,
			y: t.y,
			active: !1
		}), n.on("touchmove", MultiSelectDropdown.handleMove)
	},
	handleMove: function(e) {
		UI.mouse.update(e.originalEvent);
		var t = UI.mouse.snapshot(),
			n = MultiSelectDropdown.getRootElement(e.target).data(MultiSelectDropdown.KEY_DATA),
			i = t.x - n.x,
			o = t.y - n.y;
		(n.active || Math.abs(i) >= MultiSelectDropdown.SCROLL_THRESHOLD || Math.abs(o) >= MultiSelectDropdown.SCROLL_THRESHOLD) && (n.active = !0)
	},
	handleEnd: function(e) {
		var t = MultiSelectDropdown.getRootElement(e.target);
		t.off("touchmove", MultiSelectDropdown.handleMove), t.data(MultiSelectDropdown.KEY_DATA).active || (e.stopPropagation(), t.data("currentIndex", null), t.data("originalIndex", null))
	},
	handleToggleClick: function(e) {
		if (UI.isRecentTouch()) return e.stopImmediatePropagation(), void e.preventDefault();
		var t = MultiSelectDropdown.getRootElement(e.target);
		t.data("currentIndex", null), t.data("originalIndex", null)
	},
	handleOptionClick: function(e) {
		e.stopPropagation();
		var t = $(e.target).closest(".MultiSelectDropdown-option"),
			n = MultiSelectDropdown.getRootElement(e.target),
			i = MultiSelectDropdown.getInputElement(n),
			o = MultiSelectDropdown.getInputOptions(i),
			r = MultiSelectDropdown.getToggleElement(n),
			a = MultiSelectDropdown.getListElement(n),
			s = MultiSelectDropdown.getListOptions(a).index(t);
		if (n.data("currentIndex", s), !e.shiftKey) {
			n.data("originalIndex", s);
			var l = o.eq(s);
			l.prop("selected") ? l.prop("selected", !1) : l.prop("selected", !0)
		}
		r.focus(), i.change()
	},
	handleSelectAllClick: function(e) {
		e.stopPropagation();
		var t = $(e.target),
			n = MultiSelectDropdown.getRootElement(e.target),
			i = MultiSelectDropdown.getInputElement(n),
			o = MultiSelectDropdown.getInputOptions(i),
			r = MultiSelectDropdown.getToggleElement(n),
			a = MultiSelectDropdown.getListElement(n),
			s = MultiSelectDropdown.getListChildren(a).index(t);
		if (n.data("currentIndex", s), !e.shiftKey) {
			n.data("originalIndex", n.data("currentIndex"));
			var l = MultiSelectDropdown.getInputOptions(i, !0);
			o.prop("selected", l.length < o.length)
		}
		r.focus(), i.change()
	},
	handleKeyPress: function(e) {
		var t = MultiSelectDropdown.getRootElement(e.target),
			n = MultiSelectDropdown.getInputElement(t);
		if (t.hasClass("open")) {
			if (e.keyCode === MultiSelectDropdown.KEY_CODE_TAB && t.hasClass("open")) MultiSelectDropdown.getToggleElement(t).click();
			else {
				var i = MultiSelectDropdown.getListElement(t),
					o = MultiSelectDropdown.getListChildren(i),
					r = MultiSelectDropdown.getListSelectAll(i);
				if (!o.length) return;
				var a = t.data("currentIndex");
				if (e.keyCode === MultiSelectDropdown.KEY_CODE_UP || e.keyCode === MultiSelectDropdown.KEY_CODE_DOWN) {
					if (null === a) e.keyCode === MultiSelectDropdown.KEY_CODE_DOWN && (a = 0);
					else if (e.keyCode === MultiSelectDropdown.KEY_CODE_UP) {
						if (!(a > 0)) return MultiSelectDropdown.getToggleElement(t).click(), e.stopPropagation(), void e.preventDefault();
						a--
					} else e.keyCode === MultiSelectDropdown.KEY_CODE_DOWN && a < o.length - 1 && a++;
					t.data("currentIndex", a), e.shiftKey || t.data("originalIndex", a)
				}
				var s = o.eq(a);
				s.focus(), o.removeClass("is-active"), s.addClass("is-active");
				var l = MultiSelectDropdown.getScrollable(t);
				if (Scrollable.scrollTo(l, s), e.keyCode === MultiSelectDropdown.KEY_CODE_ENTER || e.keyCode === MultiSelectDropdown.KEY_CODE_SPACE) {
					var c = t.data("currentIndex"),
						u = t.data("originalIndex");
					if (c < u) {
						var d = c;
						c = u, u = d
					}
					var f = MultiSelectDropdown.getInputOptions(n);
					if (0 != r.length && c == o.index(r)) {
						var p = MultiSelectDropdown.getInputOptions(n, !0);
						f.prop("selected", p.length < f.length)
					} else {
						var h = f.slice(u, c + 1),
							m = h.filter(function() {
								return $(this).prop("selected")
							});
						h.prop("selected", m.length < h.length)
					}
				}
				e.stopPropagation(), e.preventDefault()
			}
			n.change()
		}
	},
	setValue: function(e, t, n) {
		var i = MultiSelectDropdown.getRootElement(e),
			o = MultiSelectDropdown.getInputElement(i);
		o.val(t), n ? MultiSelectDropdown.render({
			target: e
		}) : o.change()
	},
	render: function(e) {
		var t = MultiSelectDropdown.getRootElement(e.target),
			n = MultiSelectDropdown.getInputElement(t),
			i = MultiSelectDropdown.getInputOptions(n),
			o = MultiSelectDropdown.getListContainer(t),
			r = MultiSelectDropdown.getListElement(t),
			a = MultiSelectDropdown.getListOptions(r),
			s = MultiSelectDropdown.getListSelectAll(r),
			l = MultiSelectDropdown.getListChildren(r),
			c = MultiSelectDropdown.getToggleElement(t),
			u = [];
		l.removeClass("is-active"), l.removeClass("is-selected");
		var d = n.val();
		d && (d.length == i.length ? (a.addClass("is-selected"), s.addClass("is-selected"), i.each(function(e) {
			u.push(a.eq(e).data("label"))
		})) : i.each(function(e, t) {
			if ($(t).prop("selected")) {
				var n = a.eq(e);
				n.addClass("is-selected"), u.push(n.data("label"))
			}
		}));
		var f = c.children("span.MultiSelectDropdown-label");
		0 == u.length ? c.data("default-text") ? f.text(c.data("default-text")) : f.text(" ") : null != t.data("select-all-label") && u.length == a.length ? f.text(t.data("select-all-label")) : f.text(u.join(", "));
		var p = t.data("currentIndex"),
			h = t.data("originalIndex");
		if (null != p) {
			if (p < h) {
				var m = p;
				p = h, h = m
			}
			for (var g = h; g <= p; ++g) l.eq(g).addClass("is-active")
		}
		if (t.hasClass("open")) {
			r.height() < o.height() && o.height(r.height());
			var v = $("body").width(),
				y = r.width(),
				b = v - 2 * MultiSelectDropdown.DOCUMENT_MARGIN,
				E = r.find(".MultiSelectDropdown-optionText"),
				T = a.first().outerWidth() - a.first().width(),
				w = Math.max.apply(null, E.map(function() {
					return $(this).width()
				}).get()) + T + MultiSelectDropdown.SCROLLBAR_MARGIN;
			w != y && (y = w, o.width(y)), (y > o.width() || b < y) && (y = Math.min(y, b), o.width(y));
			var S = o.offset().left - o.position().left,
				C = v - MultiSelectDropdown.DOCUMENT_MARGIN - (S + y);
			if (C < 0) {
				var I = t.width() - y;
				S + I >= MultiSelectDropdown.DOCUMENT_MARGIN && (C = I)
			}
			C = Math.max(C, MultiSelectDropdown.DOCUMENT_MARGIN - S), C = Math.min(C, 0), o.css({
				left: C + "px"
			}), Scrollable.render(MultiSelectDropdown.getScrollable(t))
		}
	},
	resize: function() {
		$(".MultiSelectDropdown.open").each(function(e, t) {
			MultiSelectDropdown.getToggleElement($(t)).click()
		})
	}
};
UI.register(MultiSelectDropdown);
var Navigation = {
	ANIMATION_DURATION: UI.DEFAULT_ANIMATION_DURATION,
	CONTAINER_PADDING: 40,
	SCROLL_ITEMS: 2,
	getRootElement: function(e) {
		return $(e).closest(".Navigation")
	},
	getWrapperElement: function(e) {
		return e.find(".Navigation-wrapper")
	},
	getContainerElement: function(e) {
		return e.find(".Navigation-container")
	},
	init: function(e) {
		(e ? $(e).find(".Navigation") : $(".Navigation")).each(function(e, t) {
			var n = $(t),
				i = Navigation.getContainerElement(n),
				o = {
					$root: n,
					$wrapper: Navigation.getWrapperElement(n),
					$container: i
				};
			UI.TouchScroll.bind(o), n.find(".Navigation-link").on("click", function(e) {
				UI.TouchScroll.isActive(n) && (e.stopImmediatePropagation(), e.preventDefault())
			}), n.find(".Navigation-scrollLeft").on("click", Navigation.scrollLeft), n.find(".Navigation-scrollRight").on("click", Navigation.scrollRight)
		})
	},
	load: function(e) {
		Navigation.resize(), $(".Navigation", e).each(function(e, t) {
			var n = $(t),
				i = Navigation.getContainerElement(n),
				o = Navigation.getWrapperElement(n),
				r = i.find(".Navigation-link.is-selected");
			if (r.length > 0 && n.hasClass("is-constrained")) {
				var a = r[0].offsetParent ? r[0].offsetParent.offsetLeft : 0,
					s = i.width() - o.width(),
					l = Math.min(Math.max(-s, -a), 0);
				i.css("left", l - UI.TouchScroll.EXTRA_MARGIN + "px"), UI.TouchScroll.checkOverflows(n, l, -s, 0)
			}
		})
	},
	scrollLeft: function(e) {
		var t, n, i = Navigation.getRootElement(e.target),
			o = Navigation.getContainerElement(i),
			r = Navigation.getWrapperElement(i),
			a = o.position().left + UI.TouchScroll.EXTRA_MARGIN,
			s = o.find(".Navigation-item"),
			l = 0;
		for (n = s.length - 1; n > -1 && ((t = s[n]).offsetLeft <= Math.abs(a) && l++, !(l >= Navigation.SCROLL_ITEMS)); n--);
		if (t.offsetLeft < Math.abs(a)) {
			var c = o.width() - r.width();
			a = Math.min(-t.offsetLeft, 0);
			UI.TouchScroll.checkOverflows(i, a, -c, 0), a -= UI.TouchScroll.EXTRA_MARGIN, o.animate({
				left: a
			}, {
				duration: Navigation.ANIMATION_DURATION,
				easing: "easeOutCubic"
			})
		}
	},
	scrollRight: function(e) {
		var t, n, i = Navigation.getRootElement(e.target),
			o = Navigation.getContainerElement(i),
			r = Navigation.getWrapperElement(i),
			a = o.position().left + UI.TouchScroll.EXTRA_MARGIN,
			s = o.find(".Navigation-item"),
			l = 0;
		for (n = 0; n < s.length && ((t = s[n]).offsetLeft >= Math.abs(a) && l++, !(l >= Navigation.SCROLL_ITEMS)); n++);
		if (t.offsetLeft > Math.abs(a)) {
			var c = o.width() - r.width();
			a = Math.max(-t.offsetLeft, -c);
			UI.TouchScroll.checkOverflows(i, a, -c, 0), a -= UI.TouchScroll.EXTRA_MARGIN, o.animate({
				left: a
			}, {
				duration: Navigation.ANIMATION_DURATION,
				easing: "easeOutCubic"
			})
		}
	},
	resize: function(e) {
		$(e || document).find(".Navigation").each(function(e, t) {
			var n = $(t),
				i = Navigation.getContainerElement(n),
				o = Navigation.getWrapperElement(n),
				r = i.width();
			if (r > o.width() - Navigation.CONTAINER_PADDING) {
				n.addClass("is-constrained");
				var a = (r = i.width()) - o.width(),
					s = Math.min(Math.max(-a, i.position().left + UI.TouchScroll.EXTRA_MARGIN), 0);
				i.css("left", s - UI.TouchScroll.EXTRA_MARGIN + "px"), UI.TouchScroll.checkOverflows(n, s, -a, 0)
			} else n.hasClass("is-constrained") && i.css("left", ""), n.removeClass("is-constrained")
		})
	},
	refresh: function(e) {
		Navigation.resize(e)
	},
	changeSelectedItem: function(e, t) {
		var n = Navigation.getRootElement(e),
			i = n.find(".Navigation-link.is-selected");
		if (i.attr("data-name") !== t) {
			i.addClass("is-transitionOut"), n.find(".Navigation-link[data-name=" + t + "]").addClass("is-selected is-transitionIn");
			var o = n.find(".Navigation-selectDropdown");
			o.length && SelectDropdown.select(o, t, !0), setTimeout(function() {
				i.removeClass("is-selected is-transitionOut")
			}, 250)
		}
	}
};
UI.register(Navigation);
var Pagination = {
	getRootElement: function(e) {
		return $(e).closest(".Pagination")
	},
	getInputElement: function(e) {
		return e.children("input.Pagination-input")
	},
	getContainerElement: function(e) {
		return e.children(".Pagination-container")
	},
	getHtmlForLink: function(e) {
		return '<a onclick="Pagination.update(event, ' + e + ')" class="Pagination-node Pagination-link">' + e + "</a>"
	},
	init: function(e) {
		(e ? $(e).find(".Pagination") : $(".Pagination")).each(function(e, t) {
			var n = Pagination.getRootElement(t);
			Pagination.getInputElement(n).change(Pagination.render), n.children(".Pagination-previous").click(Pagination.previous), n.children(".Pagination-next").click(Pagination.next)
		})
	},
	render: function(e) {
		var t, n = Pagination.getRootElement(e.target),
			i = Pagination.getInputElement(n),
			o = Pagination.getContainerElement(n),
			r = parseInt(i.val()),
			a = parseInt(n.attr("data-pages")),
			s = parseInt(n.attr("data-range")),
			l = "",
			c = Math.min(a, r + s);
		for (t = Math.max(1, r - s); t < r; t++) l += Pagination.getHtmlForLink(t);
		for (l += '<div class="Pagination-node Pagination-current">' + r + "</div>", t = r + 1; t <= c; t++) l += Pagination.getHtmlForLink(t);
		o.html(l), n.find(".Pagination-previous").toggleClass("is-active", r > 1), n.find(".Pagination-next").toggleClass("is-active", r < a)
	},
	updateAttributes: function(e, t) {
		if (t) {
			var n = Pagination.getRootElement(e);
			void 0 !== t.pages && n.attr("data-pages", t.pages)
		}
	},
	update: function(e, t) {
		var n = Pagination.getRootElement(e.target);
		if (!n.hasClass("is-disabled")) {
			var i = parseInt(n.attr("data-pages")),
				o = Pagination.getInputElement(n);
			(t = Math.max(1, Math.min(t, i))) != parseInt(o.val()) && o.val(t).change()
		}
	},
	previous: function(e) {
		var t = Pagination.getRootElement(e.target);
		if (!t.hasClass("is-disabled")) {
			var n = Pagination.getInputElement(t),
				i = parseInt(n.val());
			i < 2 || Pagination.update(e, i - 1)
		}
	},
	next: function(e) {
		var t = Pagination.getRootElement(e.target);
		if (!t.hasClass("is-disabled")) {
			var n = Pagination.getInputElement(t),
				i = parseInt(n.val());
			i >= parseInt(t.attr("data-pages")) || Pagination.update(e, i + 1)
		}
	}
};
UI.register(Pagination);
var Parallax = {
	afterLoad: function() {
		Parallax.sync()
	},
	resize: function() {
		Parallax.sync()
	},
	scroll: function() {
		Parallax.sync()
	},
	sync: function() {
		var e = {};
		$(".Parallax").each(function(t, n) {
			var i, o = $(n),
				r = o.attr("data-group");
			if ((r = r ? "" + r : null) && void 0 !== e[r]) i = e[r];
			else {
				var a = o.attr("data-viewport-target"),
					s = o.attr("data-anchor-target"),
					l = s ? $(s)[0].getBoundingClientRect() : n.getBoundingClientRect(),
					c = o.attr("data-viewport");
				c = c ? parseFloat(c) : 50;
				var u = o.attr("data-anchor");
				u = u ? parseFloat(u) : 50;
				var d, f = o.height() * u / 100;
				if (a) {
					var p = $(a);
					d = p[0].getBoundingClientRect().top + p.height() * c / 100
				} else d = $(window).height() * c / 100;
				i = l.top + f - d, r && (e[r] = i)
			}
			var h = o.attr("data-distance");
			h = h ? parseFloat(h) : .5;
			var m = o.attr("data-direction") || "both",
				g = o.attr("data-opacity");
			g = g ? parseFloat(g) : 0;
			var v = o.attr("data-opacity-max");
			v = v ? parseFloat(v) : 1;
			var y = o.attr("data-opacity-min");
			y = y ? parseFloat(y) : 0;
			var b = {};
			if (i >= 0 && ("both" === m || "above" === m) || i < 0 && ("both" === m || "below" === m)) {
				var E, T = -h * i;
				if (b.transform = "translateY(" + T + "px)", g) E = g < 0 ? y - g * Math.abs(i) : v - g * Math.abs(i), E = Math.max(y, Math.min(E, v)), b.opacity = E
			} else b.transform = "translateY(0)", g && (b.opacity = v);
			o.children(".Parallax-content").css(b)
		})
	}
};
UI.register(Parallax);
var Scrollable = {
	init: function(e) {
		(e ? $(e).find(".Scrollable") : $(".Scrollable")).each(function(e, t) {
			var n = $(t),
				i = {};
			i.wheel = n.data("wheel"), n.tinyscrollbar(i)
		})
	},
	refresh: function(e) {
		(e ? $(e).find(".Scrollable:visible") : $(".Scrollable:visible")).each(function(e, t) {
			var n = $(t);
			Scrollable.render(n)
		})
	},
	render: function(e) {
		e.data("plugin_tinyscrollbar").update("relative")
	},
	scrollTo: function(e, t) {
		var n = e.data("plugin_tinyscrollbar"),
			i = t.position().top,
			o = i + t.height(),
			r = -1;
		i < n.contentPosition ? r = i : o > n.contentPosition + n.viewportSize && (r = o - n.viewportSize), -1 != r && n.update(r)
	}
};
UI.register(Scrollable);
var SelectDropdown = {
	KEY_CODE_TAB: 9,
	KEY_CODE_ENTER: 13,
	KEY_CODE_SPACE: 32,
	KEY_CODE_ESCAPE: 27,
	DOCUMENT_MARGIN: 20,
	SCROLLBAR_MARGIN: 10,
	SCROLL_THRESHOLD: 10,
	KEY_DATA: "touchData",
	getRootElement: function(e) {
		return $(e).closest(".SelectDropdown")
	},
	getToggleElement: function(e) {
		return e.children(".SelectDropdown-toggle")
	},
	getInputElement: function(e) {
		return e.children("select.SelectDropdown-input")
	},
	getListContainer: function(e) {
		return e.children(".SelectDropdown-listContainer")
	},
	getScrollable: function(e) {
		return e.find(".SelectDropdown-scrollable")
	},
	getListElement: function(e) {
		return e.find(".SelectDropdown-list")
	},
	getListOptions: function(e) {
		return e.children(".SelectDropdown-option")
	},
	getCloseButton: function(e) {
		return e.find(".ListItem--closeButton")
	},
	init: function(e) {
		(e ? $(e).find(".SelectDropdown") : $(".SelectDropdown")).each(function(e, t) {
			var n = $(t),
				i = SelectDropdown.getCloseButton(n),
				o = SelectDropdown.getToggleElement(n);
			n.on("touchstart", SelectDropdown.handleStart), o.on("touchstart", SelectDropdown.handleStart), o.on("touchend", SelectDropdown.handleEnd), o.on("blur", function() {
				$("html").css({
					height: "initial",
					overflow: "auto"
				})
			}), o.click(SelectDropdown.handleToggleClick), i.on("keydown", SelectDropdown.handleCloseKeydown), i.on("keyup mousedown", SelectDropdown.handleClose);
			var r = SelectDropdown.getListElement(n),
				a = SelectDropdown.getListOptions(r);
			a.click(SelectDropdown.handleOptionClick), a.on("focus", function(e) {
				SelectDropdown.scrollTo(e)
			}), n.on("keydown.selectDropdown", SelectDropdown.handleKeyPress), n.on("shown.bs.dropdown", SelectDropdown.render)
		})
	},
	handleStart: function(e) {
		UI.mouse.update(e.originalEvent);
		var t = UI.mouse.snapshot(),
			n = SelectDropdown.getRootElement(e.target);
		n.data(SelectDropdown.KEY_DATA, {
			x: t.x,
			y: t.y,
			active: !1
		}), n.on("touchmove", SelectDropdown.handleMove)
	},
	handleMove: function(e) {
		UI.mouse.update(e.originalEvent);
		var t = UI.mouse.snapshot(),
			n = SelectDropdown.getRootElement(e.target).data(SelectDropdown.KEY_DATA),
			i = t.x - n.x,
			o = t.y - n.y;
		(n.active || Math.abs(i) >= SelectDropdown.SCROLL_THRESHOLD || Math.abs(o) >= SelectDropdown.SCROLL_THRESHOLD) && (n.active = !0)
	},
	handleEnd: function(e) {
		var t = SelectDropdown.getRootElement(e.target);
		(t.off("touchmove", SelectDropdown.handleMove), t.data(SelectDropdown.KEY_DATA).active) || (e.stopPropagation(), t.data("currentIndex", null), SelectDropdown.getListElement(t).children(".SelectDropdown-option").removeClass("is-active"))
	},
	handleToggleClick: function(e) {
		if (UI.isRecentTouch()) return e.stopImmediatePropagation(), void e.preventDefault();
		var t = $(e.target);
		t.data("currentIndex", null), SelectDropdown.getRootElement(e.target).hasClass("open") && t.blur();
		var n = SelectDropdown.getListElement(t);
		SelectDropdown.getListOptions(n).removeClass("is-active")
	},
	handleOptionClick: function(e) {
		var t = SelectDropdown.getRootElement(e.target),
			n = $(e.target).closest(".SelectDropdown-option").data("value");
		n || e.stopPropagation(), SelectDropdown.getInputElement(t).val(n).change(), SelectDropdown.getToggleElement(t).blur()
	},
	handleKeyPress: function(e) {
		var t = SelectDropdown.getRootElement(e.target),
			n = SelectDropdown.getInputElement(t);
		if (t.hasClass("open")) {
			var i = SelectDropdown.getListOptions(SelectDropdown.getListElement(t)),
				o = i.filter('[tabindex="0"]').first().index();
			if (!(i.length < 1)) {
				var r = t.data("currentIndex");
				if (e.keyCode === SelectDropdown.KEY_CODE_TAB) {
					if (e.shiftKey && e.keyCode === SelectDropdown.KEY_CODE_TAB ? r > o ? (r--, void 0 === i.eq(r).attr("tabindex") && r--) : (i.eq(i.length - 1).focus(), r = i.length - 1, e.stopPropagation(), e.preventDefault()) : e.shiftKey || e.keyCode !== SelectDropdown.KEY_CODE_TAB || (r < i.length - 1 ? (r++, void 0 === i.eq(r).attr("tabindex") && r++) : (i.eq(o).focus(), r = o, e.stopPropagation(), e.preventDefault())), r < o) return !1;
					t.data("currentIndex", r)
				}
				var a = SelectDropdown.getToggleElement(t),
					s = i.eq(r);
				if (i.removeClass("is-active"), s.addClass("is-active"), e.keyCode === SelectDropdown.KEY_CODE_ENTER || e.keyCode === SelectDropdown.KEY_CODE_SPACE) {
					var l = t.data("currentIndex");
					n.val(i.eq(l).data("value")), n.change(), a.click()
				}
			}
		}
	},
	addHandler: function(e, t) {
		var n = SelectDropdown.getRootElement(e);
		SelectDropdown.getInputElement(n).on("change", t)
	},
	render: function(e) {
		var t = SelectDropdown.getRootElement(e.target),
			n = SelectDropdown.getListContainer(t),
			i = (SelectDropdown.getScrollable(t), SelectDropdown.getListElement(t)),
			o = SelectDropdown.getInputElement(t).val(),
			r = SelectDropdown.getListOptions(i);
		if (~navigator.userAgent.toLowerCase().indexOf("android") && $("html").css({
				height: "100%",
				overflow: "hidden"
			}), r.removeClass("is-active"), r.removeClass("is-selected"), r.each(function() {
				var e = $(this);
				e.data("value") == o && (SelectDropdown.getToggleElement(t).children("span.SelectDropdown-label").text(e.data("label")), t.data("currentIndex", e.index()))
			}), null !== t.data("currentIndex") && r.eq(t.data("currentIndex")).addClass("is-selected is-active"), t.hasClass("open")) {
			i.height() < n.height() && n.height(i.height());
			var a = $("body").width(),
				s = i.width(),
				l = a - 2 * SelectDropdown.DOCUMENT_MARGIN,
				c = i.find(".SelectDropdown-optionText"),
				u = r.first().outerWidth() - r.first().width(),
				d = Math.max.apply(null, c.map(function() {
					return $(this).width()
				}).get()) + u + SelectDropdown.SCROLLBAR_MARGIN;
			d != s && (s = d, n.width(s)), (s > n.width() || l < s) && (s = Math.min(s, l), n.width(s));
			var f = n.offset().left - n.position().left,
				p = a - SelectDropdown.DOCUMENT_MARGIN - (f + s);
			if (p < 0) {
				var h = t.width() - s;
				f + h >= SelectDropdown.DOCUMENT_MARGIN && (p = h)
			}
			p = Math.max(p, SelectDropdown.DOCUMENT_MARGIN - f), p = Math.min(p, 0), n.css({
				left: p + "px"
			}), r.eq(t.data("currentIndex")).focus()
		}
	},
	scrollTo: function(e) {
		var t = SelectDropdown.getRootElement(e.target),
			n = SelectDropdown.getScrollable(t);
		n.length && (Scrollable.render(n), Scrollable.scrollTo(n, $(e.target)))
	},
	select: function(e, t, n) {
		var i = SelectDropdown.getRootElement(e),
			o = SelectDropdown.getInputElement(i);
		o.val(t), n || o.change(), SelectDropdown.render({
			target: e
		})
	},
	handleCloseKeydown: function(e) {
		return e.shiftKey || e.keyCode === SelectDropdown.KEY_CODE_ESCAPE || e.keyCode === SelectDropdown.KEY_CODE_TAB
	},
	handleClose: function(e) {
		var t = SelectDropdown.getRootElement(e.target),
			n = SelectDropdown.getToggleElement(t);
		return (e.keyCode === SelectDropdown.KEY_CODE_ENTER || e.keyCode === SelectDropdown.KEY_CODE_SPACE || "mousedown" === e.type) && (t.click(), n.focus()), !1
	},
	resize: function() {
		$(".SelectDropdown.open").each(function(e, t) {
			SelectDropdown.getToggleElement($(t)).click()
		})
	}
};
UI.register(SelectDropdown);
var Slide = {
	DEFAULT_ANIMATION_DELAY: UI.DEFAULT_SLIDE_ANIMATION_DURATION,
	DEFAULT_TRANSITION_DELAY: 25,
	init: function(e) {
		(e ? $(e).find(".Slide") : $(".Slide")).each(function(e, t) {
			var n = $(t).closest(".CarouselItem");
			n.length > 0 && (n.on(CarouselItem.EVENT_ANIMATE_IN, Slide.animateIn.bind(null, t)), n.on(CarouselItem.EVENT_ANIMATE_OUT, Slide.animateOut.bind(null, t)))
		})
	},
	animateIn: function(e) {
		var t = $(e);
		t.addClass("is-transitionIn"), setTimeout(function() {
			t.addClass("is-active"), setTimeout(Slide.endAnimateIn.bind(null, e), Slide.DEFAULT_ANIMATION_DELAY)
		}, Slide.DEFAULT_TRANSITION_DELAY)
	},
	animateOut: function(e) {
		var t = $(e);
		t.addClass("is-transitionOut"), setTimeout(function() {
			t.removeClass("is-active"), setTimeout(Slide.endAnimateOut.bind(null, e), Slide.DEFAULT_ANIMATION_DELAY)
		}, Slide.DEFAULT_TRANSITION_DELAY)
	},
	endAnimateIn: function(e) {
		$(e).closest(".Slide").removeClass("is-transitionIn")
	},
	endAnimateOut: function(e) {
		$(e).closest(".Slide").removeClass("is-transitionOut")
	}
};
UI.register(Slide);
var Slideshow = {
	DEFAULT_TRANSITION_DELAY: 2e3,
	DEFAULT_TRANSITION_SPEED: 3e3,
	getRootElement: function(e) {
		return $(e).closest(".Slideshow")
	},
	getSlideElements: function(e) {
		return e.children(".Slideshow-slide")
	},
	getActiveSlideElement: function(e) {
		var t = e.children(".Slideshow-slide.is-active");
		return t.length > 0 ? t : null
	},
	getDelay: function(e) {
		return parseInt(e.attr("data-delay") || Slideshow.DEFAULT_TRANSITION_DELAY)
	},
	init: function(e) {
		$(e || document).find(".Slideshow").each(function(e, t) {
			var n = $(t);
			Slideshow.getActiveSlideElement(n).length < 1 ? Slideshow.transition.call(n) : setTimeout(Slideshow.transition.bind(n), Slideshow.getDelay(n))
		})
	},
	transition: function() {
		var e = Slideshow.getSlideElements(this),
			t = Slideshow.getActiveSlideElement(this) || $(e[0]),
			n = t.index() + 1;
		n = n < e.length ? n : 0;
		var i = $(e[n]);
		t.removeClass("is-active"), t.addClass("is-out"), i.addClass("is-animating is-active"), setTimeout(Slideshow.reset.bind(this, i, t), Slideshow.DEFAULT_TRANSITION_SPEED)
	},
	reset: function(e, t) {
		t.removeClass("is-animating is-out is-active"), e.removeClass("is-animating"), setTimeout(Slideshow.transition.bind(this), Slideshow.getDelay(this))
	}
};
UI.register(Slideshow);
var Spacer = {
	ELEMENT_HEIGHT: 1,
	refresh: function(e) {
		Spacer.resize(e)
	},
	resize: function(e) {
		$(e || document).find(".Spacer").each(function(e, t) {
			var n = $(t),
				i = n.attr("data-target");
			if (i) {
				var o = $(i).get(0).getBoundingClientRect(),
					r = t.getBoundingClientRect(),
					a = Math.max(0, o.bottom - (r.top + Spacer.ELEMENT_HEIGHT));
				n.css("height", a + "px")
			}
		})
	}
};
UI.register(Spacer);
var SvgLoader = {
	init: function(e) {
		(e ? $(e).find(".SvgLoader") : $(".SvgLoader")).each(function(e, t) {
			var n = $(t),
				i = n.attr("data-url");
			$.get(i, function(e) {
				n.html((new XMLSerializer).serializeToString(e.documentElement))
			})
		})
	}
};
UI.register(SvgLoader);
var SyncHeight = {
	init: function(e) {
		$(e || document).find(".SyncHeight").each(function(e, t) {
			UI.resizeHandlers.push(SyncHeight.sync.bind(null, t))
		})
	},
	sync: function(e) {
		if (e) {
			var t = $(e),
				n = t.attr("data-selector"),
				i = t.attr("data-target"),
				o = t.attr("data-above"),
				r = t.attr("data-below"),
				a = n ? t.find(n) : t.children(),
				s = i ? t.find(i) : a;
			o && !UI.isAboveBreakpoint(UI.BREAKPOINTS[o.toUpperCase()]) || r && !UI.isBelowBreakpoint(UI.BREAKPOINTS[r.toUpperCase()]) ? UI.clearHeight(s) : UI.syncHeight(a, s)
		}
	},
	load: function(e) {
		SyncHeight.refresh(e)
	},
	refresh: function(e) {
		$(e || document).find(".SyncHeight").each(function(e, t) {
			SyncHeight.sync(t)
		})
	}
};
UI.register(SyncHeight);
var TabControl = {
	ANIMATION_DURATION: 250,
	getRootElement: function(e) {
		return $(e).closest(".TabControl")
	},
	getContainerElement: function(e) {
		return e.find(".TabControl-container")
	},
	getIndicatorElement: function(e) {
		return e.children(".TabControl-indicator")
	},
	getTabItems: function(e) {
		return e.find(".TabControlItem")
	},
	getActiveTabItem: function(e) {
		return e.find(".TabControlItem.is-active")
	},
	init: function(e) {
		$(e || document).find(".TabControl").each(function(e, t) {
			var n = $(t),
				i = TabControl.getTabItems(n);
			i.each(function(e, t) {
				$(t).click(TabControl.clickHandler.bind(t))
			});
			var o = TabControl.getActiveTabItem(n);
			o.length ? TabControl.moveIndicator(n, o) : TabControl.clickHandler.call(i[0])
		})
	},
	clickHandler: function(e) {
		e && e.preventDefault && e.preventDefault();
		var t = $(this);
		if (!t.hasClass("is-disabled")) {
			var n = TabControl.getRootElement(t),
				i = TabControl.getActiveTabItem(n),
				o = n.attr("data-target");
			o && TabPanel && TabPanel.activate(o, t.index()), i.removeClass("is-active"), t.addClass("is-active"), TabControl.moveIndicator(n, t)
		}
	},
	moveIndicator: function(e, t, n) {
		t = t || TabControl.getActiveTabItem(e);
		var i = TabControl.getContainerElement(e);
		if (t.length) {
			var o = i[0].getBoundingClientRect(),
				r = t[0].getBoundingClientRect().left - o.left,
				a = t.outerWidth(),
				s = TabControl.getIndicatorElement(e),
				l = {
					left: r + "px",
					width: a + "px"
				};
			n ? s.css(l) : s.animate(l, TabControl.ANIMATION_DURATION, "easeOutCubic", function() {
				l = {
					width: t.outerWidth(),
					left: t[0].getBoundingClientRect().left - o.left
				}, s.css(l)
			})
		}
	},
	resize: function() {
		$(".TabControl").each(function(e, t) {
			var n = $(t);
			TabControl.moveIndicator(n, null, !0)
		})
	}
};
UI.register(TabControl);
var Table = {
	init: function(e) {
		$(".Table", e).each(function(e, t) {
			$(t).find(".Table-item.is-mobileLink").click(Table.mobileLink)
		})
	},
	filter: function(e, t) {
		var n = $(e).find(".Table-item");
		t ? n.each(function(e, n) {
			var i = $(n);
			i.toggleClass("hide", t != i.attr("data-filter"))
		}) : n.removeClass("hide")
	},
	mobileLink: function(e) {
		if (UI.isBelowBreakpoint(UI.BREAKPOINTS.SM)) {
			var t = $(e.target).closest(".Table-item.is-mobileLink");
			window.location.href = t.attr("data-url")
		}
	}
};
UI.register(Table);
var TableFilter = {
	afterInit: function(e) {
		$(e || document).find(".TableFilter").each(function(e, t) {
			SelectDropdown.addHandler(t, TableFilter.filter)
		})
	},
	filter: function(e) {
		var t = $(e.target),
			n = t.closest(".TableFilter"),
			i = t.val();
		Table.filter(n.attr("data-target"), i)
	}
};
UI.register(TableFilter);
var TableHeader = {
		getRootElement: function(e) {
			var t = $(e);
			return t.hasClass("TableHeader") ? t : t.closest(".TableHeader")
		},
		getInputElement: function(e) {
			return e.children("input.TableHeader-input")
		},
		getColumn: function(e, t) {
			return e.children('div[data-name="' + t + '"]')
		},
		sort: function(e, t) {
			var n = TableHeader.getInputElement(e),
				i = n.val();
			if (i) {
				var o = i.split(","),
					r = o[0].split(":");
				if (r[0] == t || null == t) r[1] = "asc" == r[1] ? "desc" : "asc", o[0] = r.join(":");
				else {
					var a;
					for (a = 1; a < o.length; a++)
						if ((r = o[a].split(":"))[0] == t) {
							o.splice(a, 1);
							break
						} o.unshift([t, "asc"].join(":"))
				}
				i = o.join(",")
			} else i = t + ":asc";
			n.val(i).change()
		},
		update: function(e) {
			if (!(e.data ? e.data.suppress : e.suppress)) {
				var t = $(e.target),
					n = TableHeader.getRootElement(e.target);
				t.is("select") ? TableHeader.sort(n, t.val()) : t.hasClass("TableHeader-toggle") ? TableHeader.sort(n, null) : TableHeader.sort(n, t.attr("data-name"))
			}
		},
		render: function(e) {
			var t = TableHeader.getRootElement(e.target),
				n = TableHeader.getInputElement(t);
			t.find(".TableHeader-item").removeClass("is-ascending is-descending");
			var i = n.val();
			if (i) {
				var o = i.split(",")[0].split(":");
				t.find(".TableHeader-item[data-name='" + o[0] + "']").addClass("asc" == o[1] ? "is-ascending" : "is-descending"), t.find(".TableHeader-select select").val(o[0]).trigger({
					type: "change",
					suppress: !0
				}), t.find(".TableHeader-toggleOuter").toggleClass("is-ascending", "asc" == o[1]).toggleClass("is-descending", "asc" != o[1])
			}
		}
	},
	TabPanel = {
		getRootElement: function(e) {
			return $(e).closest(".TabPanel")
		},
		getContainerElement: function(e) {
			return e.find(".TabPanel-container")
		},
		getTabItems: function(e) {
			return e.find(".TabPanelItem")
		},
		getActiveTabItem: function(e) {
			return e.find(".TabPanelItem.is-active")
		},
		init: function(e) {
			$(e || document).find(".TabPanel").each(function(e, t) {
				var n = $(t);
				TabPanel.getActiveTabItem(n).length < 1 && TabPanel.activate(n, 0)
			})
		},
		activate: function(e, t) {
			var n = TabPanel.getRootElement(e);
			if (n.length < 1) return !1;
			var i = TabPanel.getTabItems(n);
			if (t < 0 || t >= i.length) return !1;
			var o = TabPanel.getActiveTabItem(n),
				r = $(i[t]);
			return o.removeClass("is-active"), r.addClass("is-active"), !0
		}
	};
UI.register(TabPanel);
var TabSelect = {
	ANIMATION_DURATION: 250,
	getRootElement: function(e) {
		return $(e).closest(".TabSelect")
	},
	getSelectElement: function(e) {
		return e.find(".TabSelect-selectDropdown")
	},
	getWrapperElement: function(e) {
		return e.find(".TabSelect-tabItemWrapper")
	},
	getContainerElement: function(e) {
		return e.find(".TabSelect-tabItemContainer")
	},
	getIndicatorElement: function(e) {
		return e.find(".TabSelect-tabIndicator")
	},
	getTabItems: function(e) {
		return e.find(".TabSelect-tabItem")
	},
	getTabItemByValue: function(e, t) {
		return e.find(".TabSelect-tabItem[data-value=" + t + "]")
	},
	getActiveTabItem: function(e) {
		return e.find(".TabSelect-tabItem.is-active")
	},
	init: function(e) {
		$(e || document).find(".TabSelect").each(function(e, t) {
			var n = $(t),
				i = TabSelect.getSelectElement(n);
			SelectDropdown.addHandler(i, TabSelect.selectChangeHandler);
			var o = TabSelect.getTabItems(n);
			o.each(function(e, t) {
				$(t).click(TabSelect.clickHandler.bind(t))
			});
			var r = TabSelect.getActiveTabItem(n);
			r.length ? TabSelect.moveIndicator(n, r) : TabSelect.clickHandler.call(o[0])
		})
	},
	selectChangeHandler: function(e) {
		var t = $(e.target).val(),
			n = TabSelect.getRootElement(e.target),
			i = TabSelect.getTabItemByValue(n, t);
		i.length && !i.hasClass("is-active") && (TabSelect.getActiveTabItem(n).removeClass("is-active"), i.addClass("is-active"), TabSelect.moveIndicator(n, i))
	},
	clickHandler: function(e) {
		e && e.preventDefault && e.preventDefault();
		var t = $(this);
		if (!t.hasClass("is-disabled")) {
			var n = TabSelect.getRootElement(t);
			TabSelect.getActiveTabItem(n).removeClass("is-active"), t.addClass("is-active");
			var i = TabSelect.getSelectElement(n);
			SelectDropdown.select(i, t.attr("data-value")), TabSelect.moveIndicator(n, t)
		}
	},
	addChangeHandler: function(e, t) {
		var n = TabSelect.getRootElement(e),
			i = TabSelect.getSelectElement(n);
		SelectDropdown.addHandler(i, t)
	},
	moveIndicator: function(e, t, n) {
		t = t || TabSelect.getActiveTabItem(e);
		TabSelect.getContainerElement(e);
		if (t.length) {
			var i = e[0].getBoundingClientRect(),
				o = t[0].getBoundingClientRect(),
				r = o.left - i.left,
				a = i.bottom - o.bottom,
				s = t.outerWidth(),
				l = TabSelect.getIndicatorElement(e),
				c = {
					left: r + "px",
					bottom: a + "px",
					width: s + "px"
				};
			n ? l.css(c) : l.animate(c, TabSelect.ANIMATION_DURATION, "easeOutCubic", function() {
				TabSelect.moveIndicator(e, t, !0)
			})
		}
	},
	resize: function() {
		$(".TabSelect").each(function(e, t) {
			var n = $(t),
				i = TabSelect.getWrapperElement(n),
				o = n.width() >= i.width();
			n.toggleClass("is-expanded", o), n.toggleClass("is-collapsed", !o), o && TabSelect.moveIndicator(n, null, !0)
		})
	},
	load: function() {
		TabSelect.resize()
	}
};
UI.register(TabSelect);
var TextOverflow = {
	init: function(e) {
		e && TextOverflow.resize()
	},
	afterLoad: function(e) {
		TextOverflow.resize()
	},
	refresh: function(e, t) {
		t || $(e || document).find(".TextOverflow").each(function(e, t) {
			TextOverflow.truncate(t)
		})
	},
	resize: function() {
		$(".TextOverflow").each(function(e, t) {
			TextOverflow.truncate(t)
		})
	},
	truncate: function(e) {
		if (e) {
			for (var t = $(e), n = t; n.children().length;) n = n.children().first();
			var i = $(t.parent()),
				o = i.children();
			t.attr("data-original-text") ? n.text(t.attr("data-original-text")) : t.attr("data-original-text", n.text());
			for (var r = t.attr("data-original-text").split(/\s+/).length, a = 0, s = 0; s < o.length; s++) {
				var l = $(o[s]);
				l.is(t) || (a += l.outerHeight(!0))
			}
			for (var c = Math.max(0, i.height() - a); r > 0 && c > 0 && t.outerHeight(!0) > c;) r--, n.text(function(e, t) {
				return t.replace(/\W*\s(\S)*$/, "...")
			})
		}
	}
};
UI.register(TextOverflow);
var Tile = {
	resize: function(e) {
		$(e || document).find(".Tile").each(function(e, t) {
			var n = $(t).outerWidth(),
				i = Math.floor((n + parseInt(t.getAttribute("data-offset"))) * parseFloat(t.getAttribute("data-ratio")));
			$(t).height(i)
		})
	},
	refresh: function(e) {
		Tile.resize(e)
	}
};
UI.register(Tile);
var TileGroup = {
	init: function(e) {
		$(e || document).find(".TileGroup").each(function(e, t) {
			UI.resizeHandlers.push(TileGroup.sync.bind(null, t))
		})
	},
	sync: function(e) {
		if (e) {
			var t = $(e),
				n = t.find(".Tile"),
				i = t.find(".Tile-content");
			UI.isAboveBreakpoint(UI.BREAKPOINTS.XS) ? (UI.clearHeight(n), UI.syncHeight(i)) : (UI.clearHeight(i), UI.syncHeight(i, n))
		}
	},
	refresh: function(e) {
		$(e || document).find(".TileGroup").each(function(e, t) {
			TileGroup.sync(t)
		})
	}
};
UI.register(TileGroup);
var Tooltip = {
	getRootElement: function(e) {
		return $(e).closest(".Tooltip")
	},
	getToggleElement: function(e) {
		return e.find(".Tooltip-toggle")
	},
	getOverlayElement: function(e) {
		return e.find(".Tooltip-overlay")
	},
	getCloseElement: function(e) {
		return e.find(".Tooltip-close")
	},
	init: function() {
		$(".Tooltip").each(function(e, t) {
			var n = Tooltip.getRootElement(t);
			Tooltip.getToggleElement(n).click(Tooltip.handleToggle), Tooltip.getCloseElement(n).click(Tooltip.handleClose)
		}), $(document).on("click.Tooltip", Tooltip.handleCloseAll)
	},
	handleToggle: function(e) {
		var t = Tooltip.getRootElement(e.target),
			n = !t.hasClass("is-open");
		Tooltip.handleCloseAll(e), n && (t.addClass("is-open"), Tooltip.render(e.target)), e.stopPropagation()
	},
	handleClose: function(e) {
		Tooltip.getRootElement(e.target).removeClass("is-open"), e.stopPropagation()
	},
	handleCloseAll: function(e) {
		$(".Tooltip").removeClass("is-open")
	},
	render: function(e) {
		var t = Tooltip.getRootElement(e),
			n = Tooltip.getOverlayElement(t),
			i = n.get(0).getBoundingClientRect(),
			o = $(window).width() - i.right;
		o < 0 && n.css({
			left: n.get(0).offsetLeft + o + "px"
		}), i.left < 0 && n.css({
			left: n.get(0).offsetLeft - i.left + "px"
		})
	}
};
UI.register(Tooltip);
var VideoPane = {
	getVideoElements: function() {
		return $(document).find(".VideoPane-video")
	},
	init: function() {
		VideoPane.toggleVideoPlay()
	},
	resize: function() {
		VideoPane.toggleVideoPlay()
	},
	documentBlur: function() {
		VideoPane.toggleVideoPlay()
	},
	toggleVideoPlay: function() {
		var e = document.hidden,
			t = UI.isBelowBreakpoint(UI.BREAKPOINTS.SM);
		VideoPane.getVideoElements().each(function(n, i) {
			e ? i.pause() : t ? i.pause() : e || t || i.play()
		})
	}
};
UI.register(VideoPane);
