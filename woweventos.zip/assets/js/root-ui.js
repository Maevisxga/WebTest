var Page = {
	init: function(e) {
		e || ($(".Home-gameGridRow").scroll(Page.galleryResize), $(".Home-gameGridScrollLeft").click(Page.galleryLeft), $(".Home-gameGridScrollRight").click(Page.galleryRight), $(".Home-promotedCarouselItem").on("animateout.CarouselItem", Page.topCarouselOut), "desktop" === $("body").attr("data-device") ? ($(".Home-gameGridTileContainer").on("mouseover", Page.gameTileHover), $(".Home-gameGridTileContainer").on("focus", "*", Page.gameTileHover)) : "mobile" === $("body").attr("data-device") && ($(".Home-gameGridTileContainer [aria-hidden=true]").attr("aria-hidden", "false"), $(".Home-gamePane").on("keydown", Page.setGameTileTabIndex)), Page.setDeviceType())
	},
	setDeviceType: function() {
		$(document.body).attr("data-device", blizzard.deviceType)
	},
	afterLoad: function() {
		Page.resize()
	},
	resize: function(e) {
		Page.syncGallery(), Page.syncTopStories()
	},
	topCarouselOut: function(e) {
		var a = $(e.target).closest(".Home-promotedCarouselItem");
		a.addClass("is-out"), setTimeout(function() {
			a.removeClass("is-out")
		}, 500)
	},
	getGalleryInner: function() {
		var e = 0;
		return $(".Home-gameGridCell").each(function(a, t) {
			e += $(t).outerWidth()
		}), e
	},
	syncGallery: function(e) {
		if (UI.getCurrentBreakpoint() === UI.BREAKPOINTS.XS) {
			var a = $(".Home-gameGridRow"),
				t = Page.getGalleryInner() - a.width();
			null == e && (e = a.scrollLeft()), $(".Home-gameGridScrollLeft").toggleClass("hide", e <= 0), $(".Home-gameGridScrollRight").toggleClass("hide", e >= t)
		}
	},
	syncTopStories: function() {
		UI.syncHeight($(".Home-topStoriesGalleryCard"))
	},
	galleryLeft: function() {
		var e = $(".Home-gameGridRow"),
			a = Page.getGalleryInner() - e.width(),
			t = Math.max(0, Math.min(e.scrollLeft() - e.width(), a));
		Page.syncGallery(t), e.animate({
			scrollLeft: t
		}, {
			duration: Gallery.ANIMATION_DURATION,
			easing: "easeOutCubic"
		})
	},
	galleryRight: function() {
		var e = $(".Home-gameGridRow"),
			a = Page.getGalleryInner() - e.width(),
			t = Math.max(0, Math.min(e.scrollLeft() + e.width(), a));
		Page.syncGallery(t), e.animate({
			scrollLeft: t
		}, {
			duration: Gallery.ANIMATION_DURATION,
			easing: "easeOutCubic"
		})
	},
	gameTileHover: function(e) {
		var a = $(e.target || e.originalEvent.target).closest(".Home-gameGridTileContainer");
		Page.scrollActiveGameTileToView(a)
	},
	scrollActiveGameTileToView: function(e) {
		var a = e.closest(".Gallery-container");
		if (a && a.length) {
			var t = e[0].getBoundingClientRect(),
				i = a[0].getBoundingClientRect(),
				l = null;
			if (t.left < i.left ? l = a.scrollLeft() - (i.left - t.left) : t.right > i.right && (l = a.scrollLeft() + (t.right - i.right)), null !== l) a.animate({
				scrollLeft: l
			}, {
				duration: Gallery.ANIMATION_DURATION,
				easing: "easeOutCubic",
				done: function() {
					Gallery.checkLimits(e, l)
				}
			});
			else {
				var r = e.closest(".Home-gameGridGalleryItem"),
					o = r.closest(".Home-gameGridCell"),
					n = o.find(".Home-gameGridGalleryItem");
				n.first().is(r) ? o.find(".Gallery-left").click() : n.last().is(r) && o.find(".Gallery-right").click()
			}
		}
	},
	setGameTileTabIndex: function(e) {
		var a = $(".Home-gameGridGalleryLink"); - 1 === a.first().prop("tabindex") && "Tab" === e.key && a.each(function() {
			$(this).attr("tabindex", 0)
		})
	}
};
UI.register(Page);
